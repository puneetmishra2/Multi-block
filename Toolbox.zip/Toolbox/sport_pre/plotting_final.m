for i=1:6
yt = y_test_all{1,i};
pred = models_all{1, i}.predY;  
 
    
SSTp=sum((yt-mean(yt)).^2); 
SSEp=sum((yt-pred).^2); 
 R2_P=1-SSEp/SSTp;
RMSEP=sqrt(SSEp/size(yt,1));
figure, 
% subplot(1,2,1)
plot(yt,pred,'.r','MarkerSize',20);
 lsline
 xlabel('Measured');
 ylabel('Predicted');
 title(['R^2p = ' num2str(round(R2_P,2)) ' RMSEP = ' num2str(round(RMSEP,2))]);
 set(gca,'FontSize',12,'FontWeight','bold');
 
 clear yt pred SSTp SSEp R2_P RMSEP
 
%  yt= testyyy{1,i};
% pred = prediction{1,i}; 
% 
% SSTp=sum((yt-mean(yt)).^2); 
% SSEp=sum((yt-pred).^2); 
%  R2_P=1-SSEp/SSTp;
% RMSEP=sqrt(SSEp/size(yt,1));
%  
% subplot(1,2,2)
% plot(yt,pred,'.b','MarkerSize',20);
%  lsline
%  xlabel('Measured');
%  ylabel('Predicted');
%  title(['R^2p = ' num2str(R2_P) ' RMSEP = ' num2str(RMSEP)]);
%  set(gca,'FontSize',14,'FontWeight','bold');
%  clear yt pred
end

%%

