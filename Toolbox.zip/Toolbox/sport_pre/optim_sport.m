
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%adding folder in path
addpath([pwd '/sport_pre']);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nc = size(p1,1);

if nB == 2
    xc={ p1, p2 };
    pret = {'mean','mean','mean'};
elseif nB==3
    xc={ p1, p2, p3};
    pret = {'mean','mean','mean','mean'};
elseif nB==4
    xc={ p1, p2, p3, p4 };
    pret = {'mean','mean','mean','mean','mean'};
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nblk = length(xc);

%%%%%%%%%%%%%%%%%%%%%begin with some runs with two randomly chosen blocks higher than other ones
nrun = 20;
cvtyp = 'predef';
LVMAX = 20;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

lopt = zeros(nrun,nblk); %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% to record the results
h = waitbar(0,'first step...');
for i=1:nrun
    b = randperm(nblk,2);
    lv = ones(1,nblk); lv(b) = LVMAX; % generate sm like [1 1 4 1 ... 1 4 1 ... ]
    seg = ceil(rand(nc,1).*2);      % two random blocks
    model  = soplsmulti1_cv_sport( xc, Y, lv, pret, cvtyp, seg, 'no', 'no');
    lopt(i,:) = model.CV.LVopt;
    waitbar(i/nrun);
end
close(h);

lopt = ceil(mean(lopt));        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% adopt mean(lopt)+1

nit_max = 100;
ll = zeros(nit_max+1,nblk);
ll(1,:) = lopt;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
arret = 0;
match = 0;
l0 = lopt;
k = 0;

while arret==0
    seg = ceil(rand(nc,1).*2);  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 2 random blocks
    model  = soplsmulti1_cv_sport( xc, Y, ceil(lopt), pret, cvtyp, seg, 'no', 'no');
        % managing the end of the loop    k = k+1;
    if sum(abs(model.CV.LVopt(:)-l0(:)))==0
        match = match+1;
    else
        match = 0;
        l0 = model.CV.LVopt;
    end
    if match > 10 || k > nit_max
        arret = 1;
    end
   
        % change gently the LV
        % numbers%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    lopt = 0.8.*lopt + 0.2.*model.CV.LVopt;
    
%%%%%%%%%%%%%%%%%%%% trace the results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ll(k+1,:) = lopt;
    plot(ll,'*-'); 
    legend(num2str((1:nblk)'));
    xlabel('Number of iterations')
    ylabel('Latent variables');
    title('I am SPORTING');
    set(gca,'FontSize',12,'FontWeight','bold');
    drawnow
    k = k+1;
end

lv_opt = round(lopt);
bar(round(lopt));
set(gca,'FontSize',12,'FontWeight','bold');
title('Use pre-processig with non-zero LVs');
xlabel('Blocks');
ylabel('Latent variables selected');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pred = soplsmulti1_pred(xc,model.OptModel);
    
SSTp = sum((Y-mean(Y)).^2); 
SSEp = sum((Y-pred.predY).^2); 
 R2_C =  1-SSEp/SSTp;
RMSEC = sqrt(SSEp/size(Y,1));
figure, 
% subplot(1,2,1)
plot(Y,pred.predY,'.b','MarkerSize',20);
 lsline
 xlabel('Measured');
 ylabel('Predicted');
 title(['R^2_c = ' num2str(round(R2_C,2)) ' RMSEC = ' num2str(round(RMSEC,2))]);
 set(gca,'FontSize',12,'FontWeight','bold');
 
 clear yt pred SSTp SSEp R2_C RMSEC pred
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

