function model=soplsmulti1_cv(X, Y, LVmax, pret, cvtype, segments, savepred, plots)

if nargin<=6||isempty(savepred)
    savepred='no'; 
end

% JMR 29/11/2019 begin insert
if nargin<=7||isempty(plots)
    plots='no'; 
end
% JMR 29/11/2019 end insert



nblock=length(X);

if max(size(LVmax))==1
    LVmax=repmat(LVmax, 1, nblock);
end
ntot=size(X{1},1); %Total number of samples
if strcmp(cvtype, 'loo')  %Loo cross-validation corresponds to syst123 with N segments
    cvtype='syst123';
    segments=ntot;
end

% JMR 23/07/2019 begin insert
if strcmp(cvtype, 'predef')     % predefined blocks
    u = unique(segments,'rows');
    blocks = segments;
    segments = size(u,1);
end;
% JMR 23/07/2019 end insert


rmsecv=zeros(LVmax+1);
Ypredcv=cell(LVmax+1);

% JMR 29/11/2019 begin insert
h=waitbar(0,'Please wait ...'); 
k=0;
% JMR 29/11/2019 end insert

for j=1:segments %Beginning of the crossvalidation loop
    
    switch cvtype
        case 'syst123'    %venetian blind cross-validation
            t=j:segments:ntot; %Calibration set
            m=1:ntot; m(t)=[]; %Validation set
            
        case 'syst111'    %contiguous blocks
            ns=ceil(ntot./segments);  %number of samples in each group
            if j==segments
                t=(j-1)*ns+1:ntot; %Validation set
            else
                t=(j-1)*ns+1:j*ns; %Calibration set
            end
            m=[1:(j-1)*ns ns*j+1:ntot]; %camp. nel set di calib.
        % JMR 23/07/2019 begin insert
        case 'predef'     % predefined blocks
            m=find(blocks~=u(j));   % Cal set
            t=find(blocks==u(j));   % Val set
        % JMR 23/07/2019 end insert
    end
    
    cvist=[];
    ll='lvr=[';
    ll1=[];
    ee=[];
    
    
    
    for i=1:nblock
        Xm{i}=X{i}(m,:);
        Xt{i}=X{i}(t,:);
        cvist=[cvist, ' for l', num2str(i), '=0:LVmax(',num2str(i),'), '];
        ll=[ll, 'l',num2str(i), ','];
        ll1=[ll1, 'l',num2str(i), '+1,'];
        
        ee=[ee, ' end, '];
    end
    Ym=Y(m,:);
    Yt=Y(t,:);
    ll=[ll(1:end-1), '];'];
    ll1=ll1(1:end-1);
    
    cvi2=['if sum(lvr)~=0, sm=soplsmulti1_mod(Xm,Ym,lvr,pret); sp=soplsmulti1_pred(Xt,sm);else, sp.predY=repmat(mean(Ym), size(Xt{1},1),1); end, '];

    cvi3=['rmsecv(',ll1,')=rmsecv(',ll1,')+sum(sum((Yt-sp.predY).^2));Ypredcv{',ll1,'}(t,:)=sp.predY;'];
    
    % JMR 29/11/2019 begin insert
    cvi4=['k=k+1;waitbar(k/(segments*prod(LVmax+1)));'];
    % JMR 29/11/2019 end insert
    
    eval([cvist, ll, cvi2, cvi3, cvi4, ee])
end

rmsecv=sqrt(rmsecv./ntot);

% JMR 29/11/2019 begin insert
close(h);
% JMR 29/11/2019 end insert


%Mage plot
% JMR 29/11/2019 begin insert
if strcmp(plots, 'yes')
% JMR 29/11/2019 end insert
    figure
    hold on
    cvi4=['plot(sum(lvr), rmsecv(',ll1,'), ''.k'', ''MarkerSize'',8);'];
    cvi5=['tt=''('';for k=1:length(lvr), if k~=length(lvr),tt=[tt, num2str(lvr(k)), '','']; else, tt=[tt, num2str(lvr(k)), '')''];end; end,'];
    cvi6=['text(sum(lvr), rmsecv(',ll1,'),tt),'];

    eval([cvist, ll, cvi4,cvi5 ,cvi6,ee])
    xlabel('Total complexity'), ylabel('RMSECV')
    shg
% JMR 29/11/2019 begin insert
end;
% JMR 29/11/2019 end insert

model.CV.rmsecv=rmsecv;

if strcmp(savepred, 'yes')
    model.CV.CVpredY=Ypredcv;
end

rmsecvopt=rmsecv;


for ll=nblock:-1:1

finst=['[~,l',num2str(ll),'opt]=',repmat('min(',1,ll), 'rmsecvopt', repmat(')', 1,ll), ';'];
eval(finst);
finst2=['rmsecvopt=squeeze(rmsecvopt(', repmat(':,', 1, ll-1), 'l', num2str(ll), 'opt));'];
eval(finst2)
eval(['LVopt(ll)=l', num2str(ll), 'opt-1;'])
end

model.CV.rmsecvopt=rmsecvopt;
model.CV.LVopt=LVopt; 

mfin=soplsmulti1_mod(X,Y,LVopt,pret);
model.OptModel=mfin;

