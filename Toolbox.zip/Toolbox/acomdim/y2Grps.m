function [Grps]=y2Grps(y)
% [Grps]=y2Grps(y)
% y is a vector of integers
% Grps is a matrix of 0s and 1s
% By DNR 24/08/06

% One way to do it :
% : for i=1:valsy;Grps(:,i)=(y==i);end;

    rows = size(y,1);

% This is not too good !
% I'm supposing that the users don't do silly things !
% can be a vector of integers
% it will be changed into a matrix of 0s and 1s
% e.g. 2 2 2 5 5 5 9 9 9
% will be changed into a (9 x 3) matrix of 0s and 1s
% Values in the y vector cannot be = 0 ! ! !

if min(y)==0
    y=y+1;
end

miny=min(y);
maxy=max(y);
valsy=maxy-miny+1;
Grps=zeros(rows,valsy);

for j=miny:maxy
    for i=1:rows
        if y(i)==j
            %Grps(i,j-valsy+1)=1;
            %Grps(i,j-miny+1)=1;
            Grps(i,j)=1;
        end;
    end;
end;

j=1;
while (j<size(Grps,2))
    while Grps(:,j)==zeros(rows,1)
        Grps(:,j:end-1)=Grps(:,j+1:end);
        Grps(:,end)=[];
    end;
	j=j+1;
end;
