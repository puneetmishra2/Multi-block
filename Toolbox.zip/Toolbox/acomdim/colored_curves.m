function h=colored_curves(s,group)
%coloured_curves        - displays curves coloured according to groups  
%function h=colored_curves(X,group)
%
%Input argument:
%--------------
%X: SAISIR matrix (n x p)
%group: Saisir vector of groups (integers,n x 1).
%
%The function displays all the observations as curves.
%Each curve is colored according to the values in "group". The observations
%with the same group number are colored identically.   



couleur=[0 0 0; 0 0 1; 1 0 0; 1 0 0; 0 1 0 ; 0 1 0; 0 0.5 0.5 ; 0.25 0.25 0.25 ; 0.5 0 0; 0 0.5 0; 0 0.5 0; 0.1 0.2 0.3; 0.3 0.2 0.1; 0.5 0.5 0.8; 0.1 0.8 0.1 ];
[n,p]=size(s.d);
%if(nargin==1)
   nstart=1;
   nend=n;
	range=nstart:nend;   
%end;   
%if(nstart>n); nstart=n; end;
%if(nend>n);nend=n;end;
[bid,n1]=size(range);
if(range(1)<0); range(1)=1;end;
if(~isempty(str2num(s.v))) h=plot(str2num(s.v),s.d(range(1),:),'k');
set(h,'LineWidth',1);% utilisation du handle
else
   h=plot(s.d(range(1),:));end;
	set(h,'LineWidth',2);% utilisation du handle
hold on
aux=group.d(range(1));
set(h,'Color',couleur(mod(aux,15)+1,:));

for i=range(2:n1)
   if((i<=n)&(i>0))
      if(~isempty(str2num(s.v)))
          aux=group.d(range(i)) ;
          h=plot(str2num(s.v),s.d(i,:),'Color',couleur(mod(aux,15)+1,:));
      else
          aux=group.d(range(i)) ; 
          h=plot(s.d(i,:),'Color',couleur(mod(aux,15)+1,:));
      end;
    end  
    set(h,'LineWidth',2);% utilisation du handle
end;   
set(h,'LineWidth',2);% utilisation du handle
axis('tight'); 
% if(nargin >2) xlabel(xlab);end;
% if(nargin>3)ylabel(ylab);end;
% if(nargin>5) title(titre); end
hold off