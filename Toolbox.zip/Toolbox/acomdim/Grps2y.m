function [y]=Grps2y(Grps);
% By DNR 06/03/08
% Converts a binary (0/1) group matrix into a vector
[Xsize,Ysize]=size(Grps);

for i=1:Xsize
    for j=1:Ysize
        if Grps(i,j)==1
            y(i)=j;
        end
    end
end

        

