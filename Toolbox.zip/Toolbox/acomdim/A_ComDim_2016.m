function [A_ComDimIn, A_ComDimOut, ComDimResult, A_Collection]=A_ComDim_2016(X, GrpsCritNum, Options);
% A_ComDim - Performs ComDim analysis on a series of tables
% generated as in ASCA or APCA.
% function [A_ComDimIn, A_ComDimOut]=A_ComDim(X, GrpsCritNum, Options)
%
%
% INPUT :
%---------------
% X:  (nXrows x nXcols) matrix of initial data to be decomposed into ANOVA matrices
% GrpsCritNum: (nXrows x nGrps) matrix of group numbers for each classification criterion
% Options.Plots: 0=No figures; 1=Last figures; 2=All figures; 3=Too many figures
% Options.Dims: Number of Common Components if <> Number of tables
% Options.Samples=0/1; Plot samples in ellipses or not
%
% OUTPUT :
%-----------------
% A_ComDimIn: Structure with fields:
% A_ComDimIn.X : (nXrows x nXcols) original data matrix (X)
% A_ComDimIn.Grps : (nXrows x nGrps) groups numbers for factors and interactions
% A_ComDimIn.X_mean : (nTables of nXrows x nXcols) Structure of removed group mean vectors 
% A_ComDimIn.X_i : (nTables of nXrows x nXcols) Structure after removing X_mean
% A_ComDimIn.X_r : (nTables of nXrows x nXcols) Structure of group mean vectors + residual noise
% A_ComDimIn.Titre : (nTables x 1) list of strings with labels of Factors;
%
% A_ComDimOut: Cell array of (1 x nTables) Structures with fields:
% A_ComDimOut{i}.ComDimQ : (nXrows x 1) observations scores 
% A_ComDimOut{i}.ComDimSalience : (1 x ndim) weight of the original tables in each dimension.
% A_ComDimOut{i}.ComDim_Lx : (1 x nXcols) weight of the original variables for the significant table.
% A_ComDimOut{i}.ComDimExpl : (1 x 1) percentage explanation given by dimension  
% A_ComDimOut{i}.F1 : (1 x 1) Fisher's F based on saliences of CD1  
%
% ComDimResult: Structure with all the output of comdim_calib_V7
%
% A_Collection : (nGrps x 1) Structure of (nXrows x nXcols) Factor+Error tables 
%
% CALLS :
% y2Grps
% Grps2y
% comdim_calib_V6
% ANOVAPCAmegX_Ellipse_no_text_sample
% ANOVAPCAmegX_Ellipse
%
% REFERENCES
%-----------------
% 'ComDim' method :
% E.M. Qannari, I. Wakeling, P. Courcoux and H. J. H. MacFie
% Food quality and Preference 11 (2000) 151-154
%
% 'APCA' methods :
% P. Harrington, N. Vieira, J. Espinoza, J. Nien, R. Romero, A. Yergey
% Analysis of variance-principal component analysis: A soft tool for proteomic discovery.
% Analytica Chimica Acta, 544, 118-127, 2005.
%
%
% TYPICAL EXAMPLE 
%-----------------
% A (37x4600) matrix of spectra 'Wine_Data'
% and 
% 4 grouping criteria indicated by a (37x4) matrix
% of non-zero groups numbers 'Wine_Grps'
% and
% 0 plots, 10 Common Components
% Opts.Plots=0;
% Opts.Dims=10;
% Opt.Samples='Samples';

%[A_ComDimIn, A_ComDimOut, A_Collection]=A_ComDim_2016(Wine_Data, Wine_Grps, Opts);
%
%
%%
[nXrows,nXcols]=size(X);
[nXrows, nGrpCrits]=size(GrpsCritNum);
% verify matrix sizes later !

GrpsCritNumTemp=GrpsCritNum;

if exist('Options')
    if isfield(Options, 'Plots')
        Plots=Options.Plots;
    else
        Plots=3;
    end;

    if isfield(Options, 'Dims')
        nDims=Options.Dims;
    else
        nDims=2^(nGrpCrits);
    end
    
    if isfield(Options, 'Samples')
        PlotSamples=Options.Samples;
    else
        PlotSamples=0;
    end
else
    Plots=3;
    nDims=2^(nGrpCrits);
end;


%% Pour tester !
% load('Lignine_Starch_smooth_Balanced_Minimal.mat');

% GrpsCritNum: (nXrows x nGrps) group numbers for each class Factor
% X=Lignine_Starch_smooth_Balanced;

% Plots=0;
% GrpsCritNum=Grps;

% [nXrows,nXcols]=size(X);
% [nXrows, nGrpCrits]=size(GrpsCritNum);
% nDims=8;

%% "ANOVA" decomposition
clear Y Deflater Deflate X_red X_r Grps;

%% Center by Rows
% Remove mean
col=1;
% col1=mean each column
% === column center data
Y{1,col}=ones(nXrows,1); %(40,1)

Deflater{col}=(Y{1,col}'*X)/(sum(Y{1,col})); % (1,260)
Deflate{1,col}=Y{1,col}*Deflater{col}; % (40,260)
X_red{col}=X-Deflate{1,col};

titre{col}='Column means' ;

if Plots==3
    Figure_DNR(1);

    subplot(3,1,1);
    plot(X'), axis tight;
    title(['Before ', titre{col},' removed']);
    subplot(3,1,2);
    plot(Deflate{1,col}'), axis tight;
    title(titre{col});
    subplot(3,1,3);
    plot(X_red{col}'), axis tight;
    title(['After ', titre{col},' removed']);
end

%% Main factor Effects

for i=1:nGrpCrits

    col=col+1;
%     NumGrps=max(GrpsCritNum(:,i));
    NumGrps=size(unique(GrpsCritNum(:,i)),1);
    Y{1,col}=y2Grps(GrpsCritNum(:,i));
    Grps(:,col-1)=Grps2y(Y{1,col});
    % Grps===vector of levels for Factor i
    % Leave out col1
    % col=i

    Deflate{1,col}=0;
    for j=1:NumGrps
        Deflater{1,col}(j,:)=(Y{1,col}(:,j)'*X_red{col-1})/(sum(Y{1,col}(:,j))); % (1,260)
        Deflate{1,col}=Deflate{1,col}+Y{1,col}(:,j)*Deflater{1,col}(j,:); % (40,260)
    end

    X_red{col}=X_red{col-1}-Deflate{1,col};
    % Deflate for each Factor i
    
    titre{col}=[num2str(i)] ;
    % col===i
    
    if Plots==3
        Figure_DNR(1);

        subplot(3,1,1);
        plot(X_red{col-1}'), axis tight;
        title(['Before Factor ', titre{col},' removed']);
        subplot(3,1,2);
        plot(Deflate{1,col}'), axis tight;
        title(['Means for Factor ', titre{col}]);
        subplot(3,1,3);
        plot(X_red{col}'), axis tight;
        title(['After Factor ', titre{col},' removed']);
    end

end


%% 2 factor Interactions

for i=1:nGrpCrits
    for ii=i+1:nGrpCrits
        % Variable to combine the Factors
        col=col+1;

        kkk=0;
        c1=size(Y{1,i+1},2);
        c2=size(Y{1,ii+1},2);
        for k=1:c1
            for kk=1:c2
                kkk=kkk+1;
                Y{1,col}(:,kkk)=Y{1,i+1}(:,k).*Y{1,ii+1}(:,kk);

            end
        end
        Grps(:,col-1)=Grps2y(Y{1,col});
        % Neglect col1 in Grps
        
        NumGrps=size(Y{1,col},2);
        Deflate{1,col}=0;
        for j=1:NumGrps
            Deflater{1,col}(j,:)=(Y{1,col}(:,j)'*X_red{col-1})/(sum(Y{1,col}(:,j))); % (1,260)
            Deflate{1,col}=Deflate{1,col}+Y{1,col}(:,j)*Deflater{1,col}(j,:); % (40,260)
        end

        X_red{col}=X_red{col-1}-Deflate{1,col};

        titre{col}=[num2str(i),'x',num2str(ii)] ;

        if Plots==3
            Figure_DNR(1);

            subplot(3,1,1);
            plot(X_red{col-1}'), axis tight;
            title(['Before Factor ', titre{col},' removed']);
            subplot(3,1,2);
            plot(Deflate{1,col}'), axis tight;
            title(['Means for Factor ', titre{col}]);
            subplot(3,1,3);
            plot(X_red{col}'), axis tight;
            title(['After Factor ', titre{col},' removed']);
        end
    end
end


%% 3 factor Interactions

for i=1:nGrpCrits
    for ii=i+1:nGrpCrits
        for iii=ii+1:nGrpCrits
            % Variable to combine the Factors
            col=col+1;

            kkkk=0;
            c1=size(Y{1,i+1},2);
            c2=size(Y{1,ii+1},2);
            c3=size(Y{1,iii+1},2);
            for k=1:c1
                for kk=1:c2
                    for kkk=1:c3
                        kkkk=kkkk+1;
                        Y{1,col}(:,kkkk)=Y{1,i+1}(:,k).*Y{1,ii+1}(:,kk).*Y{1,iii+1}(:,kkk);
                    end
                end
            end
            Grps(:,col-1)=Grps2y(Y{1,col});

            NumGrps=size(Y{1,col},2);
            
            Deflate{1,col}=0;
            for j=1:NumGrps
                Deflater{1,col}(j,:)=(Y{1,col}(:,j)'*X_red{col-1})/(sum(Y{1,col}(:,j))); % (1,260)
                Deflate{1,col}=Deflate{1,col}+Y{1,col}(:,j)*Deflater{1,col}(j,:); % (40,260)
            end

            X_red{col}=X_red{col-1}-Deflate{1,col};

            titre{col}=[num2str(i),'x',num2str(ii),'x',num2str(iii)] ;

            if Plots==3
                Figure_DNR(1);

                subplot(3,1,1);
                plot(X_red{col-1}'), axis tight;
                title(['Before Factor ', titre{col},' removed']);
                subplot(3,1,2);
                plot(Deflate{1,col}'), axis tight;
                title(['Means for Factor ', titre{col}]);
                subplot(3,1,3);
                plot(X_red{col}'), axis tight;
                title(['After Factor ', titre{col},' removed']);
            end
        end
    end
end

%% Residuals
titre{col+1}=['Res'] ;
% titre(col-1)=== name of Factor in Deflate{1,col}

%% Number of tables
NumTab=size(X_red,2);

% if NumTab>nDims
%     nDims=NumTab;
% end

%% Means + residuals
clear X_r ;
% For Lignin :
% Deflate{1,1}== column means
% Deflate{1,2}== F1 means
% Deflate{1,3}== F2 means
% Deflate{1,4}== F3 means
% Deflate{1,5}== F1*F2 means
% Deflate{1,6}== F1*F3 means
% Deflate{1,7}== F2*F3 means
% Deflate{1,8}== F1*F2*F3 means

% X_red{1,1}== X-column means
% X_red{1,2}== X_red{1,1}-F1 means
% X_red{1,3}== X_red{1,2}-F2 means
% X_red{1,4}== X_red{1,3}-F3 means
% X_red{1,5}== X_red{1,4}-F1*F2 means
% X_red{1,6}== X_red{1,5}-F1*F3 means
% X_red{1,7}== X_red{1,6}-F2*F3 means
% X_red{1,8}== X_red{1,7}-F1*F2*F3 means

for i=1:NumTab-1 
    % From col2 to col before Residuals
    % Neglecting col1 (column means)
    X_r{1,i}=Deflate{1,i+1}+X_red{1,NumTab};
    % Add residuals to each matrix of Factor means
end;

% Just residuals in last table
X_r(1,NumTab)=X_red(1,NumTab);

%% Prepare dataset for ComDim
clear collection;

for i=1:NumTab
    collection(i).v=[1:nXcols];
    collection(1).i=[1:nXrows];
    collection(i).d=X_r{1,i};
end;


%%
clear A_ComDimIn;

A_ComDimIn.X=X;
A_ComDimIn.Grps=Grps;

A_ComDimIn.X_mean=Deflater;
A_ComDimIn.X_i=Deflate;
A_ComDimIn.X_r=X_r;
A_ComDimIn.Titre=titre;
    

%% ComDim
clear ComDimResult A_Collection;

Options.ndim=nDims;
Options.Output='TPL';

% [ComDimResult]=comdim_calib_V7(collection,Options);
[ComDimResult]=comdim_PCA_2019(collection,Options);

A_Collection=collection;

%%
for i=1:nDims
    A_ComDimOut{i}.ComDimQ=ComDimResult.Q.d(:,i);
    A_ComDimOut{i}.ComDimSalience=ComDimResult.saliences.d(:,i);

    [maxSalience,IndSalience]=max(ComDimResult.saliences.d(:,i));
    U=inv(A_ComDimOut{1,i}.ComDimQ(:,1)'*A_ComDimOut{1,i}.ComDimQ(:,1))*A_ComDimOut{1,i}.ComDimQ(:,1)';

    %     if size(X,2)==1
    %         A_ComDimOut{i}.ComDim_Lx=U*X_red{1,IndSalience}';
    %     else
    %         A_ComDimOut{i}.ComDim_Lx=U*X_red{1,IndSalience};
    %     end

    A_ComDimOut{i}.ComDim_Lx=U*X_red{1,IndSalience};

    A_ComDimOut{i}.ComDimExpl=ComDimResult.explained.d(:,i);

%     A_ComDimOut{i}.Sum_saliences_Tab=ComDimResult.Sum_saliences_Tab.d(:,i);

end;
% A_ComDimOut.Sum_saliences_Dim.d=ComDimResult.Sum_saliences_Dim.d;
% A_ComDimOut.Sum_saliences_Tab.d=ComDimResult.Sum_saliences_Tab.d;



%%
for i=1:nDims;
    [val,MaxTab(i)]=max(ComDimResult.saliences.d(:,i));
end;

%% Plot ComDim results
nCols=2;
if Plots>0
    Figs=double(floor((nDims+1)/nCols));

    Figure_DNR(1);
    for i=1:nDims;
        subplot(Figs,nCols,i);
        bar(ComDimResult.saliences.d(:,i),'r','BarWidth',0.2), axis tight;
%         stem(ComDimResult.saliences.d(:,i),'MarkerSize',5), axis tight;
%         set(gca,'XTick',[1:size(ComDimResult.saliences.d,1)]);
%         set(gca,'XTickLabel',titre(2:end));
        set(gca,'XTickLabel',[]);
        temp=xlim;
        temp(1,1)=0;
        xlim(temp)
        if MaxTab(i)<NumTab
            title(['Salience CC', num2str(i) ' Factor ' titre{MaxTab(i)+1}]);
        end;
    end;

    Figure_DNR(1);
    for i=1:nDims;
        subplot(Figs,nCols,i);
        plot(ComDimResult.Q.d(:,i),'b-'), axis tight;
        if MaxTab(i)<NumTab
            hold on;
            scatter([1:nXrows],ComDimResult.Q.d(:,i),20,Grps(:,MaxTab(i)),'Filled');
%             text([1:nXrows],ComDimResult.Q.d(:,i),num2str(Grps(:,MaxTab(i))));
        end;

        if MaxTab(i)<NumTab
            title(['Scores CC' num2str(i) ' Factor ' titre{MaxTab(i)+1}]);
        end;
    end;

    Figure_DNR(1);
    for i=1:nDims;
        subplot(Figs,nCols,i);
%         bar(A_ComDimOut{i}.ComDim_Lx), axis tight;
        stem(A_ComDimOut{i}.ComDim_Lx,'MarkerSize',2), axis tight;
        if MaxTab(i)<NumTab
            title(['Loadings CC' num2str(i) ' Factor ' titre{MaxTab(i)+1}]);
        end;
    end;

    Figure_DNR(1);
    subplot(1,3,1);
    plot(ComDimResult.explained.d,':s'), axis tight;
    xlabel('Dims');
    ylabel('Variance');
    subplot(1,3,2);
    plot(ComDimResult.Sum_saliences_Dim.d,':s'), axis tight;
    xlabel('Dims');
    ylabel('Sum Saliences');
    subplot(1,3,3);
    bar(ComDimResult.Sum_saliences_Tab.d'), axis tight;
    xlabel('Tables');
    ylabel('Sum Saliences');

end

%% Plot ComDim
if Plots>1
    for i=1:nDims;
        if MaxTab(i)<NumTab
            Figure_DNR(1);

            if PlotSamples==0
                ANOVAPCAmegX_Ellipse_no_text_sample([ComDimResult.Q.d(:,i),ComDimResult.Q.d(:,1)],Grps(:,MaxTab(i)),0.05,1,2);
            elseif PlotSamples==1;
                ANOVAPCAmegX_Ellipse([ComDimResult.Q.d(:,i),ComDimResult.Q.d(:,1)],Grps(:,MaxTab(i)),0.05,1,2);
            end

            title(['Factor ' titre{MaxTab(i)+1}]);
            xlabel(['CC' num2str(i),' / SumSal= ',num2str(ComDimResult.Sum_saliences_Dim.d(1,i))]);
            ylabel(['CC' num2str(1),' / SumSal= ',num2str(ComDimResult.Sum_saliences_Dim.d(1,1))]);
%             ylabel('CC1');
        end;
    end;
end

%% Calculate F from Saliences
for i=nDims:-1:1;
    Fup=ones(NumTab,1)*ComDimResult.saliences.d(NumTab,i);
    Fdown=ComDimResult.saliences.d(:,i);

    F1=Fup./Fdown;

    A_ComDimOut{i}.F1=F1;
end


% for i=nDims:-1:1;
% 
%     Fup=1-ones(NumTab,1)*ComDimResult.saliences.d(NumTab,i);
%     Fdown=1-ComDimResult.saliences.d(:,i);
%     F1=sqrt(Fdown./Fup);
% 
%     A_ComDimOut{i}.F1=F1;
% end


% Sum saliences of all CCs that have max salience for Residues
% [C,I]=max(ComDimResult.saliences.d);
% SumSalResidues=sum(C(:,I==NumTab));
% 
% for i=nDims:-1:1;
%     Fup=ones(NumTab,1)*SumSalResidues;
%     Fdown=ComDimResult.saliences.d(:,i);
% 
%     F1=Fup./Fdown;
% 
%     A_ComDimOut{i}.F1=F1;
% end

%% Plot F
if Plots>0
    Figure_DNR(1);

    % axes('YScale','log','YMinorTick','on');
    axes('YMinorTick','on');
    bar(F1(:,1),'r'), axis tight;
    set(gca,'XTick',[1:size(F1,1)]);
    set(gca,'XTickLabel',titre(2:end));

    title('F* based on Salience ratios');
    ylabel('F*');
    xlabel('Factor');
end

