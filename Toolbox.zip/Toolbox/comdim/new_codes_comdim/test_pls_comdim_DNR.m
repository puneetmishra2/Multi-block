clear all

load('test_pls_comdim.mat')



%%
addpath([pwd '/forjm']);
nB = 2;

BlockName = [];
for i=1:nB
    collection(i).d = eval(['xc' num2str(i)]);
    Samples_Nums = (1:size(collection(i).d,1))';
    Var_Nums = (1:size(collection(i).d,2));
    collection(i).v = Var_Nums;
    collection(i).i = Samples_Nums;
    BlockName=[BlockName;['X' num2str(i)]];
    clear Var_Nums
end

%%
% options and setting
CDs = 20;
% Number of Common Components
Options.ndim =CDs;
% Normalise each data table
Options.normalise =1;
% No comments during calculations
Options.loquace =0;
% Output Local Scores, Scaled and Unscaled Loadings
Options.Output='TPL';
% for 'Wide' & 'Tall'
% Not necessary since Options.CompMethod = 'Normal';
% % % % Options.Partitions = 3; 

Options.SortICs =0; % for ICA
Options.CompMethod = 'Normal';

%%
ComDim_Res = comdim_PLS_2020(collection,yc, Options);

%% I have a problem with crossval

% scores = ComDim_Res.Q.d;
% 
% for j=1:20
%     [~,~,rmsecv,rmsec,~,~] = crossval(scores(:,1:j),yc,'mlr',{'vet',5});
%     error(1,j) = mean(rmsec);
%     error(2,j) = mean(rmsecv);
%     clear rmsec rmsecv
% end
% 
% figure,
% plot(1:20,error);
% xlabel('Number of component');
% ylabel('Error');
% legend('RMSEC','RMSECV');

%% above plot will show around 5 lvs, so optimal MLR model is made

% mdl = fitlm(scores(:,1:6),yc);

%% to test the model in new data

BlockName = [];
for i=1:nB
    collection_T(i).d = eval(['xt' num2str(i)]);
    Samples_Nums = (1:size(collection_T(i).d,1))';
    Var_Nums = (1:size(collection_T(i).d,2));
    collection_T(i).v = Var_Nums;
    collection_T(i).i = Samples_Nums;
    BlockName=[BlockName;['X' num2str(i)]];
    clear Var_Nums
end

%% DNR testing things
% predicting scores with comdim for test data
res_pred_2019 =comdim_pred_2019(ComDim_Res, collection_T);
res_pred_MdF =comdim_pred_V8_MdF(ComDim_Res, collection_T);

calib_scores_Q = ComDim_Res.Q.d;
calib_scores_Q = calib_scores_Q(:,1:6); % selected from the cross-validation

test_scores_2019 = res_pred_2019.U.d;
test_scores_2019 = test_scores_2019(:,1:6); % selected from the cross-validation

test_scores_MdF = res_pred_MdF.U.d;
test_scores_MdF = test_scores_MdF(:,1:6); % selected from the cross-validation

%% Plot _2019 vs Q
%Figure_DNR(1);
figure,
for i=1:6
    rapport(:,i)=calib_scores_Q(:,i)./test_scores_2019(:,i);
    subplot(2,3,i);
    plot(calib_scores_Q(:,i),test_scores_2019(:,i),'.'),axis tight;
%     plot(rapport(:,i),'.'),axis tight;
    title(i);
end

%% Plot _2019 vs _MdF
figure,
for i=1:6
    rapport(:,i)=test_scores_MdF(:,i)./test_scores_2019(:,i);
    subplot(2,3,i);
    plot(test_scores_2019(:,i),test_scores_MdF(:,i),'.'),axis tight;
%     plot(rapport(:,i),'.'),axis tight;
    title(i);
end



%% Plot X using rapport
% All_xc=[xc1,xc2];
% [nR,nC]=size(All_xc);
% for i=1:6
%     Couleurs=repmat(rapport(:,i),1,nC);
%     Figure_DNR(1);
%     for j=1:nR
%         scatter([1:nC],All_xc(j,:),3,Couleurs(j,:),'Filled'),axis tight;
%         hold on;
%     end
%     title(i);
% end


%% predicting scores with comdim for test data
% res_pred_V8 =comdim_pred_2019(ComDim_Res, collection_T);

test_scores = res_pred_V8.U.d;
test_scores = test_scores(:,1:6); % selected from the cross-validation

%% apply the MLR model mdl and statistics

test_pred = predict(mdl,test_scores);

%%
%statistics
SST=sum((yt-mean(yt)).^2); 
SSE=sum((yt-test_pred).^2); 
R2_P=1-SSE/SST;
RMSEP=sqrt(SSE/size(test_scores,1));

%plot
figure,
plot(yt,test_pred,'.b','MarkerSize',20);
set(gca,'FontSize',14,'FontWeight','bold');
lsline
xlabel('Measured','FontWeight','bold','FontSize',14);
ylabel('Predicted','FontWeight','bold','FontSize',14);
title(['R^2c = ' num2str(R2_P) ' RMSEC = ' num2str(RMSEP)],'FontWeight','bold','FontSize',14);