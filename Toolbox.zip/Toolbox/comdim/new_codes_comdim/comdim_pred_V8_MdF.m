function [res_pred]=comdim_pred_V8_MdF(comdim_calib, col_pred)
%comdim_pred_V7 - Finding common dimensions in multitable data (saisir format)
%
% USAGE :
%---------------
% [res_pred]=comdim_pred_V8_MdF(col_calib, col_pred,(threshold))
%
% INPUT :
%---------------
% comdim_calib : results of calibration using ComDim
% col_pred : vector of saisir files (the numbers "nrow" of rows in each table must be equal).
% threshold (optional): if the "difference of fit"<threshold then break the
% iterative loop
%
%
% OUTPUT :
%-----------------
% res_pred with fields:
% T : Local scores_pred calculated from concatenated Loadings and tables (nrow x ndim)
% U : Orthonormal Global scores_pred calculated from concatenated T (nrow x ndim)
%
% CALLS:
%-----------------
% No external function
%
% REFERENCE :
%-----------------
%Method published by:
% E.M. Qannari, I. Wakeling, P. Courcoux and H. J. H. MacFie
% in Food quality and Preference 11 (2000) 151-154
%
% EXAMPLE :
%-----------------
% (suppose 3 SAISIR matrices "spectra1","spectra2","spectra3")
% And the output of a ComDim calibration  "comdim_calib"
%
% col_pred(1)=spectra1; col_pred(2)=spectra2; col_pred(3)=spectra3
%
% [res_pred]=comdim_pred_V7(comdim_calib, col_pred);
%

ntable_calib=size(comdim_calib.saliences.d,1);
ntable_pred=size(col_pred,2);

if(ntable_pred~=ntable_calib)
    error('The number of data tables in prediction set must be the same as in the calibration set !!!');
end

%%
ndim=size(comdim_calib.Q.d,2);

DimLabels=[repmat('D',ndim,1),num2str([1:ndim]'),repmat(' ',ndim,6)];
DimLabels=DimLabels(:,1:6);

TableLabels=[repmat('t',ntable_pred,1),num2str([1:ntable_pred]'),repmat(' ',ntable_pred,6)];
TableLabels=TableLabels(:,1:6);

%% Calculate Normalised concatenated Xs ('Pred') from col_pred
npred= size(col_pred(1,1).d,1);

%%% DNR :  
% % Using MEAN & NORM of calibration set
% % Centrage et normalisation tables 'prediction' (col_pred)
% Pred=[];
% temp_tabpred=[];
% for j=1:ntable_pred
%     temp_tabpred(j).d= col_pred(j).d-ones(npred,1)*comdim_calib.MEAN(j).d;
%     temp_tabpred(j).d= temp_tabpred(j).d/comdim_calib.NORM.d(:,j);
%     
%     Pred=[Pred,temp_tabpred(j).d];
% end
% clear j ;

%%%% MdF
% Using MEAN & NORM of test set
% Centrage et normalisation tables 'prediction' (col_pred)
for j=1:ntable_pred
    [temp_tabpred(j).d, Norm(j).d, Mean(j).d]=Normalise_DB(col_pred(j).d); % MS
end

%%%%

CCs=size(comdim_calib.Q.d,2); % extracts the number of CCs from comdim input model
P=comdim_calib.P.d; % extracts global loadings from comdim input model
Ploc=comdim_calib.P_Loc.d; % extracts local loadings from comdim input model

U.d=zeros(npred,CCs); % allocates space for prediction global scores
T=cell(1,ntable_pred); % allocates space for predictionn local scores
Xw=cell(1,ntable_pred); % allocates space for the saliences-weighted input Xs

Xs=squeeze(struct2cell(temp_tabpred))'; % converts input collection from structure to cells

for j=1:CCs % main loop to extract CCs
    
    for i=1:ntable_pred % loops over tables
        Xw{1,i}=comdim_calib.saliences.d(i,j)*Xs{1,i}; % weights Xs with saliences
    end

% MdF    
% Concatenate the weighted tables
% And multiply by Loadings to get scores
    U.d(:,j)=cat(2,Xw{:})*P(:,j)*pinv(P(:,j)'*P(:,j)); % calculates the global scores
    U.d(:,j)=U.d(:,j)/sqrt(U.d(:,j)'*U.d(:,j)); % standardizes the global scores
    
    for i=1:ntable_pred
        T{1,i}(:,j)=Xs{1,i}*Ploc{1,i}(:,j)*pinv(Ploc{1,i}(:,j)'*Ploc{1,i}(:,j)); % caluclates local scores with the unweighted Xs
        Xs{1,i}=Xs{1,i}-(U.d(:,j)*Ploc{1,i}(:,j)'); % iteratively deflates the Xs after each CC extraction
    end

end

U.i=[1:npred]';% sample numbers
U.v=DimLabels;% dimensions

clear QQ

res_pred.U=U;

res_pred.T.d=T;
res_pred.T.i=U.i;% samples
res_pred.T.v=U.v;% dimensions

return

% figure('Numbertitle','Off','Name','Global prediction scores')
% for i=1:ndim
%     if ndim==2
%         subplot(2,1,i)
%     elseif or(ndim==3,ndim==4)
%         subplot(2,2,i)
%     elseif or(ndim==5,ndim==6)
%         subplot(3,2,i)
%     elseif or(ndim==7,ndim==8,ndim==9)
%         subplot(3,3,i)
%     end
%     plot(U.d(:,i),comdim_calib.Q.d(:,i),'.')
%     axis tight
%     xlabel('U')
%     ylabel('Q')
%     title(i)
% end
% shg
% 
% for j=1:ntable_pred
%     figure('Numbertitle','Off','Name',['Local prediction scores for Table ',int2str(j)])
%     for i=1:ndim
%         if ndim==2
%             subplot(2,1,i)
%         elseif or(ndim==3,ndim==4)
%             subplot(2,2,i)
%         elseif or(ndim==5,ndim==6)
%             subplot(3,2,i)
%         elseif or(ndim==7,ndim==8,ndim==9)
%             subplot(3,3,i)
%         end
%         plot(T{j}(:,i),comdim_calib.T.d{j}(:,i),'.')
%         axis tight
%         title(i)
%     end
% end
% shg