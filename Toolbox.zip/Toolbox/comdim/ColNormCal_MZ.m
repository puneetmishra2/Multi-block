function [X_Normed, Norm_X, mX] = ColNormCal_MZ(X0c);
% For calibration set

[n0c,p]=size(X0c);

% Column center
mX = mean(X0c);
X_Cent = X0c - ones(n0c,1) * mX;

XX=X_Cent.*X_Cent;

% Column normalize
Norm_X=sqrt(sum(XX));

X_Normed=X_Cent./(ones(n0c,1) * Norm_X);
    







