function [res_calib]=CCA_DNR(X, Options);
%comdim			- Finding common dimensions in multitable data (saisir format)
%
% USAGE :
%---------------
% [res_calib]=CCA_DNR(X, Options);
%
% INPUT :
%---------------
% X : X data matrix (nrow,ncols)
% ntable=ncols
%
% Options :
% Options.ndim : Number of common dimensions
% Options.normalise : 0== no; 1== yes (default)
% Options.threshold : If the "difference of fit" < threshold
% then break the iterative loop 
% Options.loquace : 1== displays calculation times; 0== no (default)
% Options.Output : To limit the number of extra parameters calculated

% To save time and memory
% 'Q' (Global Scores) and Statistics will always be output
%
% if Output=='A' or 'TPL' , all extra parameters are calculated
% if Output=='[]', no extra parameters are calculated

% 'T' : Local X Scores
% 'P' : Scaled Loadings
% 'L' : Unscaled Loadings

% Options.FileName : To save results for successive CCs to files
% if FileName=='Toto', then results saved to 'Toto_01', Toto_02', etc
%
% OUTPUT :
%-----------------
% res_calib with fields:
% Q : Global X scores (nrow x ndim)
% T : 3D array of Local X scores (nrow x ncols x ndim)
% calculated from ncols local Loadings (nrow x 1) and tables (nrow x ndim)
%
% P : Scaled Global loadings calculated from Q (nrow x ndim) and Scaled tables (nrow x ncols)
%    (ncols x ndim)
% Lx : Unscaled Global loadings calculated from Q (nrow x ndim) and Unscaled X (nrow x ncols)
%    (ncols x ndim)
%
% saliences : weight of the original tables in each dimension (ntable x ndim)
%
% Sum_saliences_Tab - Sum of Saliences for each Tab in a Dimension
% Sum_saliences_Dim - Sum of Saliences for each Dim for a Table
% Nu - Squared saliences/Sum of Squared saliences for each Table
% explained : percentage explanation given by each dimension (1 x ndim)
%
% NORM : ntable norms of the tables (1 x 1)
% MEAN : ntable means of tables (1 x nvars)
% 
% 
% SingVal : vector of singular values (1 x ndim)
% NOT YET PROGRAMMED
%
% CALLS:
%-----------------
% Normalise_DB
%
[nrow,ncols]=size(X);
Indivs=[1:nrow];
Vars=[1:ncols];

% 1 variable per table
ntable=ncols;

if(nargin<2)
    ndim=min(nrow,ncols);
    threshold=1E-10;
    FileName=[];
end;

if exist('Options','var')
    if isfield(Options,'ndim');
        ndim= Options.ndim;
    else
        ndim=min(nrow,ncols);
    end;

    if isfield(Options,'normalise');
        normalise= Options.normalise;
    else
        normalise=1;
    end;

    if isfield(Options,'threshold');
        threshold= Options.threshold;
        if size(threshold)==0
            threshold=1E-10;
            Options.threshold=threshold;
        end;
    else
        threshold=1E-6;
        Options.threshold=threshold;
    end;

    if isfield(Options,'Output');
        Output= Options.Output;
    else
        Output= 'TPL';
    end;
    if Output== 'A';
        Output= 'TPL';
    end;

    if isfield(Options,'FileName');
        FileName= Options.FileName;
    else
        FileName= [];
    end;

    if isfield(Options,'loquace');
        loquace= Options.loquace;
    else
        loquace= 0;
    end;

end

isT=((strfind(Output,'T')));
isL=((strfind(Output,'L')));
isP=((strfind(Output,'P')));
isTLP=[isT,isP,isL];


NoFile=isempty(FileName);

LAMBDA=zeros(ncols,ndim);

% Normalise blocks
if normalise==1
    [X_Normed, Norm.d, Mean.d] = ColNormCal_MZ(X);
    X_Normed=NaN2Mean(X_Normed);
    X_Normed=NaN2Mean(X_Normed')';
    
    res_calib.NORM.d= Norm.d;
    res_calib.MEAN.d= Mean.d;
else
    X_Normed=X;
end


[nR,nC]=size(X_Normed);

h1 = waitbar(0,'Doing ComDim...');

% main loop
unexplained=ncols; % Warning!: true only because the tables were set to norm=1

% Do ComDim
for dim=1:ndim
    tic
    waitbar(dim/ndim,h1,['CC : ', sprintf('%0.1u',dim) '/', sprintf('%0.1u',ndim)]);

    previousfit=10000;
    %step a
    lambda=ones(1,ncols);
    %step b
    deltafit=1000000;

    q_tmp=X_Normed(:,1); % 1.	Select a component q of unit length at random
    while(deltafit>threshold)

        q=0;
        for i=1:ncols
            qk(:,i)=X_Normed(:,i)*X_Normed(:,i)'*q_tmp; % 	Define the block components q^((k))=X_k.X_k^T.q
            lambda(1,i)=q_tmp'*qk(:,i); % 	Define the saliences as L_k=q^T.X_k.X_k^T.q
            q=q+lambda(1,i)*qk(:,i); % 4.	Update  q
        end

        q=q./norm(q); % 5.	Standardize q :
        q_tmp=q;

        fit=0;
        for i=1:ncols
            aux=X_Normed(:,i)*X_Normed(:,i)'-lambda(1,i)*q*q';
            fit=fit+sum(sum(aux.*aux));
        end
        deltafit=previousfit-fit;
        previousfit=fit;

    end %deltafit>threshold

    explained.d(dim)=(unexplained-fit)/ntable*100;
    unexplained=fit;

    saliences.d(:,dim)=lambda;
    Q.d(:,dim)=q;

    if  ~isempty(isT)
        T(:,:,dim)=qk;
    end

    % % %     SingVal(1,dim)=SW(1,1); % DB, 13.03.2014

    % Calculate Loadings & Deflate blocks
    aux=eye(nrow,nrow)-q*q';
    
    if  ~isempty(isP)
        P(:,dim)=X_Normed'*q;
    end

    if  ~isempty(isL)
        Lx(:,dim)=X'*q;
    end

    X_Normed=aux*X_Normed;
    
    duree=toc;
    if loquace==1
        disp(['Calculations CC ',num2str(dim),' finished after ',num2str(duree)]);
    end

end

close(h1);

for i=1:ndim
    chaine=['D' num2str(i) '        '];
    bid(i,:)=chaine(1:6);
end

Q.i=Indivs;
Q.v=Vars;

% Calculate Sum of saliences for each Table
Sum_saliences_Tab.d=sum(saliences.d,2)';
Sum_saliences_Dim.d=sum(saliences.d,1);

Nu.d=saliences.d.*saliences.d;
Nu.d=(Nu.d/sum(saliences.d.*saliences.d))';

%% Output

res_calib.Q=Q;
clear Q;

if  ~isempty(isT)
    res_calib.T.i=Indivs;% samples
    res_calib.T.v=Vars;% numbers of all variables;
    for i=1:ncols
        res_calib.T.d{i}=squeeze(T(:,i,:));
    end
    clear T;
    
end

if  ~isempty(isP)
    res_calib.P.i= Vars';% numbers of all variables;
    res_calib.P.v=bid;% dimension;
    res_calib.P.d= P;
    clear P;
end

if  ~isempty(isL)
    res_calib.Lx.i=Vars';% numbers of all variables;
    res_calib.Lx.v=bid;% dimension;
    res_calib.Lx.d= Lx;
    clear L;
end

res_calib.Xnorm_mat.d=X_Normed;
res_calib.Xnorm_mat.i=Indivs;
res_calib.Xnorm_mat.v=Vars;

% SingVal.i='Singular value';
% SingVal.v=bid;
% res_calib.SingVal=SingVal; % DB, 13.03.2014
% clear SingVal;

saliences.i=Vars;% tables
saliences.v=bid;% dimensions
res_calib.saliences=saliences;
clear saliences;

explained.i='% explained';
explained.v=bid;% dimensions
res_calib.explained=explained;
clear explained;

Sum_saliences_Dim.i='Sum Dim Saliences';
Sum_saliences_Dim.v='Dim';
res_calib.Sum_saliences_Dim=Sum_saliences_Dim;
clear Sum_saliences_Dim;

Sum_saliences_Tab.i='Sum Tab Saliences';
Sum_saliences_Tab.v='Tab';

res_calib.Sum_saliences_Tab=Sum_saliences_Tab;
clear Sum_saliences_Tab;

Nu.i='Nu';
Nu.v='Tab';

res_calib.Nu=Nu;
clear Nu;

    



