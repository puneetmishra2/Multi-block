function [res_pred]=comdim_pred_2020(comdim_calib, col_pred)
%comdim			- Finding common dimensions in multitable data (saisir format)
% function[res_pred]=comdim_pred_2019(col_calib, col_pred,(threshold))
%
%Input arguments:
%---------------
%comdim_calib : results of calibration ComDim 
%col_pred : vector of saisir files (the numbers "nrow" of rows in each table must be equal). 
%threshold (optional): if the "difference of fit"<threshold then break the
%iterative loop 
%
%Output arguments:
%-----------------
% res_pred with fields:
% T : Local scores_pred calculated from concatenated Loadings and tables (nrow x ndim)
% U : Orthonormal Global scores_pred calculated from concatenated T (nrow x ndim)
%
% Method published by  E.M. Qannari, I. Wakeling, P. Courcoux and H. J. H. MacFie
% in Food quality and Preference 11 (2000) 151-154
%
% Typical example
% (suppose 3 SAISIR matrices "spectra1","spectra2","spectra3")
% And the output of a calibration ComDim "comdim_calib"
%
% col_pred(1)=spectra1; col_pred(2)=spectra2; col_pred(3)=spectra3
%
% [res_pred]=comdim_pred_V6(comdim_calib, col_pred);
%
% map(comdim_calib.T,1,2);%% looking at the calculated global scores
% figure;
% map(res_pred.T,1,2);%% looking at the predicted global scores

ntable_calib=size(comdim_calib.saliences.d,1);
ntable_pred=size(col_pred,2);

if(ntable_pred~=ntable_calib)
   error('The number of data tables in prediction set must be the same as in the calibration set !!!');
end

%%
ndim=size(comdim_calib.Q.d,2);

DimLabels=[repmat('D',ndim,1),num2str([1:ndim]'),repmat(' ',ndim,6)];
DimLabels=DimLabels(:,1:6);

TableLabels=[repmat('t',ntable_pred,1),num2str([1:ntable_pred]'),repmat(' ',ntable_pred,6)];
TableLabels=TableLabels(:,1:6);


%% Calculate Normalised concatenated Xs ('Pred') from col_pred
% Centrage et Normalisation tables 'prediction' (col_pred)
npred= size(col_pred(1,1).d,1);

% %% DNR :  Pas bon !
% % % % % Using MEAN & NORM of calibration set
% % % % % Centrage et normalisation tables 'prediction' (col_pred)
% % % % for i=1:ntable_pred
% % % %     Xs{1,i}= col_pred(i).d-ones(npred,1)*comdim_calib.MEAN(i).d';
% % % %     Xs{1,i}= Xs{1,i}/comdim_calib.NORM.d(:,i);
% % % % end
%%%%

%%%% MdF Bon !!!
% % Xs{1,i}=col_pred(j).d;
% Using MEAN & NORM of test set
% Centrage et normalisation tables 'prediction' (col_pred)
for i=1:ntable_pred
    [Xs{1,i}, Norm.d(i), Mean(i).d]=Normalise_DB(col_pred(i).d); % MS
end
%%%%

%% Calculate new global scores_pred U
% Scaling 
% From new concatenated Xs and old Loadings
% CCs=ndim; % extracts the number of CCs from comdim input model
P=comdim_calib.P.d; % extracts global loadings from comdim input model
Ploc=comdim_calib.P_Loc.d; % extracts local loadings from comdim input model
saliences=comdim_calib.saliences.d;

% Q=U.d 
% Qloc=T.d
% Xw= saliences-weighted input Xs
% Xs{1,i}=temp_tabpred(i).d;

for j=1:ndim % main loop to extract CCs
    
    for i=1:ntable_pred % loops over tables
        Xw{1,i}=saliences(i,j)*Xs{1,i}; % weights Xs with saliences
    end
    
    Q(:,j)=cat(2,Xw{:})*P(:,j)/(P(:,j)'*P(:,j)); % calculates the global scores
    Q(:,j)=Q(:,j)/sqrt(Q(:,j)'*Q(:,j)); % standardizes the global scores
    
    for i=1:ntable_pred
        Qloc{1,i}(:,j)=Xs{1,i}*Ploc{1,i}(:,j)/(Ploc{1,i}(:,j)'*Ploc{1,i}(:,j)); % caluclates local scores with the unweighted Xs
        Xs{1,i}=Xs{1,i}-(Q(:,j)*Ploc{1,i}(:,j)'); % iteratively deflates the Xs after each CC extraction
    end

end

U.i=[1:npred]';% sample numbers
U.v=DimLabels;% dimensions
U.d=Q;% Global Scores
res_pred.U=U;

res_pred.T.d=Qloc;% Local Scores
res_pred.T.i=U.i;% samples
res_pred.T.v=U.v;% dimensions

return

