function [X_out]=NaN2Mean(X_in);

X_out=X_in;

tata=isnan(X_in);

%A = circshift(X_in',1)';
%B = circshift(X_in',-])';

A = circshift(X_in',[0 1])';
B = circshift(X_in',[0 -1])';

titi=A(tata);
tutu=B(tata);

if size(titi,1)==0
    % do nothing
else
    X_out(tata)=mean([titi, tutu],2);

end;



