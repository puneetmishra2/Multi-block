%%
% load ComDim_Reg_Puneet.mat;
% in
% F:\Stat_Math\NewThingsA_O\Multiblock\ComDim\A-ComDim

%% Data
[nR1,nC1]=size(X1);
SampleNums1=[1:nR1]';
VarNums1=[1:nC1];

[nR2,nC2]=size(X2);
SampleNums2=[1:nR2]';
VarNums2=[1:nC2];

[nR3,nC3]=size(Y);
SampleNums3=[1:nR3]';
VarNums3=[1:nC3];

%% Do ComDim_PLS_ICA on X
clear collection;

i=1;
collection(i).d=X1;
collection(i).v=VarNums1;
collection(i).i=SampleNums1;

i=2;
collection(i).d=X2;
collection(i).v=VarNums2;
collection(i).i=SampleNums2;

BlockName=[' X1';' X2'];

%%
[nCr,nCc]=size(collection);
Block_Nums=[1:nCc];

%% Plot Data by Segments
Figure_DNR(1);
set(gca,'FontSize',8)
for i=1:nCc
    subplot(1,2,i);
    plot(collection(i).d'),axis tight;
    tt=title(['Table ',num2str(i)]);
end
set(tt,'Fontsize',10), clear tt
shg


%% Do comdim_calib_...
CDs=4;
r=2;
c=2;

Options.ndim =CDs;
Options.normalise =1;
Options.loquace =0;
Options.Output='TPL';

Options.CompMethod='Normal';
Options.Method='Normal';



%%
[ComDim_Res_PLS_PCA]=comdim_PLS_2020(collection, Y, Options);
disp('ComDim_PLS_PCA with 4 CDs');
disp('                ');

%% Qs
Figure_DNR(1);
for i=1:CDs
    subplot(r,c,i);
    plot(SampleNums1,ComDim_Res_PLS_PCA.Q.d(:,i),'r:'), axis tight;
    hold on;
    scatter(SampleNums1,ComDim_Res_PLS_PCA.Q.d(:,i),40,Y,'Filled'), axis tight;
    xlabel('Samples');
    ylabel(['CC ',num2str(i)]);
end
suptitle('Global Scores for ComDim-PLS-PCA');

%% Qs
Figure_DNR(1);
for i=1:CDs
    subplot(r,c,i);
    plot(Y,ComDim_Res_PLS_PCA.Q.d(:,i),'r:'), axis tight;
    hold on;
    scatter(Y,ComDim_Res_PLS_PCA.Q.d(:,i),40,Y,'Filled'), axis tight;
    xlabel('Y');
    ylabel(['CC ',num2str(i)]);
end
suptitle('Global Scores for ComDim-PLS-PCA');


%% Ps
Figure_DNR(1);
for i=1:CDs
    subplot(r,c,i);
    plot(ComDim_Res_PLS_PCA.P.d(:,i),'r'), axis tight;
    yy=get(gca,'YLim');
    ylabel(['CC ',num2str(i)]);
end
suptitle('Scaled Loadings for ComDim-PLS-PCA');

%% Lxs
Figure_DNR(1);
for i=1:CDs
    subplot(r,c,i);
    plot(ComDim_Res_PLS_PCA.Lx.d(:,i),'r'), axis tight;
    yy=get(gca,'YLim');
    ylabel(['CC ',num2str(i)]);
end
suptitle('Unscaled Loadings for ComDim-PLS-PCA');

%% Saliences
Sum_Sal_Dim=ComDim_Res_PLS_PCA.Sum_saliences_Dim.d;
Figure_DNR(1);
for i=1:CDs
    subplot(r,c,i);
    bar(ComDim_Res_PLS_PCA.saliences.d(:,i),'r'), axis tight;
    ylabel(['CC ',num2str(i)]);
    title(['Sum Sal. =', num2str(Sum_Sal_Dim(1,i))]);
end

%% Saliences
Sum_Sal_Tab=ComDim_Res_PLS_PCA.Sum_saliences_Tab.d;
Figure_DNR(1);
bar(Sum_Sal_Tab,'r'), axis tight;
xlabel('Blocks');
suptitle('Saliences');

%% Variances
Figure_DNR(1);
bar(ComDim_Res_PLS_PCA.explained.d,'r'), axis tight;
xlabel('Components');
suptitle('Variance');



%%
[ComDim_Res_PLS_ICA]=comdim_PLS_ICA_2019(collection, Y, Options);
disp('ComDim_PLS_ICA with 4 CDs');
disp('                ');

%% Qs
Figure_DNR(1);
for i=1:CDs
    subplot(r,c,i);
    plot(SampleNums1,ComDim_Res_PLS_ICA.Q.d(:,i),'r:'), axis tight;
    hold on;
    scatter(SampleNums1,ComDim_Res_PLS_ICA.Q.d(:,i),40,Y,'Filled'), axis tight;
    xlabel('Samples');
    ylabel(['CC ',num2str(i)]);
end
suptitle('Global Scores for ComDim-PLS-ICA');

%% Qs
Figure_DNR(1);
for i=1:CDs
    subplot(r,c,i);
    plot(Y,ComDim_Res_PLS_ICA.Q.d(:,i),'r:'), axis tight;
    hold on;
    scatter(Y,ComDim_Res_PLS_ICA.Q.d(:,i),40,Y,'Filled'), axis tight;
    xlabel('Y');
    ylabel(['CC ',num2str(i)]);
end
suptitle('Global Scores for ComDim-PLS-ICA');

%% Ps
Figure_DNR(1);
for i=1:CDs
    subplot(r,c,i);
    plot(ComDim_Res_PLS_ICA.P.d(:,i),'r'), axis tight;
    yy=get(gca,'YLim');
    ylabel(['CC ',num2str(i)]);
end
suptitle('Scaled Loadings for ComDim-PLS-ICA');

%% Lxs
Figure_DNR(1);
for i=1:CDs
    subplot(r,c,i);
    plot(ComDim_Res_PLS_ICA.Lx.d(:,i),'r'), axis tight;
    yy=get(gca,'YLim');
    ylabel(['CC ',num2str(i)]);
end
suptitle('Unscaled Loadings for ComDim-PLS-ICA');

%% Saliences
Sum_Sal_Dim=ComDim_Res_PLS_ICA.Sum_saliences_Dim.d;
Figure_DNR(1);
for i=1:CDs
    subplot(r,c,i);
    bar(ComDim_Res_PLS_ICA.saliences.d(:,i),'r'), axis tight;
    ylabel(['CC ',num2str(i)]);
    title(['Sum Sal. =', num2str(Sum_Sal_Dim(1,i))]);
end

%% Saliences
Sum_Sal_Tab=ComDim_Res_PLS_ICA.Sum_saliences_Tab.d;
Figure_DNR(1);
bar(Sum_Sal_Tab,'r'), axis tight;
xlabel('Blocks');
suptitle('Saliences');

%% Variances
Figure_DNR(1);
bar(ComDim_Res_PLS_ICA.explained.d,'r'), axis tight;
xlabel('Components');
suptitle('Variance');

