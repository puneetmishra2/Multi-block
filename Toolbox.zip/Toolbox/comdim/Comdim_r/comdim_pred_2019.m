function [res_pred]=comdim_pred_2019(comdim_calib, col_pred)
%comdim			- Finding common dimensions in multitable data (saisir format)
% function[res_pred]=comdim_pred_2019(col_calib, col_pred,(threshold))
%
%Input arguments:
%---------------
%comdim_calib : results of calibration ComDim 
%col_pred : vector of saisir files (the numbers "nrow" of rows in each table must be equal). 
%threshold (optional): if the "difference of fit"<threshold then break the
%iterative loop 
%
%Output arguments:
%-----------------
% res_pred with fields:
% T : Local scores_pred calculated from concatenated Loadings and tables (nrow x ndim)
% U : Orthonormal Global scores_pred calculated from concatenated T (nrow x ndim)
%
% Method published by  E.M. Qannari, I. Wakeling, P. Courcoux and H. J. H. MacFie
% in Food quality and Preference 11 (2000) 151-154
%
% Typical example
% (suppose 3 SAISIR matrices "spectra1","spectra2","spectra3")
% And the output of a calibration ComDim "comdim_calib"
%
% col_pred(1)=spectra1; col_pred(2)=spectra2; col_pred(3)=spectra3
%
% [res_pred]=comdim_pred_V6(comdim_calib, col_pred);
%
% map(comdim_calib.T,1,2);%% looking at the calculated global scores
% figure;
% map(res_pred.T,1,2);%% looking at the predicted global scores

ntable_calib=size(comdim_calib.saliences.d,1);
ntable_pred=size(col_pred,2);

if(ntable_pred~=ntable_calib)
   error('The number of data tables in prediction set must be the same as in the calibration set !!!');
end

%%
ndim=size(comdim_calib.Q.d,2);
for i=1:ndim
   chaine=['D' num2str(i) '        '];
   bid(i,:)=chaine(1:6);
end

for i=1:ntable_pred
   chaine1=['t' num2str(i) '        '];
   bid1(i,:)=chaine1(1:6);
end

%% Calculate Normalised concatenated Xs ('Pred') from col_pred
% Centrage et Normalisation tables 'prediction' (col_pred)
npred= size(col_pred(1,1).d,1);

temp_tabpred=[];
for j=1:ntable_pred
    %%%%  New formats for MEAN & NORM   
    temp_tabpred(j).d= col_pred(j).d-ones(npred,1)*comdim_calib.MEAN(j).d';
    temp_tabpred(j).d= temp_tabpred(j).d/comdim_calib.NORM.d(:,j);
end

%% Calculate new global scores_pred U
% From new concatenated Xs and old Loadings
% Scaling Necessary !

for j=1:ndim
    T_mat=[];
    for i=1:ntable_pred
        % Scores locaux 'T{i}(:,j)' pour chaque tab (i) et chaque dim (j)
        % avec 'calib.P' et 'temp_tabpred'
        T{i}(:,j)=temp_tabpred(i).d*comdim_calib.P_Loc.d{1,i}(:,j)*inv(comdim_calib.P_Loc.d{1,i}(:,j)'*comdim_calib.P_Loc.d{1,i}(:,j));

            T_mat=[T_mat,T{i}(:,j)]; % Scores "locaux"];
%         T_pred{j}(:,i)=T{i}(:,j);
       
        
        % Pour chaque dim (j), calculer 'sumpred' sur tous les tab (i)
        % avec 'comdim_calib.saliences.d(i,j)' et 'temp_tabpred(i).d'
        % Commme comdim_calib.saliences.d(i,j)*Xi*Xi'
        % == somme des X*X' pred, pond�r�s par les saliences calib
        
        % Pour chaque dim (j), deflate tous les 'temp_tabpred(i).d' 
        % avec 'comdim_calib.Q(:,j)' et 'temp_tabpred(i).d'
        % Comme Xi=Xi-calib.Q*calib.Q'*Xi == Xi(I-calib.Q*calib.Q')
        temp_tabpred(i).d=temp_tabpred(i).d-comdim_calib.Q.d(:,j)*comdim_calib.Q.d(:,j)'*temp_tabpred(i).d;
        
    end
    
    %%%%% Use b-coefficient from comdim_calib
    %%%%% to calculate Global Scores from Local Scores
%     U.d(:,j)=T_pred{j}*comdim_calib.b.d(:,j);
    U.d(:,j)=T_mat*comdim_calib.b.d(:,j);
end

U.i=[1:npred]';% sample numbers
U.v=bid;% dimensions

res_pred.U=U;

res_pred.T.d=T;
res_pred.T.i=U.i;% samples
res_pred.T.v=U.v;% dimensions


return

%% For testing
% figure('Numbertitle','Off','Name','Global prediction scores')
% for i=1:ndim
%     if ndim==2
%         subplot(2,1,i)
%     elseif or(ndim==3,ndim==4)
%         subplot(2,2,i)
%     elseif or(ndim==5,ndim==6)
%         subplot(3,2,i)
%     elseif or(ndim==7,ndim==8,ndim==9)
%         subplot(3,3,i)
%     end
%     plot(U.d(:,i),comdim_calib.Q.d(:,i),'.')
%     axis tight
%     xlabel('U')
%     ylabel('Q')
%     title(i)
% end
% shg

%% For testing
for j=1:ntable_pred
    figure('Numbertitle','Off','Name',['Local prediction scores for Table ',int2str(j)])
    for i=1:ndim
        if ndim==2
            subplot(2,1,i)
        elseif or(ndim==3,ndim==4)
            subplot(2,2,i)
        elseif or(ndim==5,ndim==6)
            subplot(3,2,i)
        elseif or(ndim==7,ndim==8,ndim==9)
            subplot(3,3,i)
        end
        plot(T{j}(:,i),comdim_calib.T.d{j}(:,i),'.')
        axis tight
        title(i)
    end
end
shg