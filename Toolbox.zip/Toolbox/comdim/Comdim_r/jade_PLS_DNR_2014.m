function [Signal,Scores] =  jade_PLS_DNR_2014(X, y, ICs, Options);

% INPUT variables :
%
%   X(nxT) = mixed signal dataset
%   y(nxP) = Property to be predicted
%   ICs=  Sources (pure signal components) =underlying signals =pure spectra
%   where :
%   n=  Sensors (mixed signal inputs) = rows =spectra
%   T=  Signal data points = columns =variables
%
% Options.Method = 'Tall_Wide', 'Tall', 'Wide', 'Kernel', 'ComDim', 'Normal'
% Options.SortICs =0 (No) Sort Scores based on variances of Scores;
%
%
%   Options.Centred = Matrix centred by column
%
% OUTPUT variables :
%
%   Signal(nxT) or Signal(ICsxT)  = pure signal dataset
%   Scores = "scores" of samples calculated from ICs
%          = old_X*Signal*inv(Signal'*Signal);
%
%
% CALLS :
%
% PLS2_DNR_2018
% jadeR_2005
% IC_sort


[nR,nC]	= size(X);
MaxRank=min(nR,nC);

old_X=X;

% Since orienting using Y, no sorting
Options.SortICs =0;

if exist('Options','var')
    if isfield(Options,'SortICs');
        SortICs= Options.SortICs;
    else
        SortICs=0;
    end;
end

[PLS2_Res]=PLS2_DNR_2018(old_X,y,ICs);
X=PLS2_Res.W';

Options.Method='Normal';
B =  jadeR_2005(X,ICs);

% Calculate pure signals from unmixing matrix and X
%     Signal=(B*old_X)';
Signal=(B*X)';


% Calculate IC_Scores (proportions) of Jade
Scores=old_X*Signal/(Signal'*Signal);
% Scores=old_X*Signal*inv(Signal'*Signal);

if SortICs~=0
    [Signal, Scores, Scores_Variance] = IC_sort(Signal,Scores);
end


%% For information
% Scores=old_X*Signal;
% Scores=X*Signal*inv(Signal'*Signal);


