%% Load data
clear all;
load Lignin_ComDim.mat
clear Lig collection MyResult;
% in
% D:\sauvegarde_reseau\NewThingsA_O\Multiblock\ComDim
% OR
% in
% D:\MATLAB\R2007b\toolbox\IAQA\ComDim

%% X_calib == X_pred
X_calib=Lignine_Starch_smooth;
[nXr1,nXc1]=size(X_calib);
Samples_Nums1=[1:nXr1]';

X_pred=Lignine_Starch_smooth;
[nXr2,nXc2]=size(X_pred);
Samples_Nums2=[1:nXr2]';


% Just Lignin conc.
Y=Lignine_Starch_Y(:,3);

[nYr,nYc]=size(Y);

%%
seg{1}=[1:20];
seg{2}=[21:40];
seg{3}=[41:70];
seg{4}=[71:100];
seg{5}=[101:130];
seg{6}=[131:160];
seg{7}=[161:180];
seg{8}=[181:260];
nSegs=size(seg,2);

Seg_Nums1=[1:nSegs]';

%%
clear collection;

for i=1:nSegs
    collection(i).d=X_calib(:,seg{i});
    collection(i).v=seg{i};
    collection(i).i=Samples_Nums1;

    [nX1,nY1]=size(collection(i).d);
end

BlockName=[' X1';' X2';' X3';' X4';' X5';' X6';' X7'];

%%
[nCr,nCc]=size(collection);
XVar_Nums=[1:nCc];

%% Use same data for Prediction
clear collection_Pred;

for i=1:nSegs
    collection_Pred(i).d=X_pred(:,seg{i});
    collection_Pred(i).v=seg{i};
    collection_Pred(i).i=Samples_Nums2;
end



%% Plot Data

Figure_DNR(1);

plot(1:260,X_calib')
axis tight
yy=get(gca,'YLim');
hold on
for i=1:nSegs
    plot([seg{i}(1,1),seg{i}(1,1)],yy,'k-.')
end
set(gca,'FontSize',8)
tt=title(['The ',num2str(nSegs),' segments in X']);
set(tt,'Fontsize',10), clear tt
shg


%% ComDim calibration parameters

CDs=3;
r=2;
c=2;

% Number of Common Components
Options.ndim =CDs;
% Normalise each data table
Options.normalise =1;
% No comments during calculations
Options.loquace =0;
% Output Local Scores, Scaled and Unscaled Loadings
Options.Output='TPL';

Compression{1}='Normal';
Compression{2}='Kernel';
Compression{3}='PCT';
Compression{4}='Wide';
Compression{5}='Tall';

Options.Partitions = 3; % for 'Wide' & 'Tall'


%%
for Comp=1:size(Compression,2)
    m=1;
    Options.CompMethod=Compression{Comp};

    %% Do ComDim calibration 
    
    %%%% Good for Prediction using comdim_pred_2019
    Model_Name{m,Comp}=['comdim-PCA-2020',' / ',Compression{Comp}];
    disp(Model_Name{m,Comp});
    [ComDim_Res{m,Comp}]=comdim_PCA_2020(collection,Options);
    disp('                ');


%     %%%% Good for Prediction using comdim_pred_V8
%     m=m+1;
%     Model_Name{m,Comp}=['comdim-CCA',' / ',Compression{Comp}];
%     disp(Model_Name{m,Comp});
%     [ComDim_Res{m,Comp}]=comdim_CCA(collection,Options);
%     disp('                ');

    %%%% Good for Prediction using comdim_pred_2019
    m=m+1;
    Model_Name{m,Comp}=['comdim-ICA-2019',' / ',Compression{Comp}];
    Options.SortICs =0;
    disp(Model_Name{m,Comp});
    [ComDim_Res{m,Comp}]=comdim_ICA_2019(collection,Options);
    disp('                ');


    %%%% Perfect for Prediction using comdim_pred_2019
    m=m+1;
    Model_Name{m,Comp}=['comdim-PLS-2020',' / ',Compression{Comp}];
    Options.SortICs =0;
    disp(Model_Name{m,Comp});
    [ComDim_Res{m,Comp}]=comdim_PLS_2020(collection,Y, Options);
    disp('                ');

    %%%% Perfect for Prediction using comdim_pred_2019
    m=m+1;
    Model_Name{m,Comp}=['comdim-PLS-ICA-2019',' / ',Compression{Comp}];
    Options.SortICs =0;
    disp(Model_Name{m,Comp});
    [ComDim_Res{m,Comp}]=comdim_PLS_ICA_2019(collection,Y, Options);
    disp('                ');

end

%% Statistics
for m=1:size(ComDim_Res,1)
    for Comp=1:size(Compression,2)

    Figure_DNR(1);
    
    %% Statistics
    
    %% Saliences per CD
    Sum_Sal_Dim=ComDim_Res{m,Comp}.Sum_saliences_Dim.d;
    for i=1:CDs
        subplot(1,CDs+2,i);
        bar(ComDim_Res{m,Comp}.saliences.d(:,i),'b'), axis tight;
        xlabel('Blocks');
        ylabel(['Sum Saliences =', num2str(Sum_Sal_Dim(1,i))]);
        title(['CC ',num2str(i)]);
    end

    %% Saliences per Block
    Sum_Sal_Tab=ComDim_Res{m,Comp}.Sum_saliences_Tab.d;
    subplot(1,CDs+2,CDs+1);
    bar(Sum_Sal_Tab,'b'), axis tight;
    xlabel('Blocks');
    title('Saliences');
    
    %% Variances
    subplot(1,CDs+2,CDs+2);
    bar(ComDim_Res{m,Comp}.explained.d,'b'), axis tight;
    xlabel('Components');
    title('Variance');
    suptitle(['Statistics for ',Model_Name{m,Comp}]);

    end
end

%% Scores & Scaled Loadings
for m=1:size(ComDim_Res,1)
    for Comp=1:size(Compression,2)

        %% Do ComDim Prediction with comdim_pred_2019
        [res_pred_V8]=comdim_pred_2019(ComDim_Res{m,Comp}, collection_Pred);
        
        %% Compare Global Scores Q with Predicted Scores U
        Figure_DNR(1);
        for i=1:CDs
            subplot(2,3,i);
            plot(ComDim_Res{m,Comp}.Q.d(:,i),'b-o'), axis tight;
            hold on;
            plot(res_pred_V8.U.d(:,i),'r*'), axis tight;
            title(['CC ',num2str(i)]);
            
            subplot(2,3,3+i);
            plot(ComDim_Res{m,Comp}.P.d(:,i),'b-'), axis tight;
            
        end
        suptitle(['Global & Predicted Scores & Scaled Loadings for ',Model_Name{m,Comp}]);

    end
end

%% Scaled Loadings
% for m=1:size(ComDim_Res,1)
%     for Comp=1:size(Compression,2)
% 
%         Figure_DNR(1);
%         for i=1:CDs
%             subplot(r,c,i);
%             plot(ComDim_Res{m,Comp}.P.d(:,i),'b-'), axis tight;
%             title(['CC ',num2str(i)]);
%         end
%         suptitle(['Global Scaled Loadings for "',Model_Name{m,Comp}]);
% 
%     end
% end

%% UnScaled Loadings
% for m=1:size(ComDim_Res,1)
%     for Comp=1:size(Compression,2)
% 
%         Figure_DNR(1);
%         for i=1:CDs
%             subplot(r,c,i);
%             plot(ComDim_Res{m,Comp}.Lx.d(:,i),'b-'), axis tight;
%             title(['CC ',num2str(i)]);
%         end
%         suptitle(['Global UnScaled Loadings for "',Model_Name{m,Comp}]);
% 
%     end
% end


