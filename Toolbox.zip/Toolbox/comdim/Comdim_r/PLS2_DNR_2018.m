function [PLS2_Res]=PLS2_DNR_2018(X,Y,lvs);
% This function implements PLS2
%   USAGE:
%        [PLS2_Results]=PLS2_DNR_2018(X,Y,lvs);
%   INPUTS:
%        X = the scaled predictor block (n,px)
%        Y = the scaled predictand block (n,py)
%        lvs = the number of latent variables to be calculated (1,1)
%
%   OUTPUTS:
% PLS2_Results : A structure containing :
%        B = the matrix of regression vectors or matrices (px,lvs)
%        B0 = regression intercepts (1,py)
%        T = X scores (n,lvs)
%        P = X loadings (px,lvs)
%        W = X weights (px,lvs)
%        U = Y scores (n,lvs)
%        Q = Y loadings (py,lvs)
%        X_mat = Cube containing successive X matrices
%        Y_mat = Cube containing successive Y matrices
%        B_mat = Cube containing successive B matrices
%        B0_mat = Cube containing successive B0 matrices
%        Y_hat = Predicted Y values (n, py)

X_old=X;
[rows,px] = size(X);
[rows,py] = size(Y);
u_old = Y(:,1);

% W=[];
% P=[];
% Q=[];
% T=[];
% U=[];
% B=[];

W=zeros(px,lvs);
P=zeros(px,lvs);
Q=zeros(py,lvs);
T=zeros(rows,lvs);
U=zeros(rows,lvs);
% B=zeros(px,py);

X_mat(1,:,:)= X;
Y_mat(1,:,:)= Y;

meanX=mean(X); %DB, 05.04.16
meanY= mean(Y); %DB, 05.04.16

%  DNR 01/06/17
% %     X = X - ones(rows,1)*meanX;

% Necessary for PLS_ICA where nLVs decreases to 1
B_mat=zeros(lvs,px,py);
B0_mat=zeros(lvs,py);
% B_mat=squeeze(zeros(lvs,px,py));
% B0_mat=squeeze(zeros(lvs,py));

for i = 1:lvs
    limite=0;
    while ( 1 )
        w = u_old' * X;
        w = w /norm(w);
        t = X * w';
        t = t / (w*w');
        q = t' * Y;
        q = q / (t'*t);
        u = (Y * q')/(q*q');
        if ( norm(u - u_old) < 1e-6)
            break;
        end
        limite=limite+1;
        if ( limite > 1000)
            break;
        end
        u_old = u;
    end
    p = t'*X;
    p = p / (t'*t);
    
    W(:,i)=w';
    P(:,i)=p';
    Q(:,i)=q';
    T(:,i)=t;
    U(:,i)=u;
    
    X = X - t*p;
    Y = Y - t*q;
    
    X_mat(i+1,:,:)= X;
    Y_mat(i+1,:,:)= Y;
    
%     B_mat(i,:,:)= W*inv(P'*W)*Q';
    i_nums=[1:i];
    B_mat(i,:,:)= W(:,i_nums)/(P(:,i_nums)'*W(:,i_nums))*Q(:,i_nums)';
    toto=ndims(B_mat);
    if toto>2
        B0_mat(i,:,:)= meanY - meanX*squeeze(B_mat(i,:,:)); %DB, 05.04.16
    else
%         B0_mat(i,:,:)= meanY - meanX*B_mat(:,i); %DNR, 24.12.18
        B0_mat(i,:,:)= meanY - meanX*B_mat(i,:)'; %DNR, 24.12.18
    end
    
end

% B = W*inv(P'*W)*Q';
B = W/(P'*W)*Q';
B0 = meanY - meanX*B; %DB, 05.04.16

PLS2_Res.B=B;
PLS2_Res.B0=B0;
PLS2_Res.Scores=T;
PLS2_Res.P=P;
PLS2_Res.W=W;
PLS2_Res.U=U;
PLS2_Res.Q=Q;
PLS2_Res.X_mat=X_mat;
PLS2_Res.Y_mat=Y_mat;
PLS2_Res.B_mat=B_mat;
PLS2_Res.B0_mat=B0_mat;
PLS2_Res.Yhat=X_old*B+ones(size(X_old,1),1)*B0;

