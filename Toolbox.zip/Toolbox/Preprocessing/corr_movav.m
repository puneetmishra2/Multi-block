function X_corr= corr_movav(X0)
winsize = 15;
[n0C, p] = size(X0);
w = floor(winsize/2);
% Extend the spectrum by symmetry
x = [X0(:,w:-1:1), X0, X0(:,end-w+1:end)];
% Smooth
for i= w+1:w+p;
X_corr(:,i-w)=(sum(x(:,i-w:i+w)'))'./(2*w+1);
end;