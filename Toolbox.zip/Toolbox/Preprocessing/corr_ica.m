function [X_corr] = corr_ica(x);
% For smoothing, kept_IC could be 1:5
% To use on xcal : [xcf, sg] = corr_ica(xc, 1:5);
% To use on xtest : xtf = corr_ica(xt, sg);
kept_IC = 1:5;
% ICA Decomposition of X
sg = jadeR_2005(x, max(kept_IC)) * x;

sc = x * sg' * inv(sg * sg');
% Rebuild filtered X
X_corr = sc*sg;