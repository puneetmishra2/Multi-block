function X_corr= corr_log(X0);
% log10 may be replaced by log
X_corr=-real(log10(X0));