function X_corr = corr_minmax(X0);
% Set min to 0 and max to 1
[n,p] = size(X0);
minX = min(X0');
X_corr=X0-minX'*(ones(1,p));
maxX = max(X_corr');
% Correct for intensity variations
X_corr=X_corr./(maxX'*(ones(1,p)));