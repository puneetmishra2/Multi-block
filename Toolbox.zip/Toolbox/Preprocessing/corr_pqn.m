function [X_corr, Ratio, Med_Ratio]=corr_pqn(X0C);
% Calculates median of quotients of each X0C point to xref point
% Then corrects X0C
% USAGE :
% [X_corr, Ratio, Med_Ratio]=corr_pqn(X0C,xref);
% INPUT :
% X0C = matrix to be corrected
% xref = vector to be used as reference for the correction
% (e.g. median of X0C)
%
% OUTPUT :
% X_corr = corrected matrix
% Ratio = ratios for all the variables in all the rows of X0C
% Med_Ratio = median of the ratios in each row of X0C
%
[n,p]=size(X0C);

xref = mean(X0C);
% Compute the ratios and divide by their median value
for i=1:n
Ratio(i,:)=abs(X0C(i,:)./xref);
Med_Ratio(i,:)=median(Ratio(i,:));
X_corr(i,:)=X0C(i,:)./Med_Ratio(i,:);
end