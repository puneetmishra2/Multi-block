function [X_offset, Offset_val] = corr_offset (X0, varargin)
[n0C,p] = size(X0);
if nargin == 3
% Calculate baseline intensity
% based on a defined range: var1-var2
xt=[1:size(X0,2)];
coeff=(X0(:,varargin{1})-X0(:,varargin{2}))./(varargin{1}-varargin{2});
base1=coeff*xt;
base2=coeff*varargin{1};
base3=X0(:,varargin{1});
base4=(base3-base2)*ones(1,p);
Offset_val=base1+base4;
clear base1 base2 base3 base4
end
if nargin == 2
% Calculate the intensity at a given point: var1
Offset_val=((X0(:,varargin{1})')')*ones(1,p);
end
if nargin == 1
% Calculate the intensity at the minimum of each signal
Offset_val=(min((X0'))')*ones(1,p);
end
% Subtract from X
X_offset=X0-Offset_val;