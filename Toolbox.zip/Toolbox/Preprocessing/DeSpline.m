function [Xcorr,SplineTrend] = DeSpline(X);
dim = size(X,2);
b  = 1:dim;
b = b(1,1:20:end);
[n,p] = size(X);
% Compute the n baselines over the p wavelengths.
for i=1: n
SplineTrend(i,:)=spline(b,X(i,b),[1:p]);
end
% Correct the n spectra for the calculated baselines
Xcorr=X-SplineTrend;
%For test set, the same function is used