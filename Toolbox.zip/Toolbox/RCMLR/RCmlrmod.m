function model=RCmlrmod(varargin)
%Calculates a PCR model of specified complexity. Most of the options are gathered in the structure
%variable 'options'.
%I/O: model=RCpcrmod(X,Y, LV, options) where the default options can be
%retrieved by writing RCpcr('options')

if nargin==1 &&strcmp(varargin{1}, 'options')
    model.prepr={'mean' 'mean'};
    model.detailedoutput='on';
    return
elseif nargin==2
    
    X=varargin{1};
    Y=varargin{2};
    opt.prepr={'mean' 'mean'};
    opt.detailedoutput='on';
    
elseif nargin==3
    X=varargin{1};
    Y=varargin{2};
    opt=varargin{3};
end



[Xp, mx, sx]=prepfn(X, opt.prepr{1});    %Preprocessing of X matrix
[Yp, my, sy]=prepfn(Y, opt.prepr{2});    %Preprocessing of X matrix

[ns,nx]=size(X);

B=pinv(Xp)*Yp;
model.regcoef=B;


Yhat=Xp*B;
Ypred=unprepfn(Yhat,opt.prepr{2},my,sy);
model.PredY=Ypred;
model.TrueY=Y;
model.YResiduals=Y-Ypred;
model.bias=mean(model.YResiduals);
model.RMSE=sqrt(sum(model.YResiduals.^2)/size(Ypred,1));
RSS=sum(model.YResiduals.^2);
TSS=sum((Y-repmat(mean(Y), size(Y,1), 1)).^2);
model.R2=1-(RSS./TSS);
model.s2y=RSS./(ns-nx);
model.InfMatrix=Xp'*Xp;
model.varB=cell(1,size(Y,2));
for l=1:length(model.varB)
    model.varB{l}=inv(model.InfMatrix)*model.s2y(l);
end



if strcmp(opt.detailedoutput,'on')
    h=diag(Xp/(model.InfMatrix)*Xp'); %leverage
    model.leverage=h;
    model.tlim=tinv(0.975, ns-nx);
    model.sypred=sqrt(repmat(model.s2y,ns,1).*h);
    
end


model.preprpars={mx sx; my sy};
model.options=opt;



%%%%%%%%%%%%%%%%
function [Mp,mm,sm]=prepfn(X,pret1)
%Preprocessing routine. Performs mean centering ('mean'), autoscaling
%('auto') or no pretreatment ('none')

nt=size(X,1);
switch pret1
    case 'none'
        Mp=X;
        mm=[];
        sm=[];
    case 'mean'
        mm=mean(X);
        sm=[];
        Mp=X-repmat(mm, nt, 1);
    case 'auto'
        mm=mean(X);
        sm=std(X);
        snzero=1:size(X,2);snzero(sm==0)=[];
        Mp=zeros(size(X));
        Mp(:,snzero)=(X(:,snzero)-repmat(mm(snzero), nt, 1))./repmat(sm(snzero),nt, 1);
    case 'pareto'
        mm=mean(X);
        sm=sqrt(std(X));
        snzero=1:size(X,2);snzero(sm==0)=[];
        Mp=zeros(size(X));
        Mp(:,snzero)=(X(:,snzero)-repmat(mm(snzero), nt, 1))./repmat(sm(snzero),nt, 1);
end

%%%%%%%%%%%%%%%%%%
function Mn=unprepfn(X,pret1,mm,sm)
%Preprocessing routine. Applies preprocessing to new matrices using the parameters
%calculated on the training set. Performs mean centering ('mean'), autoscaling
%('auto') or no pretreatment ('none')

nt=size(X,1);
switch pret1
    case 'none'
        Mn=X;
        
    case 'mean'
        Mn=X+repmat(mm, nt, 1);
    case {'auto', 'pareto'}
        Mn=(X.*repmat(sm,nt, 1))+repmat(mm, nt, 1);
end


