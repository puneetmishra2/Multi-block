function model=RCmlrpred(varargin)
%Applies a PCR model calculated by the function RCpcrmod to a new set of data
%for prediction. 
%I/O: pred=RCpcrpred(Xnew,Ynew, pcrmodel)
%     pred=RCpcrpred(Xnew,pcrmodel)
% depending on whether the Y values for the new set are available, or not
%

if nargin==3 
    Xt=varargin{1};
    Yt=varargin{2};
    modmlr=varargin{3};
elseif nargin==2
    Xt=varargin{1};
    Yt=[];
    modmlr=varargin{2};
    
end


%Preprocessing
%Apply to the unknown X the preprocessing parameters of the calibration set.
Xp=apprepfn(Xt,modmlr.options.prepr{1},modmlr.preprpars{1,1}, modmlr.preprpars{1,2});
Yhat=Xp*modmlr.regcoef; 
Ypred=unprepfn(Yhat,modmlr.options.prepr{2},modmlr.preprpars{2,1}, modmlr.preprpars{2,2});
model.PredY=Ypred; 
model.TrueY=Yt;

if ~isempty(Yt)


    model.YResiduals=Yt-Ypred; 
    model.bias=mean(model.YResiduals); 
    model.RMSEP=sqrt(sum(model.YResiduals.^2)/size(Ypred,1)); 
    RSS=sum(model.YResiduals.^2);
    TSS=sum((Yt-repmat(mean(Yt), size(Yt,1), 1)).^2); 
    model.R2=1-(RSS./TSS);
    
end

if strcmp(modmlr.options.detailedoutput,'on')
    
    h=diag(Xp/(modmlr.InfMatrix)*Xp'); %leverage
    model.leverage=h;
    model.tlim=modmlr.tlim;
    model.sypred=sqrt(repmat(modmlr.s2y,size(Xp,1),1).*(1+h));
    
end










%%%%%%%%%%%%%%%%
function Mp=apprepfn(X,pret1,mm,sm)
%Preprocessing routine. Performs mean centering ('mean'), autoscaling
%('auto') or no pretreatment ('none') - Using parameters computed on the
%training set

nt=size(X,1);
switch pret1
    case 'none'
        Mp=X;
    case 'mean'
        Mp=X-repmat(mm, nt, 1);
    case {'auto','pareto'}
        snzero=1:size(X,2);snzero(sm==0)=[];
        Mp=zeros(size(X));
        Mp(:,snzero)=(X(:,snzero)-repmat(mm(snzero), nt, 1))./repmat(sm(snzero),nt, 1);
end


%%%%%%%%%%%%%%%%%%
function Mn=unprepfn(X,pret1,mm,sm)
%Preprocessing routine. Applies preprocessing to new matrices using the parameters
%calculated on the training set. Performs mean centering ('mean'), autoscaling
%('auto') or no pretreatment ('none')

nt=size(X,1);
switch pret1
    case 'none'
        Mn=X;
        
    case 'mean'
        Mn=X+repmat(mm, nt, 1);
    case {'auto', 'pareto'}
        Mn=(X.*repmat(sm,nt, 1))+repmat(mm, nt, 1);
end
