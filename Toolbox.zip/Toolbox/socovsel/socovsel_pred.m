function pred=socovsel_pred(varargin)
% socovsel_pred Applies a sequential and orthogonalized CovSel model to new data
%   The function socovsel_pred applies a sequential and orthogonalized Covariance
%   Selection (SO-CovSel) multi-block regression model (calculated by socovsel_mod
%   or socovsel_cv) ona new set of data (for validation on a test set or for
%   prediction of unknown samples)
%
%   INPUTS:
%       X = cell array of predictor blocks for new data (of length nblocks)
%   somod = SO-CovSel model (can be the output of socovsel_mod or the field
%           OptModel of the output of socovsel_cv)
%   OPTIONAL INPUTS:
%       Y = response (dependent variables) block for the new data, if available
%
%   OUTPUT:
%    pred = a structure array with all the results.
%
%   I/O:
%           pred=socovsel_pred(X,Y, somod);
%           pred=socovsel_pred(X,somod);
%
% Written by Federico Marini
% Version: 19/04/2020


if nargin==3
    X=varargin{1};
    Y=varargin{2};
    somod=varargin{3};
elseif nargin==2
    X=varargin{1};
    Y=[];
    somod=varargin{2};
end

pret=somod.preptype;
prpar=somod.preppars;
nblock=somod.nblock;

Yhat=zeros(size(X{1},1), size(somod.predY,2));

Xsel=[];

Xp=cell(size(X));

for i=1:nblock
    Xp{i}=apprepfn(X{i},pret{i},prpar{i,1}, prpar{i,2});
    if ~isempty(somod.reg{i})
        
        Yhat=Yhat+Xp{i}*somod.reg{i};
        
        if i==1||isempty(Xsel)
            Xs=Xp{i}(:,somod.covsel(i).SelVar);
            Xso=Xs*somod.covsel(i).Brot;
            
        else
            Xs=(Xp{i}(:,somod.covsel(i).SelVar)-Xsel*somod.covsel(i).Dmatrix);
            Xso=Xs*somod.covsel(i).Brot;
        end
    else
        Xs=[];
        Xso=[];
    end
    
    pred.covsel(i).XselOrig=Xs;
    pred.covsel(i).XselOrth=Xso;
    Xsel=[Xsel Xso];
end

YPred=unprepfn(Yhat,pret{end},prpar{end,1}, prpar{end,2});   %Predicted Y in original scale

pred.concvars=Xsel;
pred.predY=YPred;
if ~isempty(Y)
    pred.resY=Y-YPred;
    pred.rmsep=sqrt(sum((pred.resY).^2,1)/size(Y,1));
    pred.bias=mean(pred.resY);
    pred.r2=1-(sum((pred.resY).^2,1)./sum((Y-repmat(mean(Y), size(Y,1), 1)).^2,1));
    
else
    pred.resY=[];
    pred.rmsep=[];
    pred.bias=[];
    pred.r2=[];
    
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Mp=apprepfn(X,pret1,mm,sm)
%Preprocessing routine. Performs mean centering ('mean'), autoscaling
%('auto') or no pretreatment ('none') - Using parameters computed on the
%training set

nt=size(X,1);
switch pret1
    case 'none'
        Mp=X;
    case 'mean'
        Mp=X-repmat(mm, nt, 1);
    case 'auto'
        Mp=(X-repmat(mm, nt, 1))./repmat(sm,nt, 1);
end

%%%%%%%%%%%%%%%%%%





%%%%%%%%%%%%%%%%%%
function Mn=unprepfn(X,pret1,mm,sm)
%Unpreprocessing routine. "removes" preprocessing to new matrices using the parameters
%calculated on the training set. Performs mean centering ('mean'), autoscaling
%('auto') or no pretreatment ('none')

nt=size(X,1);
switch pret1
    case 'none'
        Mn=X;
        
    case 'mean'
        Mn=X+repmat(mm, nt, 1);
    case 'auto'
        Mn=(X.*repmat(sm,nt, 1))+repmat(mm, nt, 1);
end
