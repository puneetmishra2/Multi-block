function model=socovsel_cv(varargin)
% socovsel_cv sequential and orthogonalized CovSel with cross-validation
%   The function socovsel_cv uses cross-validation for selecting the optimal 
%   complexity of a sequential and orthogonalized Covariance Selection (SO-CovSel)  
%   multi-block regression model. 
%   After the model selection phase, it also calculates the final SO-CovSel
%   model on the whole training data, based on the optimal model complexity.
%
%   INPUTS:
%       X = cell array of predictor blocks (of length nblocks) 
%       Y = response (dependent variables) block
%   nVmax = maximum number of variables to be tested for each block (can be either
%           a scalar (same number for each block) or a vector (of length nblocks)
%    pret = a cell array (length nblocks+1) containing the desired
%           pretreatments for the X and Y (the last component) blocks.
%           Can take values 'none', 'mean', 'auto'.
%   OPTIONAL INPUT:
%     opt = a structure array with options (if not provided, default options
%           are used. Fields are: 
%               cvtype: ['loo' | {'syst123'} | 'syst111'] Governs the
%                                   way cancelation groups are defined.
%           cvsegments: {5}         Number of cancelation groups. 
%                nVsel: [{'auto'} | 'manual'] Governs whether the optimal number 
%                                   of variables is automatically or manually selected
%             Mageplot: ['off' | {'best'} ! 'all'] Defines the level of display 
%                                   of the Mage plot. In 'best', only the
%                                   combination of LVs leading to the
%                                   minimum error for each total model
%                                   complexity are displayed.
%              output: {'full'}     If selected, 'full' determines a larger amounts
%                                   of details to be saved in the model
%                                   output.
%     Default options can be obtained by writing: 
%           opt=socovsel_cv('options'); 
%
%   OUTPUT:
%   model = a structure array with all the results. CV results are saved in the 
%           field model.CV, while the final model in model.OptModel
%
%   I/O:
%           model=socovsel_cv(X,Y, nVmax, pret, opt); 
%           model=socovsel_cv(X,Y, nVmax, pret); 
%           
% Written by Federico Marini 
% Version: 19/04/2020


if nargin==1 && strcmp(varargin{1}, 'options')
    model.cvtype='syst123';
    model.cvsegments=5;
    model.nVsel='auto';
    model.Mageplot='best';
    model.output='full';
    return
    
elseif nargin==5
    X=varargin{1};
    Y=varargin{2};
    nVmax=varargin{3};
    pret=varargin{4};
    opt=varargin{5};
    
elseif nargin==4
    X=varargin{1};
    Y=varargin{2};
    nVmax=varargin{3};
    pret=varargin{4};
    opt.cvtype='syst123';
    opt.cvsegments=5;
    opt.nVsel='auto';
    opt.Mageplot='best';
    opt.output='full';
end

cvtype=opt.cvtype;
segments=opt.cvsegments;


nblock=length(X);

if max(size(nVmax))==1
    nVmax=repmat(nVmax, 1, nblock);
end
ntot=size(X{1},1); %Total number of samples
if strcmp(cvtype, 'loo')  %Loo cross-validation corresponds to syst123 with N segments
    cvtype='syst123';
    segments=ntot;
end

L=arrayfun(@(c) 0:c, nVmax, 'un', 0);
[LVcomb{nblock:-1:1}] = ndgrid(L{nblock:-1:1}) ;
LVcomb = reshape(cat(nblock+1,LVcomb{:}), [], nblock);
ncomb=size(LVcomb,1);
rmsecv=zeros(ncomb,1);
Ypredcv=cell(ncomb,1);



for j=1:segments %Beginning of the crossvalidation loop
    
    switch cvtype
        case 'syst123'    %venetian blind cross-validation
            t=j:segments:ntot; %Calibration set
            m=1:ntot; m(t)=[]; %Validation set
            
        case 'syst111'    %contiguous blocks
            ns=ceil(ntot./segments);  %number of samples in each group
            if j==segments
                t=(j-1)*ns+1:ntot; %Validation set
            else
                t=(j-1)*ns+1:j*ns; %Calibration set
            end
            m=[1:(j-1)*ns ns*j+1:ntot]; %camp. nel set di calib.
    end
    

    Xm=cell(size(X)); Xt=cell(size(X));

    for i=1:nblock
        Xm{i}=X{i}(m,:);
        Xt{i}=X{i}(t,:);
    end
    Ym=Y(m,:);
    Yt=Y(t,:);

        for nn=1:ncomb
        
        sm=socovsel_mod(Xm, Ym, LVcomb(nn,:), pret);
        sp=socovsel_pred(Xt, Yt, sm);
        rmsecv(nn)=rmsecv(nn)+sum(sum((sp.resY).^2));
        Ypredcv{nn}(t,:)=sp.predY;
    end

end

rmsecv=sqrt(rmsecv./ntot);
mmage=rmsmageplotcs(rmsecv, LVcomb,opt.nVsel, opt.Mageplot);
mfin=socovsel_mod(X, Y, mmage.lvopt, pret);

model.OptModel=mfin;
model.CV.nVcomb=LVcomb;
model.CV.rmsecv=rmsecv;
model.CV.nVopt=mmage.lvopt;
model.CV.nVcombidx=mmage.optidx;
model.CV.rmsecvopt=mmage.rmseopt;
model.CV.predYopt=Ypredcv{mmage.optidx};

tss=sum((Y-repmat(mean(Y), size(Y,1), 1)).^2,1);

if strcmp(opt.output, 'full')
    
    r2=zeros(ncomb,size(Y,2));
    bias=zeros(ncomb,size(Y,2));
    
    for j=1:ncomb
        yres=Y-Ypredcv{j};
        bias(j,:)=mean(yres);
        r2(j,:)=1-(sum((yres).^2,1)./tss);
    end
    model.CV.biasopt=bias(model.CV.nVcombidx,:);
    model.CV.r2opt=r2(model.CV.nVcombidx,:);
    model.CV.predY=Ypredcv;
    model.CV.bias=bias;
    model.CV.r2=r2;
    
else
    yres=Y-Ypredcv{model.CV.nVcombidx};
    model.CV.biasopt=mean(yres);
    model.CV.r2opt=1-(sum((yres).^2,1)./tss);
    
    
end

model.CV.options=opt;
