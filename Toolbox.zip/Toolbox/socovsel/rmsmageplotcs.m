function model=rmsmageplotcs(rmsecv, lvcomb,selcrit, plottype)
% rmsmageplot Mage plot based on SO-CovSel cross-validation results
%   The function rmsmageplot uses the results of sequential and orthogonalized 
%   Covariance Selection (SO-CovSel) multi-block regression model in cross-validation,   
%   to display the RMSECV as a function of total model complexity (the so-called
%   Mage plot). Based on the results, it is also possible to define the
%   optimal model complexity of the regression model. 
%   The function is called within the socovsel_cv routine, but it can also be
%   used as a standalone function to plot the results of socovsel_cv after
%   modeling.
%
%   INPUTS:
%     rmsecv = vector containing the values of the total RMSECV for each combination
%              of latent variables (length: number of possible combinations
%              of LVs: ncomb)
%     lvcomb = matrix (ncombxnblocks) defining all the tested combinations
%              of the numbers of latent variables.
%    selcrit = ['auto' | 'manual'] Governs whether the optimal number of LVs
%                                  is automatically or manually selected
%   plottype = ['off' | 'best' ! 'all'] Defines the level of display of the 
%                                  Mage plot. In 'best', only the combinations of
%                                  LVs leading to the minimum error for each
%                                  total model complexity are displayed.
%                                   
%   OUTPUT:
%   model = a structure array with all the results. The optimal combination
%           of LVs is saved in the field lvopt, while the index of the
%           combination is saved in optidx.
%
%   I/O:
%           model=rmsmageplotcs(rmsecv, lvcomb,selcrit, plottype); 
%           
% Written by Federico Marini 
% Version: 19/04/2020

nblock=size(lvcomb,2);
lvtot=sum(lvcomb,2);
maxlv=max(lvtot);
rmsmin=zeros(maxlv+1,1);
nmin=zeros(maxlv+1,1);
lvmin=zeros(maxlv+1,nblock);

for nlv=0:maxlv
    scomb=find(lvtot==nlv);
    [merr,cmbidx]=min(rmsecv(scomb));
    rmsmin(nlv+1)=merr;
    lvmin(nlv+1,:)=lvcomb(scomb(cmbidx),:);
    nmin(nlv+1)=scomb(cmbidx);
end

switch plottype
    case 'off'
        
        
    case 'best'
        figure('units', 'normalized', 'position', [0.1 0.1 0.8 0.7])
        hold on
        plot(0:maxlv, rmsmin, 'sk', 0:maxlv, rmsmin, '-r','linewidth', 2, 'markersize', 9)
        for j=1:maxlv+1
            text(j-1, rmsmin(j)+.02*range(rmsmin), num2str(lvmin(j,:),[repmat('%.0f,', 1,nblock-1),'%.0f']), 'fontsize', 12, 'fontweight', 'bold')
        end
        xlabel('Total number of selected variables', 'fontsize', 14, 'fontweight', 'bold')
        ylabel('RMSECV', 'fontsize', 14, 'fontweight', 'bold')
        
    case 'all'
        
        figure('units', 'normalized', 'position', [0.1 0.1 0.8 0.7])
        hold on
        plot(0:maxlv, rmsmin, '-r','linewidth', 2)
        for j=1:length(lvtot)
            plot(lvtot(j), rmsecv(j), 'sk', 'markersize', 9)
            
            text(lvtot(j), rmsecv(j)+.02*range(rmsmin), num2str(lvcomb(j,:),[repmat('%.0f,', 1,nblock-1),'%.0f']), 'fontsize', 9, 'fontweight', 'bold')
        end
        xlabel('Total number of selected variables', 'fontsize', 14, 'fontweight', 'bold')
        ylabel('RMSECV', 'fontsize', 14, 'fontweight', 'bold')
        
end

if strcmp(selcrit, 'auto')
    [opterr, mlv]=min(rmsmin);
    nopt=nmin(mlv);
    lvopt=lvmin(mlv,:);
elseif strcmp(selcrit, 'manual')
    lvopt=input('Input the optimal number of selected variables: ');
    nopt=find(ismember(lvcomb, lvopt, 'rows')==1);
    opterr=rmsecv(nopt);
end



model.lvopt=lvopt;
model.optidx=nopt;
model.rmseopt=opterr;
model.rmsemin=rmsmin;
model.rmslvmin=lvmin;
