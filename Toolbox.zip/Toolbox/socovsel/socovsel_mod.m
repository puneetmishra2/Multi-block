function model=socovsel_mod(X, Y, nVar, pret)
% socovsel_mod Trains a sequential and orthogonalized CovSel model
%   The function socovsel_mod calculates  a sequential and orthogonalized  
%   Covariance Selecttion (SO-CovSel) multi-block regression model on 
%   training data. 
%   
%   INPUTS:
%       X = cell array of predictor blocks (of length nblocks) 
%       Y = response (dependent variables) block
%    nVar = number of variables to be extracted for each block (can be either
%           a scalar (same number for each block) or a vector (of length nblocks)
%    pret = a cell array (length nblocks+1) containing the desired
%           pretreatments for the X and Y (the last component) blocks.
%           can take values 'none', 'mean', 'auto'.

%   OUTPUT:
%   model = a structure array with all the results. 
%
%   I/O:
%           model=socovsel_mod(X,Y, nVar, pret); 
%           
% Written by Federico Marini 
% Version: 19/04/2020

nblock=length(X);

if max(size(nVar))==1
    nVar=repmat(nVar, 1, nblock);
end
Xp=cell(size(X));
preppars=cell(nblock+1,2);


for i=1:nblock
    [Xp{i},preppars{i,1},preppars{i,2}]=prepfn(X{i},pret{i});
end
[Yp,preppars{nblock+1,1},preppars{nblock+1,2}]=prepfn(Y,pret{nblock+1});

model.preptype=pret;
model.preppars=preppars;
model.nblock=nblock;
Xsel=[];
Yres=Yp;

for i=1:nblock
    
    if nVar(i)~=0
        
        if i==1||isempty(Xsel)
            Xo=Xp{i};
            [vsel,crbvar,Xseli,Xoseli,borth]=covsel(Xo,Yp,nVar(i));
            D=[];
        else
            Xo=(eye(size(Xp{i},1))-(Xsel/(Xsel'*Xsel)*Xsel'))*Xp{i};
            [vsel,crbvar,Xseli,Xoseli,borth]=covsel(Xo,Yp,nVar(i));
            D=(Xsel'*Xsel)\Xsel'*Xp{i}(:,vsel);
        end
        
        
        Xsel=[Xsel Xoseli];
        P=eye(size(Xo,2));
        P=P(:,vsel);
        
        
        model.covsel(i).XselOrig=Xseli;
        model.covsel(i).XselOrth=Xoseli;
        model.covsel(i).ExplVar=crbvar;
        model.covsel(i).SelVar=vsel;
        model.covsel(i).Brot=borth;
        model.covsel(i).Loadings=P*borth;
        model.covsel(i).Dmatrix=D;
        model.covsel(i).Borth=Xoseli\Yres;
        Bstar{i}=model.covsel(i).Borth;
        for j=1:i-1
            if j==1&&~isempty(Bstar{j})
                Bstar{j}=Bstar{j}-D(1:nVar(j),:)*Bstar{i};
            else
                if ~isempty(Bstar{j})
                    Bstar{j}=Bstar{j}-D(sum(nVar(1:j-1))+1:sum(nVar(1:j)),:)*Bstar{i};
                end
            end
        end
        
        Yres=Yres-Xoseli*Bstar{i};
        
    else
        model.covsel(i).XselOrig=[];
        model.covsel(i).XselOrth=[];
        model.covsel(i).ExplVar=[];
        model.covsel(i).SelVar=[];
        model.covsel(i).Brot=[];
        model.covsel(i).Loadings=[];
        model.covsel(i).Dmatrix=[];
        model.covsel(i).Borth=[];
        Bstar{i}=[];
        
    end
    
end


Yhat=zeros(size(Yp));
for i=1:nblock
    model.covsel(i).regSel=Bstar{i};
    model.reg{i}=model.covsel(i).Loadings*Bstar{i};
    if ~isempty(model.reg{i})
        Yhat=Yhat+Xp{i}*model.reg{i};
    end
end
YPred=unprepfn(Yhat,pret{end},preppars{end,1},preppars{end,2});

model.concvars=Xsel; 
model.predY=YPred;
model.resY=Y-YPred;
model.rmsec=sqrt(sum((model.resY).^2,1)/size(Y,1));
model.bias=mean(model.resY);
model.r2=1-(sum((model.resY).^2,1)./sum((Y-repmat(mean(Y), size(Y,1), 1)).^2,1));








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [vsel,crbvar,Xsel,Xosel,borth] = covsel(x,y,nv)

crbvar=zeros(nv,2);

[nx,~] = size(x);
[ny,~] = size(y);

if nx ~= ny
    error('The number of samples in X and Y do not correspond')
end

nv = min( nv, rank(x) );
z=x;
t=y;

vartot=[ sum(sum(z.*z))     sum(sum(t.*t))];
Xosel=zeros(nx,nv);
vsel=zeros(1,nv);


for i=1:nv
    [~,j] = max( sum( (z'*t).^2 ,2) );
    vsel(i)=j;
    v = z(:,j);
    z = z - v*v'*z/(v'*v);
    crbvar(i,1) = ( vartot(1)-  sum(sum(z.*z)) ) / vartot(1);
    t = t - v*v'*t/(v'*v);
    crbvar(i,2) = ( vartot(2) - sum(sum(t.*t)) ) / vartot(2);
    
    Xosel(:,i)=v;
    
end

Xsel=x(:,vsel);

borth=pinv(Xsel)*Xosel;


%%%%%%%%%%%%%%%%
function [Mp,mm,sm]=prepfn(X,pret1)
%Preprocessing routine. Performs mean centering ('mean'), autoscaling
%('auto') or no pretreatment ('none')

nt=size(X,1);
switch pret1
    case 'none'
        Mp=X;
        mm=[];
        sm=[];
    case 'mean'
        mm=mean(X);
        sm=[];
        Mp=X-repmat(mm, nt, 1);
    case 'auto'
        mm=mean(X);
        sm=std(X);
        Mp=(X-repmat(mm, nt, 1))./repmat(sm,nt, 1);
end

%%%%%%%%%%%%%%%%%%
function Mn=unprepfn(X,pret1,mm,sm)
%Preprocessing routine. Applies preprocessing to new matrices using the parameters
%calculated on the training set. Performs mean centering ('mean'), autoscaling
%('auto') or no pretreatment ('none')

nt=size(X,1);
switch pret1
    case 'none'
        Mn=X;
        
    case 'mean'
        Mn=X+repmat(mm, nt, 1);
    case 'auto'
        Mn=(X.*repmat(sm,nt, 1))+repmat(mm, nt, 1);
end

