% script for running the socvsel for classification and then feeding it to lda calssifier 
% This script will be called by the GUI ...Puneet Mishra (29/05/2020)


addpath([pwd '/socovsellda']);
opt=socovlda_cv('options'); 
opt.cvtype = CV;

blocks=nB;

if blocks==2
    pret={'mean','mean','mean'};
    lv=[10,10];
    X = {p1,p2};
elseif blocks==3
    pret={'mean','mean','mean','mean'};
    lv=[10,10,10];
    X = {p1,p2,p3};
elseif blocks==4
    pret={'mean','mean','mean','mean','mean'};
    lv=[10,10,10,10];
    X = {p1,p2,p3,p4};
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CROSS VALIDATING THE MODEL

socovseldamodel=socovlda_cv(X,Y, lv, pret);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% PLOTTING THE BANDS SELECTED FROM EACH BLOCK

varsel=[];
figure, 
for i=1:nB
    k = socovseldamodel.OptModel.covsel(i).SelVar;
    varsel = [varsel k];
    if isempty(k)
        subplot(1,nB,i)
        plot(eval(['w' num2str(i)]),X{1,i});
        set(gca,'FontSize',10,'FontWeight','bold');
        xlabel('Variables');
        ylabel('Signal intensity');
        title(['Sensor ' num2str(i) '   Vars = 0']);
        axis tight
    else
    subplot(1,nB,i)
    plot(eval(['w' num2str(i)]),X{1,i});
    set(gca,'FontSize',10,'FontWeight','bold');
    sel = socovseldamodel.OptModel.covsel(i).SelVar;
        for plo = 1:size(sel,2)
            xline(eval(['w' num2str(i) '(1,sel(1,plo))']),'g');
            hold on
        end
        hold off
    xlabel('Variables');
    ylabel('Signal intensity');
    title(['Sensor ' num2str(i) '  Vars = ' num2str(size(socovseldamodel.OptModel.covsel(i).SelVar,2))]);
    axis tight
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PREDICITNG FOR THE CALIBRAITON SET TO EXTRACT STATISTICS AND PLOTTING

pred=socovlda_pred(X,Y, socovseldamodel.OptModel); 

[~,ind]= max(pred.predY');
ind = ind';
overall_accuracy = sum(Y-ind == 0)/size(Y,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:size(unique(Y),1)
    accuracy_individual(1,i) = sum(Y(Y==i,:)-ind(Y==i,:) == 0)/size(Y(Y==i,:),1);
end

total_var = 0;  %counting total number of variables selected
for i = 1:nB
total_var = total_var + size(socovseldamodel.OptModel.covsel(i).SelVar,2);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BAR PLOT EXPLAINING ACCURACY FOR EACH CLASS IS PLOTTED

figure, bar(accuracy_individual); %plotting the bar graph of individual class accuracy
set(gca,'FontSize',10,'FontWeight','bold');
title(['Overall accuracy with ' num2str(total_var) ' bands = ' num2str(overall_accuracy*100) ' %']);
xlabel('Classes');
ylabel('Accuracy for individual class');
grid on

clear X sel
