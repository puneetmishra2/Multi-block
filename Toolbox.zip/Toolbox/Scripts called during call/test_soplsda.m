% Script for applicaiton of sopls trained model for a new test dataset ...Puneet Mishra (29/05/2020)

addpath([pwd '/soplslda']);

run prepare_test_data.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
% application of the model

pred = soplslda_pred(test_data,soplsdamodel.OptModel); 
predY = pred.predY;
[~,ind] = max(pred.predY');
ind = ind';
predictions = ind;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


if exist('test_Y')
    
    overall_accuracy = sum(test_Y-ind == 0)/size(test_Y,1);
    for i=1:size(unique(test_Y),1)
        accuracy_individual_test(1,i) = sum(test_Y(test_Y==i,:)-ind(test_Y==i,:) == 0)/size(test_Y(test_Y==i,:),1);
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    figure, bar(accuracy_individual_test);
    set(gca,'FontSize',10,'FontWeight','bold');
    title(['Overall accuracy = ' num2str(overall_accuracy*100) ' %']);
    xlabel('Classes');
    ylabel('Accuracy for individual class (Test set)');
    grid on
    
else
    figure;
    plot(predictions,'.r','MarkerSize',30);
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Samples');
    ylabel('Predicted class');
    title('Predictions');
end
