%%% COMDIM-PLS-PCA-LDA  ...Puneet Mishra (29/05/2020)

addpath([pwd '/comdim/Comdim_r']);
addpath([pwd '/comdim']);
addpath([pwd '/comdim/COMDIM_Douglas']);
BlockName = [];
for i=1:nB
    collection(i).d = eval(['p' num2str(i)]);
    Samples_Nums = (1:size(collection(i).d,1))';
    Var_Nums = (1:size(collection(i).d,2));
    collection(i).v = Var_Nums;
    collection(i).i = Samples_Nums;
    BlockName=[BlockName;['X' num2str(i)]];
    clear Var_Nums
end
[cld,~] = conjtodis(Y);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[nCr,nCc]=size(collection);
Block_Nums = [1:nCc];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% model parameters and options
CDs = 20;
    
Options.SortICs =0;
Options.ndim = CDs;
Options.normalise = 1;
Options.loquace =0;
Options.Output='TPL';

Options.CompMethod=Compression;
Options.Method='Normal';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%running comdim PLS

ComDim_Res = comdim_PLS_2020(collection, cld, Options);

scores = ComDim_Res.Q.d;
opt=cross_val_lda('options');
opt.cvtype = CV;
model = cross_val_lda(scores,Y,opt);