%%% COMDIM-PLS-ICA (This does not do any regression but decompose data with
%%% supervised knowledge) ...Puneet Mishra (29/05/2020)

addpath([pwd '/comdim/Comdim_r']);
addpath([pwd '/comdim']);
addpath([pwd '/comdim/COMDIM_Douglas']);
BlockName = [];
for i=1:nB
    collection(i).d = eval(['p' num2str(i)]);
    Samples_Nums = (1:size(collection(i).d,1))';
    Var_Nums = (1:size(collection(i).d,2));
    collection(i).v = Var_Nums;
    collection(i).i = Samples_Nums;
    BlockName=[BlockName;['X' num2str(i)]];
    clear Var_Nums
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[nCr,nCc]=size(collection);
Block_Nums = [1:nCc];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% model parameters and options

CDs=nF;

Options.ndim = CDs;
Options.normalise = 1;
Options.loquace =0;
Options.Output='TPL';

Options.CompMethod='Normal';
Options.Method='Normal';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% running comdim PLS ICA
[ComDim_Res_PLS_ICA]=comdim_PLS_ICA_2019(collection, Y, Options);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plotting global scores on common components with samples
figure,
for i=1:CDs
    subplot(1,CDs,i);
    plot(Samples_Nums,ComDim_Res_PLS_ICA.Q.d(:,i),'r:'), axis tight;
    set(gca,'FontSize',10,'FontWeight','bold');
    hold on;
    scatter(Samples_Nums,ComDim_Res_PLS_ICA.Q.d(:,i),40,Y,'Filled'), axis tight;
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Samples');
    ylabel(['CC ',num2str(i)]);
end
suptitle('Global scores on common components with samples');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% plotting global scores on common components with Y value of samples
figure,
for i=1:CDs
    subplot(1,CDs,i);
    plot(Y,ComDim_Res_PLS_ICA.Q.d(:,i),'r:'), axis tight;
    set(gca,'FontSize',10,'FontWeight','bold');
    hold on;
    scatter(Y,ComDim_Res_PLS_ICA.Q.d(:,i),40,Y,'Filled'), axis tight;
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Y measured');
    ylabel(['CC ',num2str(i)]);
end
suptitle('Global scores on common components with Y value of samples');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure,
 plot3(ComDim_Res_PLS_ICA.Q.d(:,1),ComDim_Res_PLS_ICA.Q.d(:,2),ComDim_Res_PLS_ICA.Q.d(:,3),'.r','MarkerSize',20); xlabel('CC1'); ylabel('CC2'); zlabel('CC3'); title('Global Scores 3 COMDIM components');axis tight;
 set(gca,'FontSize',12,'FontWeight','bold');
 text(ComDim_Res_PLS_ICA.Q.d(:,1),ComDim_Res_PLS_ICA.Q.d(:,2),ComDim_Res_PLS_ICA.Q.d(:,3),string(1:size(ComDim_Res_PLS_PCA.Q.d,1)),'FontWeight','bold');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% salinces
Sum_Sal_Dim=ComDim_Res_PLS_ICA.Sum_saliences_Dim.d;
figure,
for i=1:CDs
    subplot(1,CDs,i);
    bar(ComDim_Res_PLS_ICA.saliences.d(:,i),'r'), axis tight;
    set(gca,'FontSize',10,'FontWeight','bold');
    ylabel(['CC ',num2str(i)]);
    title(['Sum Sal. =', num2str(Sum_Sal_Dim(1,i))]);
end
suptitle('Saliences');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% saliences blocks

Sum_Sal_Tab=ComDim_Res_PLS_ICA.Sum_saliences_Tab.d;
figure,
bar(Sum_Sal_Tab,'r'), axis tight;
set(gca,'FontSize',10,'FontWeight','bold');
xlabel('Blocks');
ylabel('Variance');

suptitle('Saliences each block');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% variances

figure,
bar(ComDim_Res_PLS_ICA.explained.d,'r'), axis tight;
set(gca,'FontSize',10,'FontWeight','bold');
xlabel('Components');
ylabel('Variance');
suptitle('Variances');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% scaled loading
% figure,
% for i=1:CDs
%         subplot(1,CDs,i);
%         plot(ComDim_Res_PLS_ICA.P.d(:,i),'b:'), axis tight;
%         set(gca,'FontSize',10,'FontWeight','bold');
%         hold on;
%         if nB==2
%         plot(collection(1).v,ComDim_Res_PLS_ICA.P_Loc.d{1,1}(:,i), 'r'), axis tight;
%         plot(max(collection(1).v)+collection(2).v,ComDim_Res_PLS_ICA.P_Loc.d{1,2}(:,i), 'k'), axis tight;
%         set(gca,'FontSize',10,'FontWeight','bold');
%         elseif nB==3
%         plot(collection(1).v,ComDim_Res_PLS_ICA.P_Loc.d{1,1}(:,i), 'r'), axis tight;
%         plot(max(collection(1).v)+collection(2).v,ComDim_Res_PLS_ICA.P_Loc.d{1,2}(:,i), 'k'), axis tight;
%         plot(max(collection(1).v)+max(collection(2).v)+collection(3).v,ComDim_Res_PLS_ICA.P_Loc.d{1,3}(:,i), 'g'), axis tight;
%         set(gca,'FontSize',10,'FontWeight','bold');
%             
%         elseif nB==4
%         plot(collection(1).v,ComDim_Res_PLS_ICA.P_Loc.d{1,1}(:,i), 'r'), axis tight;
%         plot(max(collection(1).v)+collection(2).v,ComDim_Res_PLS_ICA.P_Loc.d{1,2}(:,i), 'k'), axis tight;
%         plot(max(collection(1).v)+max(collection(2).v)+collection(3).v,ComDim_Res_PLS_ICA.P_Loc.d{1,3}(:,i), 'g'), axis tight;    
%         plot(max(collection(1).v)+max(collection(2).v)+max(collection(3).v)+collection(4).v,ComDim_Res_PLS_ICA.P_Loc.d{1,4}(:,i), 'b'), axis tight;
%         set(gca,'FontSize',10,'FontWeight','bold');
%         end
%         xlabel('Variables');
%         ylabel('Loadings');
%         title(['CC ',num2str(i)]);
% end
% 
% suptitle('Scaled Loadings');

for i=1:CDs
        figure,
        %subplot(CDs,1,i);
        
        
%         plot(ComDim_Res.P.d(:,i),'b:'), axis tight;
%         set(gca,'FontSize',10,'FontWeight','bold');
%         hold on;
        if nB==2
        subplot(1,2,1)
        plot(w1,ComDim_Res_PLS_ICA.P_Loc.d{1,1}(:,i), 'r'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        set(gca,'FontSize',10,'FontWeight','bold');
        subplot(1,2,2)
        plot(w2,ComDim_Res_PLS_ICA.P_Loc.d{1,2}(:,i), 'k'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        set(gca,'FontSize',10,'FontWeight','bold');
        suptitle(['CC ',num2str(i) ' (Scaled)']);
        
        elseif nB==3
        subplot(1,3,1)
        plot(w1,ComDim_Res_PLS_ICA.P_Loc.d{1,1}(:,i), 'r'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,3,2)
        plot(w2,ComDim_Res_PLS_ICA.P_Loc.d{1,2}(:,i), 'k'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,3,3)
        plot(w3,ComDim_Res_PLS_ICA.P_Loc.d{1,3}(:,i), 'g'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        set(gca,'FontSize',10,'FontWeight','bold');
        suptitle(['CC ',num2str(i) ' (Scaled)']);
            
            
        elseif nB==4
        subplot(1,4,1)
        plot(w1,ComDim_Res_PLS_ICA.P_Loc.d{1,1}(:,i), 'r'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,4,2)
        plot(w2,ComDim_Res_PLS_ICA.P_Loc.d{1,2}(:,i), 'k'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,4,3)
        plot(w3,ComDim_Res_PLS_ICA.P_Loc.d{1,3}(:,i), 'g'), axis tight; 
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,4,4)
        plot(w4,ComDim_Res_PLS_ICA.P_Loc.d{1,4}(:,i), 'b'), axis tight; 
        xlabel('Variables');
        ylabel('Loadings');
        set(gca,'FontSize',10,'FontWeight','bold');
        suptitle(['CC ',num2str(i) ' (Scaled)']);
        end
        
end