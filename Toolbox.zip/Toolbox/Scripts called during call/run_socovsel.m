%Script for running the socovsel for variable selection
%written by ...Puneet Mishra (29/05/2020)

%The scipt will be called by the GUI when the user selects to run the
%analysis
%a model will be saved which can be used for testing the model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if nB ==4
    X = [p1 p2 p3 p4];
    Xin{1}=1:size(evalin('base', 'p1'),2);
    Xin{2}=(1:size(evalin('base', 'p2'),2))+max(Xin{1});
    Xin{3}=(1:size(evalin('base', 'p3'),2))+max(Xin{2});
    Xin{4}=(1:size(evalin('base', 'p4'),2))+max(Xin{3});
elseif nB==3
     X = [p1 p2 p3];
     Xin{1}=1:size(evalin('base', 'p1'),2);
    Xin{2}=(1:size(evalin('base', 'p2'),2))+max(Xin{1});
    Xin{3}=(1:size(evalin('base', 'p3'),2))+max(Xin{2});
elseif nB==2
    X = [p1 p2];
    Xin{1}=1:size(evalin('base', 'p1'),2);
    Xin{2}=(1:size(evalin('base', 'p2'),2))+max(Xin{1});
elseif nB==1
    X = p1;
    Xin{1}=1:size(evalin('base', 'p1'),2);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
addpath([pwd '/socovsel']);
opt = socovsel_cv('options');  
opt.cvtype = CV;


blocks=nB;

if blocks==2
    pret={'mean','mean','mean'};
    lv=[10,10];
    X = {p1,p2};
elseif blocks==3
    pret={'mean','mean','mean','mean'};
    lv=[10,10,10];
    X = {p1,p2,p3};
elseif blocks==4
    pret={'mean','mean','mean','mean','mean'};
    lv=[10,10,10,10];
    X = {p1,p2,p3,p4};
end

socovselmodel=socovsel_cv(X,Y, lv, pret);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%plotting calibration statistics
SST=sum((Y-mean(Y)).^2); 
SSE=sum((Y-socovselmodel.OptModel.predY).^2); 
R2_C=1-SSE/SST;
RMSEC=sqrt(SSE/size(Y,1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
total_var = 0;  %counting total number of variables selected
for i = 1:nB
total_var = total_var + size(socovselmodel.OptModel.covsel(i).SelVar,2);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure, plot(Y,socovselmodel.OptModel.predY,'.b','MarkerSize',30);
set(gca,'FontSize',10,'FontWeight','bold');
lsline
xlabel('Measured');
ylabel('Predicted');
title([ 'Total variables : ' num2str(total_var)]);

biasc = mean(Y)-mean(socovselmodel.OptModel.predY);
str = ['R^2_c = ' num2str(round(R2_C,2)) ' RMSEC = ' num2str(round(RMSEC,3)) '  Bias = ' num2str(biasc)];
annotation('textbox', [0.2, 0.8, 0.35, 0.1], 'String',str);

% text(min(Y)+.1,max(socovselmodel.OptModel.predY)-0.1,.01,sprintf(['R^2c = ' num2str(R2_C)]),'FontSize',10,'FontWeight','bold');
% text(min(Y)+.1,max(socovselmodel.OptModel.predY)-0.2,.01,sprintf(['RMSEC = ' num2str(RMSEC)]),'FontSize',10,'FontWeight','bold');
% text(min(Y)+.1,max(socovselmodel.OptModel.predY)-0.3,.01,sprintf(['Bias = ' num2str(biasc)]),'FontSize',10,'FontWeight','bold');
varsel =[];
% plotting selected bands


figure, 
for i=1:nB
    k = socovselmodel.OptModel.covsel(i).SelVar;
    if isempty(k)
        subplot(1,nB,i)
        plot(eval(['w' num2str(i)]),X{1,i});
        set(gca,'FontSize',10,'FontWeight','bold');
        xlabel('Variables');
        ylabel('Signal intensity');
        title(['Sensor ' num2str(i) '   Vars = 0' ]);
        axis tight
    else
    subplot(1,nB,i)
    plot(eval(['w' num2str(i)]),X{1,i});
    axis tight
    sel = socovselmodel.OptModel.covsel(i).SelVar;
        for plo = 1:size(sel,2)
            xline(eval(['w' num2str(i) '(1,sel(1,plo))']),'g');
            hold on
        end
        hold off
    varsel = [varsel eval(['w' num2str(i) '(1,sel)'])];
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Variables');
    ylabel('Signal intensity');
    title(['Sensor ' num2str(i) '  Vars = ' num2str(size(socovselmodel.OptModel.covsel(i).SelVar,2))]);
    
    end
end

clear X Xin sel