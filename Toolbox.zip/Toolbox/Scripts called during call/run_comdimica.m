%COMDIM ICA (This script is for visualisation doing Independent compnent
%analysis for comdim)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
addpath([pwd '/comdim/COMDIM_Douglas']);

BlockName = [];
for i=1:nB
    collection(i).d = eval(['p' num2str(i)]);
    Samples_Nums = (1:size(collection(i).d,1))';
    Var_Nums = (1:size(collection(i).d,2));
    collection(i).v = Var_Nums;
    collection(i).i = Samples_Nums;
    BlockName=[BlockName;['X' num2str(i)]];
    clear Samples_Nums Var_Nums
end

Seg_Nums = (1:nB)';
XVar_Nums = (1:nB);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CDs=nF;
r=2;
c=2;

% Number of Common Components
Options.ndim = CDs;
% Normalise each data table
Options.normalise = 1;
% No comments during calculations
Options.loquace = 0;
% Output Local Scores, Scaled and Unscaled Loadings
Options.Output = 'TPL';
% compression method
Options.CompMethod ='Normal';

Options.SortICs = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Good for Prediction using comdim_pred_2019

addpath([pwd '/comdim']);
ComDim_Res = comdim_ICA_2019(collection,Options);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Sum_Sal_Dim=ComDim_Res.Sum_saliences_Dim.d;
 
 figure,
 for i=1:CDs
        subplot(1,CDs,i);
        bar(ComDim_Res.saliences.d(:,i),'r'), axis tight;
        set(gca,'FontSize',10,'FontWeight','bold');
        ylabel(['CC ',num2str(i)]);
        title(['Sum Sal. =', num2str(Sum_Sal_Dim(1,i))]);
 end
 suptitle('Saliences for COMDIM-ICA');
 
 %%%%%%%%%%%%%%%saliences%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 Sum_Sal_Tab=ComDim_Res.Sum_saliences_Tab.d;
 
 figure,
 subplot(1,3,1);
    bar(Sum_Sal_Tab,'r'), axis tight;
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Blocks');
    title('Saliences per Block');

%%Saliences per Dimension
 subplot(1,3,2);
    bar(ComDim_Res.Sum_saliences_Dim.d,'r'), axis tight;
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Components');
    title('Sum saliences per Dimension');

%%Variances per Dimension
    subplot(1,3,3);
    bar(ComDim_Res.explained.d,'r'), axis tight;
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Components');
    title('Variance per Dimension (%)');

    %suptitle(Model_Name{CC_mod,Comp});
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%scores%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure,
for i=1:CDs
        subplot(1,CDs,i);
        plot(ComDim_Res.Q.d(:,i),'b-o'), axis tight;
        set(gca,'FontSize',10,'FontWeight','bold');
        title(['CC ',num2str(i)]);
end
    suptitle('Global Scores for COMDIM-ICA');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%global scores in biplot for first three COMDIm-Component
figure,
 plot3(ComDim_Res.Q.d(:,1),ComDim_Res.Q.d(:,2),ComDim_Res.Q.d(:,3),'.r','MarkerSize',20); xlabel('CC1'); ylabel('CC2'); zlabel('CC3'); title('Global Scores 3 COMDIM components');axis tight;
 set(gca,'FontSize',12,'FontWeight','bold');
 text(ComDim_Res.Q.d(:,1),ComDim_Res.Q.d(:,2),ComDim_Res.Q.d(:,3),string(1:size(ComDim_Res.Q.d,1)),'FontWeight','bold');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Scaled loadings%%%%%%%%%%%%%%%%%%%%%%%%%%5
 for i=1:CDs
        figure,
        %subplot(CDs,1,i);
        
        
%         plot(ComDim_Res.P.d(:,i),'b:'), axis tight;
%         set(gca,'FontSize',10,'FontWeight','bold');
%         hold on;
        if nB==2
        subplot(1,2,1)
        plot(w1,ComDim_Res.P_Loc.d{1,1}(:,i), 'r'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        set(gca,'FontSize',10,'FontWeight','bold');
        subplot(1,2,2)
        plot(w2,ComDim_Res.P_Loc.d{1,2}(:,i), 'k'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        set(gca,'FontSize',10,'FontWeight','bold');
        suptitle(['CC ',num2str(i) ' (Scaled)']);
        
        elseif nB==3
        subplot(1,3,1)
        plot(w1,ComDim_Res.P_Loc.d{1,1}(:,i), 'r'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,3,2)
        plot(w2,ComDim_Res.P_Loc.d{1,2}(:,i), 'k'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,3,3)
        plot(w3,ComDim_Res.P_Loc.d{1,3}(:,i), 'g'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        set(gca,'FontSize',10,'FontWeight','bold');
        suptitle(['CC ',num2str(i) ' (Scaled)']);
            
            
        elseif nB==4
        subplot(1,4,1)
        plot(w1,ComDim_Res.P_Loc.d{1,1}(:,i), 'r'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,4,2)
        plot(w2,ComDim_Res.P_Loc.d{1,2}(:,i), 'k'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,4,3)
        plot(w3,ComDim_Res.P_Loc.d{1,3}(:,i), 'g'), axis tight; 
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,4,4)
        plot(w4,ComDim_Res.P_Loc.d{1,4}(:,i), 'b'), axis tight; 
        xlabel('Variables');
        ylabel('Loadings');
        set(gca,'FontSize',10,'FontWeight','bold');
        suptitle(['CC ',num2str(i) ' (Scaled)']);
        end
        
    end
    %suptitle('Scaled Loadings for COMDIM-PCA');   
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %Unscaled loadings
    for i=1:CDs
        figure,
        %subplot(CDs,1,i);
        
        
%         plot(ComDim_Res.P.d(:,i),'b:'), axis tight;
%         set(gca,'FontSize',10,'FontWeight','bold');
%         hold on;
        if nB==2
        subplot(1,2,1)
        plot(w1,ComDim_Res.Lx_Loc.d{1,1}(:,i), 'r'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        set(gca,'FontSize',10,'FontWeight','bold');
        subplot(1,2,2)
        plot(w2,ComDim_Res.Lx_Loc.d{1,2}(:,i), 'k'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        set(gca,'FontSize',10,'FontWeight','bold');
        suptitle(['CC ',num2str(i) ' (Unscaled)']);
        
        elseif nB==3
        subplot(1,3,1)
        plot(w1,ComDim_Res.Lx_Loc.d{1,1}(:,i), 'r'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,3,2)
        plot(w2,ComDim_Res.Lx_Loc.d{1,2}(:,i), 'k'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,3,3)
        plot(w3,ComDim_Res.Lx_Loc.d{1,3}(:,i), 'g'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        set(gca,'FontSize',10,'FontWeight','bold');
        suptitle(['CC ',num2str(i) ' (Unscaled)']);
            
            
        elseif nB==4
        subplot(1,4,1)
        plot(w1,ComDim_Res.Lx_Loc.d{1,1}(:,i), 'r'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,4,2)
        plot(w2,ComDim_Res.Lx_Loc.d{1,2}(:,i), 'k'), axis tight;
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,4,3)
        plot(w3,ComDim_Res.Lx_Loc.d{1,3}(:,i), 'g'), axis tight; 
        xlabel('Variables');
        ylabel('Loadings');
        subplot(1,4,4)
        plot(w4,ComDim_Res.Lx_Loc.d{1,4}(:,i), 'b'), axis tight; 
        xlabel('Variables');
        ylabel('Loadings');
        set(gca,'FontSize',10,'FontWeight','bold');
        suptitle(['CC ',num2str(i) ' (Unscaled)']);
        end
        
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Unscaled loadings%%%%%%%%%%%%%%%%%%%%%%%%%5

    