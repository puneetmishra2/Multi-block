%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%apply the sport pre-processing selected model on the new set ...Puneet Mishra (29/05/2020)

run prepare_test_data.m

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%applying the trained model based on sport pre-processing

pred = soplsmulti1_pred(test_data,model.OptModel);
predictions = pred.predY;


if exist('test_Y')
    SSTp = sum((test_Y-mean(test_Y)).^2);
    SSEp = sum((test_Y-pred.predY).^2);
    R2_P =  1-SSEp/SSTp;
    RMSEP = sqrt(SSEp/size(test_Y,1));
    figure,
    plot(test_Y,pred.predY,'.r','MarkerSize',20);
    lsline
    xlabel('Measured');
    ylabel('Predicted');
    title(['R^2_p = ' num2str(round(R2_P,2)) ' RMSEP = ' num2str(round(RMSEP,2))]);
    set(gca,'FontSize',12,'FontWeight','bold');
    
    clear yt pred SSTp SSEp R2_C RMSEC pred
else
    figure,
    plot(predictions,'.r','MarkerSize',30);
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Samples','FontWeight','bold','FontSize',10);
    ylabel('Predicted','FontWeight','bold','FontSize',10);
end
