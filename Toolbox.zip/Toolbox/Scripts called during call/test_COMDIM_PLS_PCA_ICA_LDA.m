%% test COMDIM PLS LDA models ...Puneet Mishra (29/05/2020)

run prepare_test_data.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
addpath([pwd '/comdim/Comdim_r']);
addpath([pwd '/comdim']);
addpath([pwd '/comdim/COMDIM_Douglas']);
BlockName = [];
for i=1:nB
    collection_Pred(i).d = test_data{1,i};
    Samples_Nums = (1:size(collection(i).d,1))';
    Var_Nums = (1:size(collection(i).d,2));
    collection_Pred(i).v = Var_Nums;
    collection_Pred(i).i = Samples_Nums;
    BlockName=[BlockName;['X' num2str(i)]];
    clear Var_Nums
end

res_pred_V8 = comdim_pred_2020(ComDim_Res, collection_Pred);

test_scores = res_pred_V8.U.d;
test_scores = test_scores(:,1:nF);

prediction_test = predict(comdim_mdl,test_scores);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if exist('test_Y')
overall_accuracy = sum(test_Y-prediction_test == 0)/size(test_Y,1);
predictions = prediction_test;

for i=1:size(unique(test_Y),1)
    accuracy_individual_test(1,i) = sum(test_Y(test_Y==i,:)-prediction_test(test_Y==i,:) == 0)/size(test_Y(test_Y==i,:),1);
end

figure, bar(accuracy_individual_test);
set(gca,'FontSize',10,'FontWeight','bold');
title(['Overall accuracy = ' num2str(overall_accuracy)]);
xlabel('Classes');
ylabel('Accuracy for individual class (Test set)');
grid on

else
   figure,
   predictions = prediction_test;
   plot(prediction_test,'.r','MarkerSize',30);
   set(gca,'FontSize',10,'FontWeight','bold');
   xlabel('Samples');
   ylabel('Predicted class');
   title('Predictions');
end
