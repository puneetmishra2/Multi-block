% This script is for running the SOPLS calibration and ploting the
% calibration curves ...Puneet Mishra (29/05/2020) (Wageninge University &
% Research)
% The script will be called by the GUI when the SOPLS option will be
% chosen
% At the end a model will be saved in the workspace which can be used for
% prediction on new data

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if nB ==4
    X = [p1 p2 p3 p4];
    Xin{1}=1:size(evalin('base', 'p1'),2);
    Xin{2}=(1:size(evalin('base', 'p2'),2))+max(Xin{1});
    Xin{3}=(1:size(evalin('base', 'p3'),2))+max(Xin{2});
    Xin{4}=(1:size(evalin('base', 'p4'),2))+max(Xin{3});
elseif nB==3
     X = [p1 p2 p3];
     Xin{1}=1:size(evalin('base', 'p1'),2);
    Xin{2}=(1:size(evalin('base', 'p2'),2))+max(Xin{1});
    Xin{3}=(1:size(evalin('base', 'p3'),2))+max(Xin{2});
elseif nB==2
    X = [p1 p2];
    Xin{1}=1:size(evalin('base', 'p1'),2);
    Xin{2}=(1:size(evalin('base', 'p2'),2))+max(Xin{1});
elseif nB==1
    X = p1;
    Xin{1}=1:size(evalin('base', 'p1'),2);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
addpath([pwd '/sopls_r']); % adding the folder with codes to the path 
blocks=nB;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% peparing the data for the model input
opt=sopls_cv('options'); 
opt.cvtype = CV;
if blocks==2
    pret={'mean','mean','mean'};
    lv=[10,10];
    X = {p1,p2};
elseif blocks==3
    pret={'mean','mean','mean','mean'};
    lv=[10,10,10];
    X = {p1,p2,p3};
elseif blocks==4
    pret={'mean','mean','mean','mean','mean'};
    lv=[10,10,10,10];
    X = {p1,p2,p3,p4};
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
opt=sopls_cv('options'); 
opt.cvtype = CV;
soplsmodel=sopls_cv(X,Y, lv, pret,opt); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%typ_cv='syst123';
%model=soplsmulti1_cv(X, Y, lv, pret, typ_cv,5);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% statistics


SST=sum((Y-mean(Y)).^2); 
SSE=sum((Y-soplsmodel.OptModel.predY).^2); 
R2_C=1-SSE/SST;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%plotting calibration statistics
figure, plot(Y,soplsmodel.OptModel.predY,'.b','MarkerSize',30);
set(gca,'FontSize',10,'FontWeight','bold');
lsline
xlabel('Measured','FontWeight','bold','FontSize',10);
ylabel('Predicted','FontWeight','bold','FontSize',10);
title('Calibration set');

biasc = mean(Y)-mean(soplsmodel.OptModel.predY);

str = ['R^2_c = ' num2str(round(R2_C,2)) ' RMSEC = ' num2str(round(soplsmodel.OptModel.rmsec,3)) '  Bias = ' num2str(biasc)];
 annotation('textbox', [0.2, 0.8, 0.35, 0.1], 'String',str);
% text(min(Y)+.1,max(soplsmodel.OptModel.predY)-0.1,.01,sprintf(['R^2c = ' num2str(R2_C)]),'FontSize',10,'FontWeight','bold');
% text(min(Y)+.1,max(soplsmodel.OptModel.predY)-0.2,.01,sprintf(['RMSEC = ' num2str(soplsmodel.OptModel.rmsec)]),'FontSize',10,'FontWeight','bold');
% text(min(Y)+.1,max(soplsmodel.OptModel.predY)-0.3,.01,sprintf(['),'FontSize',10,'FontWeight','bold');



clear SST  SSE R2_C RMSEC

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plotting bar graph of number of LVs selected from each block
figure,
bar(soplsmodel.CV.LVopt);
set(gca,'FontSize',10,'FontWeight','bold');
title('Numer of LVs selected per block','FontWeight','bold','FontSize',10);
xlabel('Blocks','FontWeight','bold','FontSize',10);
ylabel('LVs selected','FontWeight','bold','FontSize',10);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plotting the final regression vector

figure,
set(gca,'FontSize',10,'FontWeight','bold');
if nB==2
    subplot(1,2,1)
    if isempty(soplsmodel.OptModel.plsmodels(1).Borth)
        plot(w1,zeros(size(Xin{1},2)),'b');
        axis tight
    else
        plot(w1,soplsmodel.OptModel.plsmodels(1).Borth),'b';
        axis tight
    end
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Variables');
    ylabel('Regression weights');
    title('Block 1');
    
    subplot(1,2,2)
    if isempty(soplsmodel.OptModel.plsmodels(2).Borth)
        plot(w2,zeros(size(Xin{2},2)),'r');
        axis tight
    else
        plot(w2,soplsmodel.OptModel.plsmodels(2).Borth,'r');
        axis tight
    end
    
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Variables');
    ylabel('Regression weights');
    title('Block 2');

elseif nB==3
     subplot(1,3,1)
     if isempty(soplsmodel.OptModel.plsmodels(1).Borth)
        plot(w1,zeros(size(Xin{1},2)),'b');
        axis tight
    else
        plot(w1,soplsmodel.OptModel.plsmodels(1).Borth),'b';
        axis tight
     end
     set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Variables');
    ylabel('Regression weights');
    title('Block 1');
    
    subplot(1,3,2)
    if isempty(soplsmodel.OptModel.plsmodels(2).Borth)
        plot(w2,zeros(size(Xin{2},2)),'r');
        axis tight
    else
        plot(w2,soplsmodel.OptModel.plsmodels(2).Borth,'r');
        axis tight
    end
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Variables');
    ylabel('Regression weights');
    title('Block 2');
    
    subplot(1,3,3)
    if isempty(soplsmodel.OptModel.plsmodels(3).Borth)
        plot(w3,zeros(size(Xin{3},2)),'c');
        axis tight
    else
        plot(w3,soplsmodel.OptModel.plsmodels(3).Borth),'c';
        axis tight
    end
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Variables');
    ylabel('Regression weights');
    title('Block 3');
   
    
elseif nB==4
    subplot(1,4,1)
     if isempty(soplsmodel.OptModel.plsmodels(1).Borth)
        plot(w1,zeros(size(Xin{1},2)),'b');
        axis tight
    else
        plot(w1,soplsmodel.OptModel.plsmodels(1).Borth),'b';
        axis tight
     end
     set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Variables');
    ylabel('Regression weights');
    title('Block 1');

    subplot(1,4,2)
    if isempty(soplsmodel.OptModel.plsmodels(2).Borth)
        plot(w2,zeros(size(Xin{2},2)),'r');
        axis tight
    else
        plot(w2,soplsmodel.OptModel.plsmodels(2).Borth,'r');
        axis tight
    end 
    
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Variables');
    ylabel('Regression weights');
    title('Block 2');
    
    subplot(1,4,3)
     if isempty(soplsmodel.OptModel.plsmodels(3).Borth)
        plot(w3,zeros(size(Xin{3},2)),'c');
        axis tight
    else
        plot(w3,soplsmodel.OptModel.plsmodels(3).Borth),'c';
        axis tight
     end
     set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Variables');
    ylabel('Regression weights');
    title('Block 3');
    
    subplot(1,4,4)
    if isempty(soplsmodel.OptModel.plsmodels(4).Borth)
        plot(w4,zeros(size(Xin{4},2)),'g');
        axis tight
    else
        plot(w4,soplsmodel.OptModel.plsmodels(4).Borth,'g');
        axis tight
    end
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Variables');
    ylabel('Regression weights');
    title('Block 4');
    
end
    suptitle('Regression vector');


   clear X Xin