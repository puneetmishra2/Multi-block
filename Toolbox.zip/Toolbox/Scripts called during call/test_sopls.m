% This script is for running the SOPLS calibration and plotting the
% calibration curves ...Puneet Mishra (29/05/2020)(Wageninge University &
% Research)
% The script will be called by the GUI when the SOPLS option will be
% chosen

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
addpath([pwd '/sopls_r']);

run prepare_test_data.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% application of the model
pred=sopls_pred(test_data,soplsmodel.OptModel);
predictions = pred.predY;

%plotting prediction statistics
if exist('test_Y')
    
    SSTp=sum((test_Y-mean(test_Y)).^2);
    SSEp=sum((test_Y-pred.predY).^2);
    R2_P=1-SSEp/SSTp;
    figure, plot(test_Y,pred.predY,'.r','MarkerSize',30);
    lsline
    xlabel('Measured');
    ylabel('Predicted');
    
    title('Test set');
    set(gca,'FontSize',10,'FontWeight','bold');
    
    biasp = mean(test_Y)-mean(pred.predY);
    
    str = ['R^2_p = ' num2str(round(R2_P,2)) ' RMSEP = ' num2str(round(pred.rmsep,3)) '  Bias = ' num2str(biasp)];
    annotation('textbox', [0.2, 0.8, 0.35, 0.1], 'String',str);
    
    % text(min(test_Y)+.1,max(pred.predY)-0.1,.01,sprintf(['R^2p = ' num2str(R2_P)]),'FontSize',10,'FontWeight','bold');
    % text(min(test_Y)+.1,max(pred.predY)-0.2,.01,sprintf(['RMSEP = ' num2str(pred.rmsep)]),'FontSize',10,'FontWeight','bold');
    % text(min(test_Y)+.1,max(pred.predY)-0.3,.01,sprintf(['Bias = ' num2str(biasp)]),'FontSize',10,'FontWeight','bold');
    
    clear SSTp  SSEp R2_P RMSEP
    
else
    
    figure,
    plot(predictions,'.r','MarkerSize',30);
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Samples','FontWeight','bold','FontSize',10);
    ylabel('Predicted','FontWeight','bold','FontSize',10);
end