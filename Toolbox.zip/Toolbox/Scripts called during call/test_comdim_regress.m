% testing comdim based regression models on test datasets ...Puneet Mishra (29/05/2020)


run prepare_test_data.m

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath([pwd '/comdim/Comdim_r']);
addpath([pwd '/comdim']);
addpath([pwd '/comdim/COMDIM_Douglas']);
BlockName = [];
for i=1:nB
    collection_Pred(i).d = test_data{1,i};
    Samples_Nums = (1:size(collection(i).d,1))';
    Var_Nums = (1:size(collection(i).d,2));
    collection_Pred(i).v = Var_Nums;
    collection_Pred(i).i = Samples_Nums;
    BlockName=[BlockName;['X' num2str(i)]];
    clear Var_Nums
end

% predcition for scores with comdim
res_pred_V8 =comdim_pred_2020(ComDim_Res, collection_Pred);

test_scores = res_pred_V8.U.d;
test_scores = test_scores(:,1:nF);

test_pred = predict(comdim_mdl,test_scores);
predictions = test_pred;

% plotting statistics

if exist('test_Y')
    SSTp=sum((test_Y-mean(test_Y)).^2);
    SSEp=sum((test_Y-test_pred).^2);
    R2_P = corr(test_Y,test_pred);
    R2_P = R2_P*R2_P;
    RMSEP=sqrt(SSEp/size(test_Y,1));
    
    figure,
    plot(test_Y,test_pred,'.r','MarkerSize',30);
    set(gca,'FontSize',10,'FontWeight','bold');
    lsline
    xlabel('Measured','FontWeight','bold','FontSize',10);
    ylabel('Predicted','FontWeight','bold','FontSize',10);
    title('Test set');
    biasp = mean(test_Y)-mean(test_pred);
    
    str = ['R2 = ' num2str(R2_P) ' RMSEP = ' num2str(round(RMSEP,3)) '  Bias = ' num2str(biasp)];
    annotation('textbox', [0.2, 0.8, 0.35, 0.1], 'String',str);
else
    figure,
    plot(predictions,'.r','MarkerSize',30);
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Samples','FontWeight','bold','FontSize',10);
    ylabel('Predicted','FontWeight','bold','FontSize',10);
end
% text(min(test_Y)+.1,max(test_pred)-0.1,.01,sprintf(['R^2p = ' num2str(R2_P)]),'FontSize',10,'FontWeight','bold');
% text(min(test_Y)+.1,max(test_pred)-0.2,.01,sprintf(['RMSEP = ' num2str(RMSEP)]),'FontSize',10,'FontWeight','bold');
% text(min(test_Y)+.1,max(test_pred)-0.3,.01,sprintf(['Bias = ' num2str(biasp)]),'FontSize',10,'FontWeight','bold');
