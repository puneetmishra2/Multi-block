%script for applicaiton of covsel trained model for a new test dataset
%Script for testig the socovsel on new data
%written by ...Puneet Mishra (29/05/2020)
%The scipt will be called by the GUI when the user selects to run the
%analysis
%a model will be saved which can be used for testing the model

addpath([pwd '/socovsel']);


run prepare_test_data.m

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% application of the model

pred = socovsel_pred(test_data,test_Y, socovselmodel.OptModel);
predictions = pred.predY;

if exist('test_Y')
    %plotting prediction statistics
    SSTp=sum((test_Y-mean(test_Y)).^2);
    SSEp=sum((test_Y-pred.predY).^2);
    R2_P=1-SSEp/SSTp;
    figure, plot(test_Y,pred.predY,'.r','MarkerSize',30);
    set(gca,'FontSize',14,'FontWeight','bold');
    lsline
    xlabel('Measured');
    ylabel('Predicted');
    title(['Total Variables : ' num2str(total_var)]);
    
    biasp = mean(test_Y)-mean(pred.predY);
    
    str = ['R^2_p = ' num2str(round(R2_P,2)) ' RMSEP = ' num2str(round(pred.rmsep,3)) '  Bias = ' num2str(biasp)];
    annotation('textbox', [0.2, 0.8, 0.35, 0.1], 'String',str);
    
    % text(min(test_Y)+.1,max(pred.predY)-0.1,.01,sprintf(['R^2p = ' num2str(R2_P)]),'FontSize',10,'FontWeight','bold');
    % text(min(test_Y)+.1,max(pred.predY)-0.2,.01,sprintf(['RMSEP = ' num2str(pred.rmsep)]),'FontSize',10,'FontWeight','bold');
    % text(min(test_Y)+.1,max(pred.predY)-0.3,.01,sprintf(['Bias = ' num2str(biasp)]),'FontSize',10,'FontWeight','bold');
    
    clear SSTp  SSEp R2_P RMSEP
    
else
    figure,
    plot(predictions,'.r','MarkerSize',30);
    set(gca,'FontSize',10,'FontWeight','bold');
    xlabel('Samples','FontWeight','bold','FontSize',10);
    ylabel('Predicted','FontWeight','bold','FontSize',10);
end