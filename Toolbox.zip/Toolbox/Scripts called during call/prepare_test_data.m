% script for preparing the test dataset with the same pre-processing as
% selected by the user for calibration set ...Puneet Mishra (29/05/2020)

test_data = test_original;
for i=1:nB
    if eval(['chp' num2str(i)])==2
        test_data{1,i} = preprocesspt(test_data{1,i},eval(['chp' num2str(i)]),eval(['win_p' num2str(i)]),eval(['pol_p' num2str(i)]));%block 1 pre-processing start here
        temp = preprocesspt(eval(['x' num2str(i)]),eval(['chp' num2str(i)]),eval(['win_p' num2str(i)]),eval(['pol_p' num2str(i)]));
    else
        test_data{1,i} = preprocesspt(test_data{1,i},eval(['chp' num2str(i)]));%block 1 pre-processing start here
        temp = preprocesspt(eval(['x' num2str(i)]),eval(['chp' num2str(i)]));
    end
    
    
    if eval(['chc' num2str(i)]) == 4 % special step of MSC application
        test_data{1,i} = corr_msc(test_data{1,i},mean(temp));
    elseif eval(['chc' num2str(i)]) == 8 % special step of vsn application
        test_data{1,i} = vsn(test_data{1,i},eval(['res' num2str(i)]));
    else
        test_data{1,i} = correctionpt(test_data{1,i},eval(['chc' num2str(i)]));
    end
    
    if eval(['chn' num2str(i)])==4
        test_data{1,i} = derivativept(test_data{1,i},eval(['chn' num2str(i)]),eval(['win_d' num2str(i)]),eval(['pol_d' num2str(i)]),eval(['der_d' num2str(i)]));
    else
        test_data{1,i} = derivativept(test_data{1,i},eval(['chn' num2str(i)]));
    end
end
