
% SCRIPT FOR RUNNING THE SOPLSDA CALIBRATION ROUTINE AFTER GETTING THE PRE-PROCESSED DATASET
%...Puneet Mishra (29/05/2020)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% SOPLSDA FUNCTION ARE ADDED TO THE PATH
addpath([pwd '/soplslda']);

% OPTIONS FOR SOPLSDA ARE PREPARED

opt=soplslda_cv('options');
opt.cvtype = CV;


blocks=nB;

if blocks==2
    pret={'mean','mean','mean'};
    lv=[10,10];
    X = {p1,p2};
elseif blocks==3
    pret={'mean','mean','mean','mean'};
    lv=[10,10,10];
    X = {p1,p2,p3};
elseif blocks==4
    pret={'mean','mean','mean','mean','mean'};
    lv=[10,10,10,10];
    X = {p1,p2,p3,p4};
end

% CROSS-VALIDATION FOR SOPLSDA IS PERFORMED 

soplsdamodel=soplslda_cv(X,Y,lv,pret); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% PREDICTION FOR THE CALIBRAITON DATASET IS PERFORMED TO ESTIMATE
% STATISTICS AND PLOTTING

pred = soplslda_pred(X,soplsdamodel.OptModel); 

predY = pred.predY;

[~,ind]= max(pred.predY');
ind = ind';

overall_accuracy = (sum(Y-ind == 0)/size(Y,1)) *100;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ACCURACY FOR INDIVIDUAL CLASS IS CALCULATES
for i=1:size(unique(Y),1)
    accuracy_individual(1,i) = sum(Y(Y==i,:)-ind(Y==i,:) == 0)/size(Y(Y==i,:),1);
end

% BAR PLOT EXPLAINING ACCURACY FOR EACH CLASS IS PLOTTED

figure, bar(accuracy_individual);
set(gca,'FontSize',10,'FontWeight','bold');
title(['Overall accuracy = ' num2str(overall_accuracy) ' %']);
xlabel('Classes');
ylabel('Accuracy for individual class (Training set)');
grid on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear X Xin
