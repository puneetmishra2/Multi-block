% running comdim based regression (This script is designed to get input
% data and run the comdim regression based on user choice) ...Puneet Mishra (29/05/2020)

addpath([pwd '/comdim/Comdim_r']);
addpath([pwd '/comdim']);
addpath([pwd '/comdim/COMDIM_Douglas']);
BlockName = [];
for i=1:nB
    collection(i).d = eval(['p' num2str(i)]);
    Samples_Nums = (1:size(collection(i).d,1))';
    Var_Nums = (1:size(collection(i).d,2));
    collection(i).v = Var_Nums;
    collection(i).i = Samples_Nums;
    BlockName=[BlockName;['X' num2str(i)]];
    clear Var_Nums
end

% options and setting
CDs = 20;
% Number of Common Components
Options.ndim =CDs;
% Normalise each data table
Options.normalise =1;
% No comments during calculations
Options.loquace =0;
% Output Local Scores, Scaled and Unscaled Loadings
Options.Output='TPL';
% for 'Wide' & 'Tall'
Options.Partitions = 3; 

Options.SortICs =0; % for ICA
Options.CompMethod = Compression;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
if PC == 1
    ComDim_Res = comdim_PCA_2020(collection,Options);
    
elseif PC==2
    ComDim_Res = comdim_ICA_2019(collection,Options);
    
elseif PC==3
    
    ComDim_Res = comdim_PLS_2020(collection,Y, Options);
     
elseif PC==4
    
    ComDim_Res = comdim_PLS_ICA_2019(collection,Y, Options);
    
end

% performing regression on global scores and optimising with
% cross-validation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
scores = ComDim_Res.Q.d;
opt=cross_val_mlr('options');
%opt.cvtype = CV;
rmsecv = cross_val_mlr(scores,Y,opt);

