%script for running the a-comdim for data vislualisation of designed
%experiments ...Puneet Mishra (29/05/2020)

%% "ANOVA" decomposition
addpath([pwd '/acomdim']);

% Grps=Groupes_Balanced;
[nR,nC]=size(p1);
SampleNums=[1:nR]';
VarNums=[1:nC];


Grps=DOEbread_mat(:,1:4);
% Replcates are in DOEbread_mat(:,5)

for g=1:size(Grps,2)
    groups.d=Grps(:,g);
    
    Figure_DNR(1);
    h=colored_curves(s,groups);
    suptitle(['Groups ', DOEbread.class(1,2,g)]);
end

%% Do A_ComDim on X
Options.Plots=2;
Options.Dims=10;
Options.Samples=1;
Options.CompMethod='Normal';

[A_ComDimIn, A_ComDimOut, A_Collection]=A_ComDim_2016(X, Grps, Options);

