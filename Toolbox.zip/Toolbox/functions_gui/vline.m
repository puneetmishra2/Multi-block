function vline(x)
% the function will plot vertical line on the plot and will be used in the
% case of variable selection

[~,j] = size(x);
x = x';
drawline = axis;

if ishold
  for i=1:j
    plot([1 1]*x(i,1),drawline(1:2),'-r');
  end
else
  hold on
  for i=1:j
    plot([1 1]*x(i,1),drawline(1:2),'-r');
  end
  hold off
  
end
