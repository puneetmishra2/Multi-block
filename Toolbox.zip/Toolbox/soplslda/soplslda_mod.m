function model=soplslda_mod(X, cl, LV, pret, ldaX, prior)
% soplslda_mod Trains a sequential and orthogonalized PLS-LDA model
%   The function soplslda_mod calculates  a sequential and orthogonalized 
%   PLS-LDA (SO-PLS-LDA) multi-block classification model on training data.
%   
%   INPUTS:
%       X = cell array of predictor blocks (of length nblocks) 
%      cl = numerical vector coding for class belonging
%      LV = number of LVs to be extracted for each block (can be either
%           a scalar (same number for each block) or a vector (of length nblocks)
%    pret = a cell array (length nblocks+1) containing the desired
%           pretreatments for the X and Y (the last component) blocks.
%           can take values 'none', 'mean', 'auto'.
%    ldaX = ['ypred' | 'scores'] Defines whether the LDA model should be 
%           calculated on the Y predicted by SO-PLS or on the SO-PLS scores.
%   OPTIONAL INPUT:
%   prior = [{'uniform'} | 'frequency'] Defines whether uniform priors or priors 
%           based on number of training samples per class should be used when 
%           calculating the LDA model. If prior is a vector (length: number 
%           of classes), then custom priors are input. If omitted, uniform
%           priors are used.
%                                   
%
%   OUTPUT:
%   model = a structure array with all the results. 
%
%   I/O:
%           model=soplslda_mod(X,cl, LV, pret, ldaX, prior); 
%           model=soplslda_mod(X,cl, LV, pret, ldaX); 
%
%           
% Written by Federico Marini 
% Version: 19/04/2020


nblock=length(X);
if nargin<6 || isempty(prior)
    prior='uniform';
end

%%% Creation of the class matrix
clnum=unique(cl); 
ncl=length(clnum);
clnew=zeros(size(cl));
Y=zeros(size(X,1), ncl); 
for j=1:ncl
    sj=find(cl==clnum(j)); 
    clnew(sj)=j; 
    Y(sj, j)=ones(length(sj),1); 
end


if max(size(LV))==1
    LV=repmat(LV, 1, nblock);
end
Xp=cell(size(X));
preppars=cell(nblock+1,2);


for i=1:nblock
    [Xp{i},preppars{i,1},preppars{i,2}]=prepfn(X{i},pret{i});
end
[Yc,preppars{nblock+1,1},~]=prepfn(Y,'mean');
[yu, ys, preppars{nblock+1,2}]=svds(Yc, ncl-1); 

Yp=yu*ys; 

model.preptype=pret;
model.preppars=preppars;
model.nblock=nblock;

Tall=[];
Yres=Yp;
Qstar=cell(1,nblock);


for i=1:nblock
    
    if LV(i)~=0
        
        if i==1||isempty(Tall)
            Xo=Xp{i}; D=[];
        else
            Xo=(eye(size(Xp{i},1))-(Tall/(Tall'*Tall)*Tall'))*Xp{i};
            D=(Tall'*Tall)\Tall'*Xp{i};
        end
        [T,P,V,W,Q]=pls2fn(Xo,Yp,LV(i));
        Tall=[Tall T];
        model.plsmodels(i).scoresX=T;
        model.plsmodels(i).loadsX=P;
        model.plsmodels(i).weightsX=W;
        model.plsmodels(i).VweightsX=V;
        model.plsmodels(i).YloadsX=Q;
        model.plsmodels(i).Dmatrix=D;
        model.plsmodels(i).Borth=V*Q';
        Qstar{i}=Q';
        for j=1:i-1
            if j==1&&~isempty(Qstar{j})
                Qstar{j}=Qstar{j}-D(1:LV(j),:)*V*Q';
            else
                if ~isempty(Qstar{j})
                    Qstar{j}=Qstar{j}-D(sum(LV(1:j-1))+1:sum(LV(1:j)),:)*V*Q';
                end
            end
        end
        
        Yres=Yres-T*Q'; %Deflation of the Y wrt to the contribution of the X block
        
    else
        
        model.plsmodels(i).scoresX=[];
        model.plsmodels(i).loadsX=[];
        model.plsmodels(i).weightsX=[];
        model.plsmodels(i).VweightsX=[];
        model.plsmodels(i).YloadsX=[];
        model.plsmodels(i).Dmatrix=[];
        model.plsmodels(i).Borth=[];
        Qstar{i}=[];
        
    end
    
    
    
end

Yhat=zeros(size(Yp));
for i=1:nblock
    model.plsmodels(i).Qstar=Qstar{i};
    model.reg{i}=model.plsmodels(i).VweightsX*Qstar{i};
    if ~isempty(model.reg{i})
        Yhat=Yhat+Xp{i}*model.reg{i};
    end
end

YPred=unprepfn(Yhat*preppars{end,2}','mean',preppars{end,1},[]);
model.concscores=Tall; 
model.predYsvd=Yhat;
model.predY=YPred;
model.resY=Y-YPred;
model.rmsec=sqrt(sum((model.resY).^2,1)/size(Y,1));
model.bias=mean(model.resY);
model.r2=1-(sum((model.resY).^2,1)./sum((Y-repmat(mean(Y), size(Y,1), 1)).^2,1));

switch ldaX
    case 'ypred'
        mlda=RClda(Yhat, cl, prior);
    case 'scores'
        mlda=RClda(Tall, cl,prior);
end

model.ldaX=ldaX;
model.lda=mlda;








%%%%%%%%%%%%%%%%
function [Mp,mm,sm]=prepfn(X,pret1)
%Preprocessing routine. Performs mean centering ('mean'), autoscaling
%('auto') or no pretreatment ('none')

nt=size(X,1);
switch pret1
    case 'none'
        Mp=X;
        mm=[];
        sm=[];
    case 'mean'
        mm=mean(X);
        sm=[];
        Mp=X-repmat(mm, nt, 1);
    case 'auto'
        mm=mean(X);
        sm=std(X);
        Mp=(X-repmat(mm, nt, 1))./repmat(sm,nt, 1);
end

%%%%%%%%%%%%%%%%%%
function Mn=unprepfn(X,pret1,mm,sm)
%Preprocessing routine. Applies preprocessing to new matrices using the parameters
%calculated on the training set. Performs mean centering ('mean'), autoscaling
%('auto') or no pretreatment ('none')

nt=size(X,1);
switch pret1
    case 'none'
        Mn=X;
        
    case 'mean'
        Mn=X+repmat(mm, nt, 1);
    case 'auto'
        Mn=(X.*repmat(sm,nt, 1))+repmat(mm, nt, 1);
end


%%%%%%%%%%%%%%%%%%
function [T,P,V,W,Q]=pls2fn(X,Y,facts)

E=X; F=Y; % Set E0=X and F0=Y
W=[]; T=[]; P=[]; C=[]; Q=[]; U=[];   %Initialization of the matrices
for i=1:facts                         %Loop over the number of LVs
    [~,b]=max(std(F));      %Initial estimate of u as the Y(F) column with the largest variance
    u_old=F(:,b);
    crit=1;                 %initializing the convergence criterion
    while crit>10.^(-9)      %loop for the computation of the ith component
        w=E'*u_old;
        w=w./sqrt(w'*w);
        t=E*w;
        q=F'*t; q=q./norm(q);
        u=F*q;
        crit=norm(u-u_old)./norm(u_old);  %check for convergence.
        u_old=u;
    end
    
    p=E'*t./(t'*t); c=u'*t./(t'*t);
    W=[W w]; T=[T t]; P=[P p]; C=[C c]; Q=[Q q]; U=[U u];
    E=E-t*p'; F=F-c*t*q';  %deflation of X and Y
end
%Transform Q to be consistent with Y=TQ'+F
Q=Q*diag(C);

V=W/(P'*W); %Regression coefficients

