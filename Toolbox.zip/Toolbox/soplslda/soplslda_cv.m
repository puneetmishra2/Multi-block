function model=soplslda_cv(varargin)
% soplslda_cv sequential and orthogonalized PLS-LDA with cross-validation
%   The function sopls_cv uses cross-validation for selecting the optimal 
%   complexity of a sequential and orthogonalized PLS-LDA (SO-PLS-LDA) multi-block 
%   classification model. 
%   After the model selection phase, it also calculates the final SO-PLS-LDA
%   model on the whole training data, based on the optimal model complexity.
%
%   INPUTS:
%       X = cell array of predictor blocks (of length nblocks) 
%      cl = numerical vector coding for class belonging
%   LVmax = maximum number of LVs to be tested for each block (can be either
%           a scalar (same number for each block) or a vector (of length nblocks)
%    pret = a cell array (length nblocks) containing the desired
%           pretreatments for the X blocks.
%           Can take values 'none', 'mean', 'auto'.
%   OPTIONAL INPUT:
%     opt = a structure array with options (if not provided, default options
%           are used. Fields are: 
%               cvtype: ['loo' | {'syst123'} | 'syst111'] Governs the
%                                   way cancelation groups are defined.
%           cvsegments: {5}         Number of cancelation groups. 
%                 ldaX: [{'ypred'} | 'scores'] Defines whether the LDA model
%                                   should be calculated on the Y predicted
%                                   by SO-PLS or on the SO-PLS scores.
%                prior: [{'uniform'} | 'frequency'] Defines whether uniform
%                                   priors or priors based on number of
%                                   training samples per class should be
%                                   used when calculating the LDA model. If
%                                   prior is a vector (length: number of
%                                   classes), then custom priors are input.
%                LVsel: ['rmse' | {'cerr'} | 'acc' | 'manual'] Governs whether   
%                                   the optimal number of LVs is automatically 
%                                   (based on either the RMSECV, the total 
%                                   classification error in CV or 1-accuracy 
%                                   in CV) or manually selected.
%             Mageplot: ['off' | {'best'} ! 'all'] Defines the level of display 
%                                   of the M?ge plot. In 'best', only the
%                                   combination of LVs leading to the
%                                   minimum error for each total model
%                                   complexity are displayed.
%              output: {'full'}     If selected, 'full' determines a larger amounts
%                                   of details to be saved in the model
%                                   output.
%     Default options can be obtained by writing: 
%           opt=soplslda_cv('options'); 
%
%   OUTPUT:
%   model = a structure array with all the results. CV results are saved in the 
%           field model.CV, while the final model in model.OptModel
%
%   I/O:
%           model=soplslda_cv(X,cl, LVmax, pret, opt); 
%           model=soplslda_cv(X,cl, LVmax, pret); 
%           
% Written by Federico Marini 
% Version: 19/04/2020


if nargin==1 && strcmp(varargin{1}, 'options')
    model.cvtype='syst123';
    model.cvsegments=5;
    model.ldaX='ypred';
    model.prior='uniform';
    model.LVsel='cerr';
    model.Mageplot='best';
    model.output='full';
    return
    
elseif nargin==5
    X=varargin{1};
    cl=varargin{2};
    LVmax=varargin{3};
    pret=varargin{4};
    opt=varargin{5};
    
elseif nargin==4
    X=varargin{1};
    cl=varargin{2};
    LVmax=varargin{3};
    pret=varargin{4};
    opt.cvtype='syst123';
    opt.cvsegments=5;
    opt.ldaX='ypred';
    opt.prior='uniform';
    opt.LVsel='cerr';
    opt.Mageplot='best';
    opt.output='full';
end

cvtype=opt.cvtype;
segments=opt.cvsegments;

if size(cl,1)==1
    cl=cl';
end
ncl=length(unique(cl));


nblock=length(X);

if max(size(LVmax))==1
    LVmax=repmat(LVmax, 1, nblock);
end
ntot=size(X{1},1); %Total number of samples
if strcmp(cvtype, 'loo')  %Loo cross-validation corresponds to syst123 with N segments
    cvtype='syst123';
    segments=ntot;
end

L=arrayfun(@(c) 0:c, LVmax, 'un', 0);
[LVcomb{nblock:-1:1}] = ndgrid(L{nblock:-1:1}) ;
LVcomb = reshape(cat(nblock+1,LVcomb{:}), [], nblock);
ncomb=size(LVcomb,1);
rmsecv=zeros(ncomb,1);
Ypredcv=cell(ncomb,1);
Cpredcv=cell(ncomb,1);
cmcv=cell(ncomb,1);
for i=1:ncomb
    cmcv{i}=zeros(ncl,ncl);
end


for j=1:segments %Beginning of the crossvalidation loop
    
    switch cvtype
        case 'syst123'    %venetian blind cross-validation
            t=j:segments:ntot; %Calibration set
            m=1:ntot; m(t)=[]; %Validation set
            
        case 'syst111'    %contiguous blocks
            ns=ceil(ntot./segments);  %number of samples in each group
            if j==segments
                t=(j-1)*ns+1:ntot; %Validation set
            else
                t=(j-1)*ns+1:j*ns; %Calibration set
            end
            m=[1:(j-1)*ns ns*j+1:ntot]; %camp. nel set di calib.
    end
    
    Xm=cell(size(X)); 
    Xt=cell(size(X));
    
    for i=1:nblock
        Xm{i}=X{i}(m,:);
        Xt{i}=X{i}(t,:);
    end
    clm=cl(m,:);
    clt=cl(t,: );
    
    for nn=1:ncomb
        
        
        if sum(LVcomb(nn,:))~=0,
            
            
            sm=soplslda_mod(Xm, clm, LVcomb(nn,:), pret, opt.ldaX, opt.prior);
            sp=soplslda_pred(Xt, clt, sm);
            
        else
            sm=soplslda_mod(Xm, clm, LVcomb(nn,:), pret, 'ypred', opt.prior);
            sp=soplslda_pred(Xt, clt, sm);
        end
        
        rmsecv(nn)=rmsecv(nn)+sum(sum((sp.resY).^2));
        Cpredcv{nn}(t,:)=sp.lda.predclassorig;
        Ypredcv{nn}(t,:)=sp.predY;
        cmcv{nn}=cmcv{nn}+sp.lda.class.confmatrix;
        
    end
    
end

crate=cell(ncomb,1);
sens=zeros(ncomb,ncl);
spec=zeros(ncomb, ncl);
cerr=zeros(ncomb,1);
acc=zeros(ncomb,1);

for ni=1:ncomb
    crate{ni}=cmcv{ni}./repmat(sum(cmcv{ni},2),1,ncl);
    sens(ni,:)=diag(crate{ni})';
    for i=1:ncl
        spec(ni,i)=sum(sum(cmcv{ni}([1:i-1 i+1:end],[1:i-1 i+1:end])))/sum(sum(cmcv{ni}([1:i-1 i+1:end],:)));
    end
    cerr(ni)=1-mean(sens(ni,:));
    acc(ni)=sum(diag(cmcv{ni}))/ntot;
end
rmsecv=sqrt(rmsecv./ntot);

mmage=classmageplot(rmsecv,cerr, acc, LVcomb,opt.LVsel, opt.Mageplot);
mfin=soplslda_mod(X, cl, mmage.lvopt, pret, opt.ldaX, opt.prior);

model.OptModel=mfin;
model.CV.LVcomb=LVcomb;
model.CV.rmsecv=rmsecv;
model.CV.classerr=cerr;
model.CV.accuracy=acc;
model.CV.LVopt=mmage.lvopt;
model.CV.LVcombidx=mmage.optidx; 
model.CV.rmsecvopt=mmage.rmseopt;
model.CV.classerropt=mmage.cerropt;
model.CV.accuracyopt=mmage.accopt;
model.CV.predclassopt=Cpredcv{mmage.optidx};
model.CV.predYopt=Ypredcv{mmage.optidx};
model.CV.confmatrixopt=cmcv{mmage.optidx};
model.CV.classrateopt=crate{mmage.optidx};
model.CV.sensitivityopt=sens(mmage.optidx,:);
model.CV.specificivityopt=spec(mmage.optidx,:);

if strcmp(opt.output, 'full')
    model.CV.predclass=Cpredcv;
    model.CV.predY=Ypredcv;
    model.CV.confmatrix=cmcv;
    model.CV.classrate=crate;
    model.CV.sensitivity=sens;
    model.CV.specificivity=spec;
    
end

model.CV.options=opt;
