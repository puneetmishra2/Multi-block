function model=RCldapred(X, varargin)
% RCldapred Applies a Linear Discriminant Analysis (LDA) model to new data
%   The function RCldapred applies a Linear Discriminant Analysis (LDA)
%   classification model (calculated by RClda) on a new set of data (for 
%   validation on a test set or for prediction of unknown samples)
%   Canonical variate analysis (CVA) is also performed. New samples are
%   projected on the CVs calculated on the training data.
%   
%
%   INPUTS:
%       X = cell array of predictor blocks for new data (of length nblocks) 
%    lmod = LDA model (can be the output of RClda)
%
%   OPTIONAL INPUTS:
%     clt = numerical vector coding for class belonging of the new data, 
%           if available
%
%   OUTPUT:
%    model = a structure array with all the results. CVA scores and weights
%            are saved in the CVA field, while the classification results
%            are stored in the class field.
%
%
%   I/O:
%           model=RCldapred(X,clt, lmod); 
%           model=RCldapred(X,lmod); 
%           
% Written by Federico Marini 
% Version: 19/04/2020

if nargin==2
    clt=[];
    lmod=varargin{1};
elseif nargin==3
    clt=varargin{1};
    lmod=varargin{2};
end

ns=size(X,1);

if ~isempty(clt)
    if size(clt, 1)==1
    clt=clt'; 
    end
    clnumt=unique(clt);
    clchk=ismember(clnumt, lmod.classcoding);
    clnumtnew=[lmod.classcoding; sort(clnumt(clchk==0), 'ascend')];
    clnewt=zeros(size(clt));
    nclt=length(clnumtnew);
    nsct=zeros(1, nclt);
    for j=1:nclt
        sj=find(clt==clnumtnew(j));
        clnewt(sj)=j;
        nsct(j)=length(sj);
    end
else
    clnumtnew=lmod.classcoding;
    clnewt=[];
    nclt=length(clnumtnew);
    nsct=[];
end

di=zeros(ns,lmod.nclasses);
for j=1:lmod.nclasses
    di(:,j)=mdapply(X, lmod.classmeans(j,:),lmod.Rmatrix);
end

postp=exp(-0.5*di)*diag(lmod.priorprob);
postp=postp./repmat(sum(postp,2), 1,lmod.nclasses);

model.classmeans=lmod.classmeans;
model.grandmean=lmod.grandmean;
model.nclasses=lmod.nclasses;
model.nclassestest=nclt;
model.classsamples=nsct;
model.modeledclasses=lmod.classcoding;
model.classcodingtest=clnumtnew;
model.trueclassorig=clt;
model.trueclasscoded=clnewt;
model.Rmatrix=lmod.Rmatrix;
model.MD2=di;
model.priortype=lmod.priortype;
model.priorprob=lmod.priorprob;
model.postprobab=postp;
[~,pc]=max(postp, [],2);
model.predclasscoded=pc;
pccod=zeros(size(pc));
for i=1:length(pccod)
    pccod(i)=clnumtnew(pc(i));
end
model.predclassorig=pccod;

model.CVA.scores=(X-repmat(lmod.grandmean, ns,1))*lmod.CVA.weights;
model.CVA.noncenteredscores=X*lmod.CVA.weights;
model.CVA.weights=lmod.CVA.weights;
model.CVA.eigs=lmod.CVA.eigs;

if ~isempty(clt)
    cm=RCconfmat(clnewt, pc,nclt);
    model.class.confmatrix=cm;
    nn=zeros(1, nclt);
    nn(nsct~=0)=1./nsct(nsct~=0);
    cr=diag(nn)*cm;
    
    model.class.classrate=cr;
    model.class.sensitivity=diag(cr);
    for i=1:nclt
        model.class.specificity(i,1)=sum(sum(cm([1:i-1 i+1:end],[1:i-1 i+1:end])))/sum(sum(cm([1:i-1 i+1:end],:)));
    end
    
    model.class.meanCCR=mean(model.class.sensitivity);
    model.class.accuracy=sum(diag(cm))/sum(nsct);
    
else
    model.class.confmatrix=[];
    model.class.classrate=[];
    model.class.sensitivity=[];
    model.class.specificity=[];
    model.class.meanCCR=[];
    model.class.accuracy=[];
end
