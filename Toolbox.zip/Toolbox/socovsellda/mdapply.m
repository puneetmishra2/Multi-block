function d=mdapply(Y, m, R)
% mdapply Calculates Mahalanobis distances wrt centroid of another data set
%   The function mdapply calculates the squared Mahalanobis distance between 
%   the elements of the matrix Y and the centroid m of another data set X, 
%   based on the (pseudo)square root R of the covariance matrix of X, calculated
%   by the function mdcalc. It is called, for instance, by the RClda and
%   RCldapred routines.
%
%   INPUTS:
%        Y = the data matrix with new samples 
%        m = coordinates of the centroid (mean row vector) of X. 
%        R = the QR (pseudo)square root of the covariance matrix of X 
%
%   OUTPUT:
%        d = vector of squared Mahalanobis distances between each row in Y 
%            and the centroid of X
%
%   I/O:
%           d=mdapply(Y, m, R); 
%
%           
% Written by Federico Marini 
% Version: 19/04/2020

[ry,~] = size(Y);
Yc = Y - repmat(m, ry,1);
di=Yc/R;
d=sum(di.^2, 2); 


