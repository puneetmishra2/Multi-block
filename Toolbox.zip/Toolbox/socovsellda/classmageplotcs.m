function model=classmageplotcs(rmsecv,cerr, acc, lvcomb,selcrit, plottype)
% classmageplot Mage plot based on SO-CovSel-LDA cross-validation results
%   The function classmageplot uses the results of sequential and orthogonalized  
%   CovSel-LDA (SO-CovSel-LDA) multi-block classification model in cross-validation,    
%   to display the RMSECV, the classification error and 1-classification accuracy 
%   as a function of total model complexity (the so-called Mage plots). 
%   Based on the results, it is also possible to define the
%   optimal model complexity of the classification model. 
%   The function is called within the socovlda_cv routine, but it can also be
%   used as a standalone function to plot the results of socovlda_cv after
%   modeling.
%
%   INPUTS:
%     rmsecv = vector containing the values of the total RMSECV for each combination
%              of selected X variables (length: number of possible combinations
%              of X variabless: ncomb)
%       cerr = vector containing the values of the total classification error 
%              for each combination of selected variables (length: number of 
%              possible combinations of selected variables: ncomb)
%        acc = vector containing the values of the classification accuracy
%              for each combination of selected variables (length: number of 
%              possible combinations of selected variables: ncomb)
%     lvcomb = matrix (ncombxnblocks) defining all the tested combinations
%              of the numbers of selected variables per block.
%    selcrit = ['rmse' | 'cerr' | 'acc' | 'manual'] Governs whether the optimal 
%                                  number of variables is automatically (based on 
%                                  either the RMSECV, the total classification
%                                  error in CV or 1-accuracy in CV) or manually selected
%   plottype = ['off' | 'best' ! 'all'] Defines the level of display of the 
%                                  Mage plot. In 'best', only the combinations of
%                                  selected variables leading to the minimum error 
%                                  for each total model complexity are displayed.
%                                  
%   OUTPUT:
%   model = a structure array with all the results. The optimal combination
%           of selected variables is saved in the field lvopt, while the index of the
%           combination is saved in optidx.
%
%   I/O:
%           model=classmageplotcs(rmsecv, cerr, acc, lvcomb,selcrit, plottype); 
%           
% Written by Federico Marini 
% Version: 05/05/2020

acc=1-acc;
nblock=size(lvcomb,2);
lvtot=sum(lvcomb,2);
maxlv=max(lvtot);
rmsmin=zeros(maxlv+1,1);
cerrmin=zeros(maxlv+1,1);
accmin=zeros(maxlv+1,1);
nmin=zeros(maxlv+1,1);
ncmin=zeros(maxlv+1,1);
namin=zeros(maxlv+1,1);
lvmin=zeros(maxlv+1,nblock);
lvmincerr=zeros(maxlv+1,nblock);
lvminacc=zeros(maxlv+1,nblock);

for nlv=0:maxlv
    scomb=find(lvtot==nlv);
    [merr,cmbidx]=min(rmsecv(scomb));
    [mcerr,cmbidx2]=min(cerr(scomb));
    [macc,cmbidx3]=min(acc(scomb));
    rmsmin(nlv+1)=merr;
    lvmin(nlv+1,:)=lvcomb(scomb(cmbidx),:);
    nmin(nlv+1)=scomb(cmbidx);
    
    cerrmin(nlv+1)=mcerr;
    lvmincerr(nlv+1,:)=lvcomb(scomb(cmbidx2),:);
    ncmin(nlv+1)=scomb(cmbidx2);
    
    accmin(nlv+1)=macc;
    lvminacc(nlv+1,:)=lvcomb(scomb(cmbidx3),:);
    namin(nlv+1)=scomb(cmbidx3);
end

switch plottype
    case 'off'
        
        
    case 'best'
        figure('units', 'normalized', 'position', [0.1 0.1 0.8 0.7])
        subplot(1,2,1)
        hold on
        plot(0:maxlv, rmsmin, 'sk', 0:maxlv, rmsmin, '-k','linewidth', 1, 'markersize', 5)
        for j=1:maxlv+1
            text(j-1, rmsmin(j)+.02*range(rmsmin), num2str(lvmin(j,:),[repmat('%.0f,', 1,nblock-1),'%.0f']), 'fontsize', 12, 'fontweight', 'bold')
        end
        xlabel('Total number of selected variables', 'fontsize', 12, 'fontweight', 'bold')
        ylabel('RMSECV', 'fontsize', 12, 'fontweight', 'bold')
        title('RMSE', 'fontsize', 12, 'fontweight', 'bold')
        
        subplot(1,2,2)
        hold on
        plot(0:maxlv, cerrmin, 'o-r', 'linewidth', 1, 'markersize', 5)
        plot(0:maxlv, accmin, 'd-b', 'linewidth', 1, 'markersize', 5)
        
        for j=1:maxlv+1
            text(j-1, cerrmin(j)+.02*range(cerrmin), num2str(lvmincerr(j,:),[repmat('%.0f,', 1,nblock-1),'%.0f']), 'fontsize', 12, 'fontweight', 'bold', 'color', 'r')
        end
        
        for j=1:maxlv+1
            text(j-1, accmin(j)+.02*range(accmin), num2str(lvminacc(j,:),[repmat('%.0f,', 1,nblock-1),'%.0f']), 'fontsize', 12, 'fontweight', 'bold', 'color', 'b')
        end
        
        legend({'Classification error','1-Accuracy'}, 'fontsize', 12, 'fontweight', 'bold')
        
        xlabel('Total number of selected variables', 'fontsize', 12, 'fontweight', 'bold')
        ylabel('% Error rate', 'fontsize', 12, 'fontweight', 'bold')
        title('Classification', 'fontsize', 12, 'fontweight', 'bold')
        
    case 'all'
        
        figure('units', 'normalized', 'position', [0.1 0.1 0.8 0.7])
        hold on
        plot(0:maxlv, rmsmin, '-k','linewidth', 1)
        for j=1:length(lvtot)
            plot(lvtot(j), rmsecv(j), 'sk', 'markersize', 5)
            
            text(lvtot(j), rmsecv(j)+.02*range(rmsmin), num2str(lvcomb(j,:),[repmat('%.0f,', 1,nblock-1),'%.0f']), 'fontsize', 9, 'fontweight', 'bold')
        end
        xlabel('Total number of selected variables', 'fontsize', 12, 'fontweight', 'bold')
        ylabel('RMSECV', 'fontsize', 12, 'fontweight', 'bold')
        title('RMSE', 'fontsize', 12, 'fontweight', 'bold')
        
        figure('units', 'normalized', 'position', [0.1 0.1 0.8 0.7])
        hold on
        plot(0:maxlv, cerrmin, '-r','linewidth', 1)
        for j=1:length(lvtot)
            plot(lvtot(j), cerr(j), 'or', 'markersize', 5)
            
            text(lvtot(j), cerr(j)+.02*range(rmsmin), num2str(lvcomb(j,:),[repmat('%.0f,', 1,nblock-1),'%.0f']), 'fontsize', 9, 'fontweight', 'bold', 'color', 'r')
        end
        xlabel('Total number of selected variables', 'fontsize', 12, 'fontweight', 'bold')
        ylabel('Classification error', 'fontsize', 12, 'fontweight', 'bold')
        title('Classification Error', 'fontsize', 12, 'fontweight', 'bold')
        
        figure('units', 'normalized', 'position', [0.1 0.1 0.8 0.7])
        hold on
        plot(0:maxlv, accmin, '-b','linewidth', 1)
        for j=1:length(lvtot)
            plot(lvtot(j), acc(j), 'db', 'markersize', 5)
            
            text(lvtot(j), acc(j)+.02*range(accmin), num2str(lvcomb(j,:),[repmat('%.0f,', 1,nblock-1),'%.0f']), 'fontsize', 9, 'fontweight', 'bold', 'color', 'b')
        end
        xlabel('Total number of selected variables', 'fontsize', 12, 'fontweight', 'bold')
        ylabel('1-Accuracy', 'fontsize', 12, 'fontweight', 'bold')
        title('Classification Accuracy', 'fontsize', 12, 'fontweight', 'bold')
        
end

if strcmp(selcrit, 'rmse')
    [opterr, mlv]=min(rmsmin);
    optcerr=cerrmin(mlv);
    optacc=accmin(mlv);
    nopt=nmin(mlv); 
    lvopt=lvmin(mlv,:);
elseif strcmp(selcrit, 'cerr')
    [optcerr, mlv]=min(cerrmin);
    optacc=accmin(mlv);
    opterr=rmsmin(mlv);
    nopt=ncmin(mlv);
    lvopt=lvmincerr(mlv,:);
elseif strcmp(selcrit, 'acc')
    [optacc, mlv]=min(accmin);
    optcerr=cerrmin(mlv);
    opterr=rmsmin(mlv);
    nopt=namin(mlv);
    lvopt=lvminacc(mlv,:);
elseif strcmp(selcrit, 'manual')
    lvopt=input('Input the optimal number of selected variables: ');
    nopt=find(ismember(lvcomb, lvopt, 'rows')==1); 
    opterr=rmsecv(nopt);
    optacc=acc(nopt);
    optcerr=cerr(nopt);
end



model.lvopt=lvopt; 
model.optidx=nopt;
model.rmseopt=opterr; 
model.cerropt=optcerr; 
model.accopt=1-optacc; 
model.rmsemin=rmsmin; 
model.cerrmin=cerrmin; 
model.accmax=1-accmin; 
model.rmslvmin=lvmin; 
model.cerrlvmin=lvmincerr; 
model.acclvmax=lvminacc; 
