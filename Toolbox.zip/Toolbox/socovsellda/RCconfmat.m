function cm=RCconfmat(ct, cp,nt)
% RCconfmat Calculates confusion matrix
%   The function RCconfmat calculates a confusion matrix based on the outcomes 
%   of a classification model. It is called, for instance, by the RClda and
%   RCldapred routines. 
%
%   INPUTS:
%       ct = vector with the true classification of samples
%       cp = vector with the predicted classification of samples
%       nt = number of classes 
%
%   OUTPUT:
%       cm = the confusion matrix (dim: true classes x predicted classes)
%
%   I/O:
%           cm=RCconfmat(ct, cp,nt); 
%
%           
% Written by Federico Marini 
% Version: 19/04/2020

cm=zeros(nt,nt); 
for i=1:length(cp)
    cm(ct(i), cp(i))=cm(ct(i), cp(i))+1; 
end
