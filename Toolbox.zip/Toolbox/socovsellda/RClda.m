function model=RClda(X, cl, prior)
% RClda Trains Linear Discriminant Analysis (LDA) model
%   The function RClda calculates a Linear Discriminant Analysis (LDA)
%   classification model on training data. 
%   Canonical variate analysis (CVA) is also performed. 
%   
%   INPUTS:
%       X = Data matrix 
%      cl = numerical vector coding for class belonging
%
%   OPTIONAL INPUT:
%   prior = [{'uniform'} | 'frequency'] Defines whether uniform priors or priors 
%           based on number of training samples per class should be used when 
%           calculating the LDA model. If prior is a vector (length: number 
%           of classes), then custom priors are input. If omitted, uniform
%           priors are used.
%                                   
%
%   OUTPUT:
%   model = a structure array with all the results. CVA scores and weights
%           are saved in the CVA field, while the classification results
%           are stored in the class field.
%
%   I/O:
%           model=RClda(X,cl, prior); 
%           model=RClda(X,cl); 
%
%           
% Written by Federico Marini 
% Version: 19/04/2020

if size(cl, 1)==1
    cl=cl'; 
end


if nargin==2 || isempty(prior)
    prior='uniform'; 
end
[ns, nv]=size(X); 
clnum=unique(cl); 
ncl=length(clnum);
clnew=zeros(size(cl));

[~, M, R]=mdcalc(X);
m=zeros(ncl, nv);
Sw=0;
Sb=0;

di=zeros(ns,ncl); 
nsc=zeros(1, ncl);

for j=1:ncl
    sj=find(cl==clnum(j)); 
    clnew(sj)=j; 
    m(j,:)=mean(X(sj,:));
    nsc(j)=length(sj);
    Sw=Sw+(X(sj,:)-repmat(m(j,:), nsc(j),1))'*(X(sj,:)-repmat(m(j,:), nsc(j),1));
    Sb=Sb+nsc(j)*(m(j,:)-M)'*(m(j,:)-M);
    di(:,j)=mdapply(X, m(j,:), R); 
end

if ~ischar(prior) && isvector(prior)
    pr=prior/sum(prior); 
else
    switch prior
        case 'uniform'
            pr=repmat(1/ncl, 1, ncl); 
        case 'frequency'
            pr=nsc/sum(nsc); 
    end
end

postp=exp(-0.5*di)*diag(pr); 
postp=postp./repmat(sum(postp,2), 1, ncl); 

model.classmeans=m; 
model.grandmean=M;
model.nclasses=ncl;
model.classsamples=nsc; 
model.classcoding=clnum; 
model.trueclassorig=cl; 
model.trueclasscoded=clnew; 
model.Rmatrix=R; 
model.MD2=di; 
model.priortype=prior; 
model.priorprob=pr; 
model.postprobab=postp; 
[~,pc]=max(postp, [],2); 
model.predclasscoded=pc;
pccod=zeros(size(pc)); 
for i=1:length(pccod)
    pccod(i)=clnum(pc(i)); 
end
model.predclassorig=pccod;

%calculation of the canonical variate scores and weights

[W, lambda]=eig(Sb,Sw, 'vector');
[lambda, neword]=sort(lambda,'descend');
 W=W(:,neword);
 ncomp=min(nv, ncl-1); 
 W=W(:,1:ncomp); 
 lambda=lambda(1:ncomp); 
 T=X*W; 
 T1=(X-repmat(M, ns,1))*W; 
 model.CVA.scores=T1; 
 model.CVA.noncenteredscores=T;
 model.CVA.weights=W; 
 model.CVA.eigs=lambda; 
 cm=RCconfmat(clnew, pc,ncl); 
 model.class.confmatrix=cm; 
 nn=zeros(1, ncl); 
 nn(nsc~=0)=1./nsc(nsc~=0);
 cr=diag(nn)*cm; 
 
 model.class.classrate=cr; 
 model.class.sensitivity=diag(cr); 
 for i=1:ncl
 model.class.specificity(i,1)=sum(sum(cm([1:i-1 i+1:end],[1:i-1 i+1:end])))/sum(sum(cm([1:i-1 i+1:end],:))); 
 end
 
 model.class.meanCCR=mean(model.class.sensitivity); 
 model.class.accuracy=sum(diag(cm))/sum(nsc); 
 