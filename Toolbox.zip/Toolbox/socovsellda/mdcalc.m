function [d, m, R]=mdcalc(X)
% mdcalc Calculates Mahalanobis distances wrt class centroid of same data
%   The function mdcalc calculates the squared Mahalanobis distance between 
%   the elements of the matrix X and the centroid of X. It is called, for
%   instance, by the RClda routine. 
%
%   INPUTS:
%        X = the data matrix (usually, data from a single category)
%
%   OUTPUT:
%        d = vector of squared Mahalanobis distances between each row in X 
%            and the centroid of X
%        m = coordinates of the centroid (mean row vector) of X. 
%        R = the QR (pseudo)square root of the covariance matrix of X 
%
%   I/O:
%           [d, m, R]=mdcalc(X); 
%
%           
% Written by Federico Marini 
% Version: 19/04/2020

[rx,~] = size(X);
m = mean(X);
Xc = X - repmat(m, rx,1);
[~,R] = qr(Xc,0);
R=R/sqrt(rx-1); 
di=Xc/R;
d=sum(di.^2, 2); 


