function model=socovlda_mod(X, cl, nVar, pret, ldaX, prior)
% socovlda_mod Trains a sequential and orthogonalized CovSel-LDA model
%   The function socovlda_mod calculates  a sequential and orthogonalized  
%   Covariance Selecttion-LDA (SO-CovSel-LDA) multi-block classification model 
%   on training data. 
%   
%   INPUTS:
%       X = cell array of predictor blocks (of length nblocks) 
%      cl = numerical vector coding for class belonging
%    nVar = number of variables to be extracted for each block (can be either
%           a scalar (same number for each block) or a vector (of length nblocks)
%    pret = a cell array (length nblocks) containing the desired
%           pretreatments for the X blocks.
%           Can take values 'none', 'mean', 'auto'.
%    ldaX = ['ypred' | 'selvar'] Defines whether the LDA model should be 
%           calculated on the Y predicted by SO-CovSel or on the X variables 
%           selected according to the CovSel algorithm.
%   OPTIONAL INPUT:
%   prior = [{'uniform'} | 'frequency'] Defines whether uniform priors or priors 
%           based on number of training samples per class should be used when 
%           calculating the LDA model. If prior is a vector (length: number 
%           of classes), then custom priors are input. If omitted, uniform
%           priors are used.
%
%   OUTPUT:
%   model = a structure array with all the results. 
%
%   I/O:
%           model=socovlda_mod(X,cl, nVar, pret); 
%           
% Written by Federico Marini 
% Version: 19/04/2020


nblock=length(X);
if nargin<6 || isempty(prior)
    prior='uniform';
end

%%% Creation of the class matrix
clnum=unique(cl); 
ncl=length(clnum);
clnew=zeros(size(cl));
Y=zeros(size(X,1), ncl); 
for j=1:ncl
    sj=find(cl==clnum(j)); 
    clnew(sj)=j; 
    Y(sj, j)=ones(length(sj),1); 
end


if max(size(nVar))==1
    nVar=repmat(nVar, 1, nblock);
end
Xp=cell(size(X));
preppars=cell(nblock+1,2);


for i=1:nblock
    [Xp{i},preppars{i,1},preppars{i,2}]=prepfn(X{i},pret{i});
end
[Yc,preppars{nblock+1,1},~]=prepfn(Y,'mean');
[yu, ys, preppars{nblock+1,2}]=svds(Yc, ncl-1); 

Yp=yu*ys; 

model.preptype=pret;
model.preppars=preppars;
model.nblock=nblock;

Xsel=[];
Yres=Yp;

for i=1:nblock
    
    if nVar(i)~=0
        
        if i==1||isempty(Xsel)
            Xo=Xp{i};
            [vsel,crbvar,Xseli,Xoseli,borth]=covsel(Xo,Yp,nVar(i));
            D=[];
        else
            Xo=(eye(size(Xp{i},1))-(Xsel/(Xsel'*Xsel)*Xsel'))*Xp{i};
            [vsel,crbvar,Xseli,Xoseli,borth]=covsel(Xo,Yp,nVar(i));
            D=(Xsel'*Xsel)\Xsel'*Xp{i}(:,vsel);
        end
        
        
        Xsel=[Xsel Xoseli];
        P=eye(size(Xo,2));
        P=P(:,vsel);
        
        
        model.covsel(i).XselOrig=Xseli;
        model.covsel(i).XselOrth=Xoseli;
        model.covsel(i).ExplVar=crbvar;
        model.covsel(i).SelVar=vsel;
        model.covsel(i).Brot=borth;
        model.covsel(i).Loadings=P*borth;
        model.covsel(i).Dmatrix=D;
        model.covsel(i).Borth=Xoseli\Yres;
        Bstar{i}=model.covsel(i).Borth;
        for j=1:i-1
            if j==1&&~isempty(Bstar{j})
                Bstar{j}=Bstar{j}-D(1:nVar(j),:)*Bstar{i};
            else
                if ~isempty(Bstar{j})
                    Bstar{j}=Bstar{j}-D(sum(nVar(1:j-1))+1:sum(nVar(1:j)),:)*Bstar{i};
                end
            end
        end
        
        Yres=Yres-Xoseli*Bstar{i};
        
    else
        model.covsel(i).XselOrig=[];
        model.covsel(i).XselOrth=[];
        model.covsel(i).ExplVar=[];
        model.covsel(i).SelVar=[];
        model.covsel(i).Brot=[];
        model.covsel(i).Loadings=[];
        model.covsel(i).Dmatrix=[];
        model.covsel(i).Borth=[];
        Bstar{i}=[];
        
    end
    
end


Yhat=zeros(size(Yp));
for i=1:nblock
    model.covsel(i).regSel=Bstar{i};
    model.reg{i}=model.covsel(i).Loadings*Bstar{i};
    if ~isempty(model.reg{i})
        Yhat=Yhat+Xp{i}*model.reg{i};
    end
end
YPred=unprepfn(Yhat*preppars{end,2}','mean',preppars{end,1},[]);

model.concvars=Xsel; 
model.predYsvd=Yhat;
model.predY=YPred;
model.resY=Y-YPred;
model.rmsec=sqrt(sum((model.resY).^2,1)/size(Y,1));
model.bias=mean(model.resY);
model.r2=1-(sum((model.resY).^2,1)./sum((Y-repmat(mean(Y), size(Y,1), 1)).^2,1));


switch ldaX
    case 'ypred'
        mlda=RClda(Yhat, cl, prior);
    case 'selvar'
        mlda=RClda(Xsel, cl,prior);
end

model.ldaX=ldaX;
model.lda=mlda;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [vsel,crbvar,Xsel,Xosel,borth] = covsel(x,y,nv)

crbvar=zeros(nv,2);

[nx,~] = size(x);
[ny,~] = size(y);

if nx ~= ny
    error('The number of samples in X and Y do not correspond')
end

nv = min( nv, rank(x) );
z=x;
t=y;

vartot=[ sum(sum(z.*z))     sum(sum(t.*t))];
Xosel=zeros(nx,nv);
vsel=zeros(1,nv);


for i=1:nv
    [~,j] = max( sum( (z'*t).^2 ,2) );
    vsel(i)=j;
    v = z(:,j);
    z = z - v*v'*z/(v'*v);
    crbvar(i,1) = ( vartot(1)-  sum(sum(z.*z)) ) / vartot(1);
    t = t - v*v'*t/(v'*v);
    crbvar(i,2) = ( vartot(2) - sum(sum(t.*t)) ) / vartot(2);
    
    Xosel(:,i)=v;
    
end

Xsel=x(:,vsel);

borth=pinv(Xsel)*Xosel;


%%%%%%%%%%%%%%%%
function [Mp,mm,sm]=prepfn(X,pret1)
%Preprocessing routine. Performs mean centering ('mean'), autoscaling
%('auto') or no pretreatment ('none')

nt=size(X,1);
switch pret1
    case 'none'
        Mp=X;
        mm=[];
        sm=[];
    case 'mean'
        mm=mean(X);
        sm=[];
        Mp=X-repmat(mm, nt, 1);
    case 'auto'
        mm=mean(X);
        sm=std(X);
        Mp=(X-repmat(mm, nt, 1))./repmat(sm,nt, 1);
end

%%%%%%%%%%%%%%%%%%
function Mn=unprepfn(X,pret1,mm,sm)
%Preprocessing routine. Applies preprocessing to new matrices using the parameters
%calculated on the training set. Performs mean centering ('mean'), autoscaling
%('auto') or no pretreatment ('none')

nt=size(X,1);
switch pret1
    case 'none'
        Mn=X;
        
    case 'mean'
        Mn=X+repmat(mm, nt, 1);
    case 'auto'
        Mn=(X.*repmat(sm,nt, 1))+repmat(mm, nt, 1);
end

